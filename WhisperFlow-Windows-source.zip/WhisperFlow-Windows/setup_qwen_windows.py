"""Explicit optional CPU setup. Models download only on first generation."""
from pathlib import Path
import subprocess
import sys
import venv

ROOT = Path(__file__).resolve().parent


def main():
    if sys.version_info[:2] != (3, 12):
        raise SystemExit('Please run this optional setup with Python 3.12.')
    directory = ROOT / '.qwen-env'
    venv.EnvBuilder(with_pip=False).create(directory)
    python = directory / ('Scripts/python.exe' if sys.platform == 'win32' else 'bin/python')
    command = [sys.executable, '-m', 'pip', '--python', str(python), 'install']
    print('Installing optional CPU speech dependencies. This requires a large download.', flush=True)
    subprocess.run(command + ['torch>=2.6,<3', 'torchaudio', '--index-url',
                              'https://download.pytorch.org/whl/cpu'], check=True)
    subprocess.run(command + ['-r', str(ROOT / 'requirements-qwen-windows.txt')], check=True)
    print('Ready. Run Start-Qwen-CPU.cmd, then choose Qwen and voice ID design:ko or design:en.')


if __name__ == '__main__':
    main()
