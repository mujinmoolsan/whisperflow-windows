"""Install the verified official llama.cpp CPU build and Qwen GGUF locally."""
from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import urllib.request
import zipfile

ROOT = Path(__file__).resolve().parent


def main():
    if sys.version_info < (3, 11):
        raise SystemExit('Python 3.11 or newer is required.')
    subprocess.run([sys.executable, '-m', 'pip', 'install', '--target', str(ROOT/'.windows-env'),
                    '-r', str(ROOT/'requirements-windows.txt')], check=True)
    native, models = ROOT/'.native/llama', ROOT/'.models/gguf'
    native.mkdir(parents=True, exist_ok=True)
    models.mkdir(parents=True, exist_ok=True)
    with urllib.request.urlopen(urllib.request.Request(
            'https://api.github.com/repos/ggml-org/llama.cpp/releases/tags/b11960',
            headers={'User-Agent':'JarvisVoiceSetup'}), timeout=30) as response:
        release = json.load(response)
    asset = next(item for item in release['assets']
                 if item['name'] == 'llama-b11960-bin-win-cpu-x64.zip')
    base = 'https://huggingface.co/ggml-org/Qwen3-TTS-12Hz-1.7B-Base-GGUF/resolve/main/'
    jobs = [(asset['browser_download_url'], native/'release.zip'),
            (base+'Qwen3-TTS-12Hz-1.7B-Base-Q4_K_M.gguf', models/'tts-q4.gguf'),
            (base+'mmproj-Qwen3-TTS-12Hz-1.7B-Base-Q8_0.gguf', models/'codec-q8.gguf')]

    def download(job):
        url, path = job
        if path.is_file():
            return
        temporary = path.with_suffix(path.suffix+'.partial')
        with urllib.request.urlopen(url, timeout=120) as response, temporary.open('wb') as file:
            while data := response.read(1024*1024):
                file.write(data)
        temporary.replace(path)
        print('Downloaded '+path.name, flush=True)

    with ThreadPoolExecutor(max_workers=3) as pool:
        list(pool.map(download, jobs))
    digest = hashlib.sha256((native/'release.zip').read_bytes()).hexdigest()
    if asset.get('digest') != 'sha256:'+digest:
        raise RuntimeError('Official release checksum mismatch.')
    with zipfile.ZipFile(native/'release.zip') as archive:
        for info in archive.infolist():
            if not (native/info.filename).resolve().is_relative_to(native.resolve()):
                raise RuntimeError('Unsafe archive path.')
        archive.extractall(native)
    print('Native Qwen is ready. Prepare local voice references, then run Start-Qwen-CPU.cmd.')


if __name__ == '__main__':
    main()
