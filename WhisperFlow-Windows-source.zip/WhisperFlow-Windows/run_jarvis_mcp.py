"""Absolute-path stdio entry point for MCP hosts that don't set cwd."""
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parent / '.windows-env'))
from whisperflow.jarvis_mcp import mcp

if __name__ == '__main__':
    mcp.run(transport='stdio')
