"""Local Windows bridge for the original JARVIS browser UI (ko/en).

Run with python -m whisperflow.windows. macOS entry points remain untouched.
"""
from __future__ import annotations

import argparse
import asyncio
import base64
import functools
import json
import logging
import mimetypes
import os
import re
from pathlib import Path
import shutil
import subprocess
import urllib.request
import webbrowser

from websockets.asyncio.server import serve
from websockets.datastructures import Headers
from websockets.http11 import Response

from .windows_ui import render_windows_ui

ROOT = Path(__file__).resolve().parents[1]
STATIC = Path(__file__).parent / 'static'
log = logging.getLogger(__name__)

PROFILES = {
    'ko': {'language': 'Korean', 'voice': 'design:ko', 'speed': 1.0,
           'instruct': 'Native standard Korean. Adult male, smooth medium-low register. '
           'Calm, intelligent, composed personal assistant. Clear diction, restrained intonation, '
           'subtle dry wit, polite conversational delivery. No exaggerated bass or robotic filter.'},
    'en': {'language': 'English', 'voice': os.getenv('JARVIS_TTS_VOICE', 'clone:jarvis'),
           'speed': float(os.getenv('JARVIS_TTS_SPEED', '1.4')),
           'instruct': 'Calm and warm narration tone, speaking at a steady moderate pace'},
}

CHARACTERS = {
    'jarvis': 'Calm, refined, intelligent personal assistant. Smooth medium-low male voice, '
              'clear diction, restrained intonation and understated dry wit.',
    'deckard': 'Heroic adult male robot police officer. Solid resonant medium-low voice, '
               'clear decisive diction, brave and sincere delivery. Controlled metallic texture, '
               'energetic without shouting. A new character-style voice, not a verified actor replica.',
}


def validate_options(data):
    language = data.get('language', 'ko')
    if language not in PROFILES:
        raise ValueError('Choose Korean or English.')
    profile = {**PROFILES[language], 'code': language}
    character = data.get('character', 'jarvis')
    if character not in CHARACTERS:
        raise ValueError('Choose Jarvis or Deckard.')
    if character == 'deckard' and language != 'ko':
        raise ValueError('Deckard is Korean only. Choose Jarvis for English.')
    profile['instruct'] = 'Native ' + profile['language'] + '. ' + CHARACTERS[character]
    voice = data.get('voice', profile['voice'])
    if not isinstance(voice, str) or not 1 <= len(voice) <= 80:
        raise ValueError('Invalid voice ID.')
    speed = float(data.get('speed', profile['speed']))
    if not .5 <= speed <= 2.0:
        raise ValueError('Speed must be between 0.5 and 2.0.')
    engine = data.get('engine', 'browser')
    if engine not in ('browser', 'qwen'):
        raise ValueError('Invalid voice engine.')
    effect = data.get('robot_effect', 'soft' if character == 'deckard' else 'none')
    if effect not in ('none','soft','strong'):
        raise ValueError('Invalid robot effect.')
    return {**profile, 'character': character, 'robot_effect': effect, 'voice': voice, 'speed': speed, 'engine': engine}


def claude_command():
    """Use a native executable or Node entry point; never shell-interpolate prompts."""
    explicit = os.getenv('JARVIS_CLAUDE_PATH')
    candidate = explicit or shutil.which('claude')
    if not candidate:
        return None
    path = Path(candidate)
    if path.suffix.lower() in ('.cmd', '.bat', '.ps1'):
        entry = path.parent / 'node_modules/@anthropic-ai/claude-code/cli.js'
        node = shutil.which('node')
        return [node, str(entry)] if node and entry.is_file() else None
    return [str(path)]


async def answer_with_claude(messages, text, language, model, cwd):
    command = claude_command()
    if not command:
        raise RuntimeError('Claude Code is not connected. Install/sign in to Claude Code, '
                           'then restart. Voice preview works without it.')
    instruction = ('Answer in natural Korean.' if language == 'ko' else 'Answer in natural English.')
    prompt = json.dumps({'conversation': messages[-16:], 'user': text}, ensure_ascii=False)
    command += ['--print', '--output-format', 'json', '--tools', '',
                '--strict-mcp-config', '--mcp-config', '{"mcpServers":{}}',
                '--disable-slash-commands', '--model', model,
                '--system-prompt', 'You are a calm, intelligent personal voice assistant. '
                'Keep replies concise and conversational, with restrained dry wit. ' + instruction]
    # Pass user content on stdin; Windows command-line length/quoting cannot alter it.
    proc = await asyncio.create_subprocess_exec(
        *command, stdin=asyncio.subprocess.PIPE, stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE, cwd=str(cwd),
        **({'creationflags': subprocess.CREATE_NO_WINDOW} if os.name == 'nt' else {}))
    try:
        stdout, stderr = await asyncio.wait_for(proc.communicate(prompt.encode('utf-8')), 180)
    except (asyncio.TimeoutError, asyncio.CancelledError):
        if proc.returncode is None:
            proc.kill()
        await proc.communicate()
        raise
    if proc.returncode:
        raise RuntimeError(stderr.decode('utf-8', 'replace').strip()[:1000] or 'Claude request failed.')
    result = json.loads(stdout.decode('utf-8'))
    if result.get('is_error'):
        raise RuntimeError(result.get('result', 'Claude request failed.'))
    answer = result.get('result', '')
    if not answer:
        raise RuntimeError('Claude returned an empty reply.')
    return answer


def generate_qwen(text, options, url):
    payload = json.dumps({'text': text, 'voice': options['voice'], 'seed': 42,
                          'character': options['character'],
                          'robot_effect': options['robot_effect'],
                          'language': options['language'],
                          'instruct': options['instruct']}).encode('utf-8')
    req = urllib.request.Request(url + '/generate', data=payload,
                                 headers={'Content-Type': 'application/json'})
    with urllib.request.urlopen(req, timeout=300) as response:
        audio = response.read()
    if audio[:4] != b'RIFF' or audio[8:12] != b'WAVE':
        raise RuntimeError('TTS server did not return a WAV file.')
    return audio


class WindowsBridge:
    def __init__(self, data_dir=None, answer_provider=None, tts_provider=None):
        self.data_dir = Path(data_dir or os.getenv('JARVIS_DATA_DIR', ROOT / '.windows-data'))
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.history_path = self.data_dir / 'conversations.json'
        self.sessions = {}
        if self.history_path.exists():
            self.sessions = json.loads(self.history_path.read_text(encoding='utf-8'))
        self.answer = answer_provider or answer_with_claude
        self.tts = tts_provider or functools.partial(
            generate_qwen, url=os.getenv('QWEN_TTS_URL', 'http://127.0.0.1:9093').rstrip('/'))
        self.tasks = {}
        self.voice_tasks = {}

    def save(self):
        temporary = self.history_path.with_suffix('.tmp')
        temporary.write_text(json.dumps(self.sessions, ensure_ascii=False, indent=2), encoding='utf-8')
        temporary.replace(self.history_path)

    def session(self, tab):
        return self.sessions.setdefault(tab, {'name': tab, 'model': 'haiku', 'messages': []})

    async def send(self, ws, kind, **data):
        await ws.send(json.dumps({'type': kind, **data}, ensure_ascii=False))

    def status(self):
        return {'claude': bool(claude_command()), 'languages': ['ko', 'en'],
                'openai': bool(os.environ.get('OPENAI_API_KEY')),
                'gpt_model': os.environ.get('JARVIS_GPT_MODEL', 'gpt-5-mini'),
                'profiles': PROFILES, 'tts': 'browser', 'platform': 'windows'}

    async def http(self, connection, request):
        if request.headers.get('Upgrade', '').lower() == 'websocket':
            return None
        path = request.path.split('?', 1)[0]
        if path == '/api/status':
            body = json.dumps(self.status()).encode('utf-8')
            mime = 'application/json'
        else:
            # In the Windows entry point both desktop and assistant routes use the working voice UI.
            path = '/jarvis.html' if path in ('/', '/assistant.html') else path
            file = (STATIC / path.lstrip('/')).resolve()
            if not file.is_relative_to(STATIC.resolve()) or not file.is_file():
                return connection.respond(404, 'Not found')
            if file.name == 'jarvis.html':
                body = render_windows_ui(file.read_text(encoding='utf-8')).encode('utf-8')
                mime = 'text/html; charset=utf-8'
            else:
                body = file.read_bytes()
                mime = mimetypes.guess_type(file.name)[0] or 'application/octet-stream'
        return Response(200, 'OK', Headers({'Content-Type': mime,
                        'Content-Length': str(len(body)), 'Cache-Control': 'no-store'}), body)

    async def speak(self, ws, text, options):
        await self.send(ws, 'state', value='tts_playing')
        try:
            if options['engine'] == 'browser':
                await self.send(ws, 'tts_browser', text=text, language=options['code'],
                                speed=options['speed'], voice=options['voice'])
            else:
                audio = await asyncio.to_thread(self.tts, text[:2000], options)
                await self.send(ws, 'tts_audio', value=base64.b64encode(audio).decode('ascii'),
                                speed=options['speed'])
        except Exception as exc:
            # Explicit fallback, so a system voice is never presented as a custom Qwen voice.
            await self.send(ws, 'voice_warning', error='Qwen unavailable: ' + str(exc)[:300])
            await self.send(ws, 'tts_browser', text=text, language=options['code'],
                            speed=options['speed'], voice='')
        finally:
            await self.send(ws, 'tts_done')

    async def chat(self, ws, data):
        tab = data.get('tab_id', 'main_assistant')
        try:
            options = validate_options(data)
            text = data.get('text', '').strip()
            if not text or len(text) > 12000:
                raise ValueError('Enter a message (maximum 12,000 characters).')
            session = self.session(tab)
            provider = data.get('provider', 'claude')
            if provider not in ('claude', 'openai'):
                raise ValueError('Choose GPT or Claude.')
            answer_function, model = self.answer, session['model']
            if provider == 'openai':
                from .windows_openai import answer_with_gpt
                answer_function = answer_with_gpt
                model = data.get('gpt_model') or os.environ.get('JARVIS_GPT_MODEL', 'gpt-5-mini')
                if not isinstance(model, str) or not re.fullmatch(r'[A-Za-z0-9._:-]{1,100}', model):
                    raise ValueError('Invalid GPT model ID.')
            answer = await answer_function(list(session['messages']), text, options['code'],
                                           model, self.data_dir)
            session['messages'] += [{'role': 'user', 'content': text},
                                    {'role': 'assistant', 'content': answer}]
            session['messages'] = session['messages'][-200:]
            self.save()
            await self.send(ws, 'chat_chunk', tab_id=tab, content=answer, chunk_type='assistant')
            await self.send(ws, 'chat_done', tab_id=tab)
            self.start_voice(ws, answer, options)
        except Exception as exc:
            log.warning('Chat failed: %s', type(exc).__name__)
            await self.send(ws, 'chat_error', tab_id=tab, error=str(exc))
            await self.send(ws, 'state', value='idle')

    def start_voice(self, ws, text, options):
        task = self.voice_tasks.get(ws)
        if task and not task.done():
            task.cancel()
        self.voice_tasks[ws] = asyncio.create_task(self.speak(ws, text, options))

    async def handler(self, ws):
        await self.send(ws, 'windows_status', **self.status())
        await self.send(ws, 'state', value='idle')
        try:
            async for raw in ws:
                data = {}
                try:
                    data = json.loads(raw)
                    if not isinstance(data, dict):
                        raise ValueError('Expected a message object.')
                    kind = data.get('type')
                    tab = data.get('tab_id', 'main_assistant')
                    if not isinstance(tab, str) or len(tab) > 100:
                        raise ValueError('Invalid session.')
                    if kind == 'chat_input':
                        if ws in self.tasks and not self.tasks[ws].done():
                            raise ValueError('Please wait for the current response.')
                        self.tasks[ws] = asyncio.create_task(self.chat(ws, data))
                    elif kind == 'tts_preview':
                        opts = validate_options(data)
                        text = ('시스템 점검을 마쳤습니다. 모든 기능이 정상입니다. 다만, 이번 계획은 조금 무모하군요.'
                                if opts['code'] == 'ko' else
                                'System checks are complete. Everything is operating normally. '
                                'Although, I must say, this plan is rather ambitious.')
                        self.start_voice(ws, text, opts)
                    elif kind == 'tts_interrupt':
                        task = self.voice_tasks.get(ws)
                        if task:
                            task.cancel()
                        await self.send(ws, 'state', value='idle')
                    elif kind == 'chat_history_request':
                        await self.send(ws, 'chat_history', tab_id=tab,
                                        messages=self.session(tab)['messages'])
                    elif kind == 'session_list':
                        await self.send(ws, 'session_list', sessions=[
                            {'tab_id': key, **{k: v for k, v in val.items() if k != 'messages'}}
                            for key, val in self.sessions.items()])
                    elif kind == 'session_create':
                        session = self.session(tab)
                        session['name'] = str(data.get('name', tab))[:100]
                        self.save()
                        await self.send(ws, 'session_created', tab_id=tab, session=session)
                    elif kind == 'session_model_change':
                        model = data.get('model', 'haiku')
                        if model not in ('haiku', 'sonnet', 'opus'):
                            raise ValueError('Invalid model.')
                        self.session(tab)['model'] = model
                        self.save()
                        await self.send(ws, 'model_changed', tab_id=tab, model=model)
                    elif kind == 'state':
                        await self.send(ws, 'state', value=data.get('value', 'idle'))
                    elif kind == 'file_upload':
                        raise ValueError('File attachments are not enabled in this voice version.')
                except (ValueError, TypeError, KeyError) as exc:
                    await self.send(ws, 'chat_error', tab_id=data.get('tab_id', 'main_assistant')
                                    if isinstance(data, dict) else 'main_assistant', error=str(exc))
        finally:
            pending = []
            for tasks in (self.tasks, self.voice_tasks):
                task = tasks.pop(ws, None)
                if task:
                    task.cancel()
                    pending.append(task)
            if pending:
                await asyncio.gather(*pending, return_exceptions=True)


async def run(port=8767, open_browser=False):
    bridge = WindowsBridge()
    origins = [f'http://127.0.0.1:{port}', f'http://localhost:{port}']
    async with serve(bridge.handler, '127.0.0.1', port, process_request=bridge.http,
                     origins=origins, max_size=100000):
        url = f'http://127.0.0.1:{port}'
        print('JARVIS Windows: ' + url, flush=True)
        if open_browser:
            webbrowser.open(url)
        await asyncio.Future()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--port', type=int, default=8767)
    parser.add_argument('--open', action='store_true')
    args = parser.parse_args()
    logging.basicConfig(level=logging.INFO)
    try:
        asyncio.run(run(args.port, args.open))
    except KeyboardInterrupt:
        pass


if __name__ == '__main__':
    main()
