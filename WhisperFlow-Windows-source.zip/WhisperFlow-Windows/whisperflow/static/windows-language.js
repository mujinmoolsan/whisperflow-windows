/* Loaded only by the Windows bridge. Original macOS pages stay unchanged. */
(() => {
  'use strict';
  const KEY = 'jarvis_windows_voice_v1';
  const defaults = {
    language: 'ko', character: 'jarvis', provider: 'claude', gptModel: 'gpt-5-mini',
    ko: {engine: 'browser', voice: 'clone:jarvis', browserVoice: '', speed: 1.0},
    en: {engine: 'browser', voice: 'clone:jarvis', browserVoice: '', speed: 1.4}
  };
  let settings;
  try {
    const saved = JSON.parse(localStorage.getItem(KEY) || '{}');
    settings = {...defaults, ...saved,
      ko: {...defaults.ko, ...saved.ko}, en: {...defaults.en, ...saved.en}};
  } catch (_) { settings = structuredClone(defaults); }
  if (!['ko', 'en'].includes(settings.language)) settings.language = 'ko';
  if (!['jarvis', 'deckard'].includes(settings.character)) settings.character = 'jarvis';
  settings.characters = settings.characters || {};
  settings.characters.jarvis = settings.characters.jarvis || {ko: settings.ko, en: settings.en};
  settings.characters.deckard = settings.characters.deckard || {
    ko: {...defaults.ko, voice: 'clone:deckard'},
    en: {...defaults.en, voice: 'clone:deckard', speed: 1.0}
  };
  if (settings.characters.jarvis.ko.voice === 'design:ko' && !settings.referenceProfiles) {
    settings.characters.jarvis.ko.voice = 'clone:jarvis';
  }
  settings.referenceProfiles = true;
  if (settings.character === 'deckard') settings.language = 'ko';
  let socket, recognition, panel, serverStatus;
  const profile = () => settings.characters[settings.character][settings.language];
  const locale = () => settings.language === 'ko' ? 'ko-KR' : 'en-GB';
  const save = () => { try { localStorage.setItem(KEY, JSON.stringify(settings)); } catch (_) {} };
  const el = id => document.getElementById(id);
  const notify = text => { if (el('voiceNote')) el('voiceNote').textContent = text; };
  const options = () => ({language: settings.language, engine: profile().engine,
    character: settings.character,
    robot_effect: profile().robotEffect || (settings.character === 'deckard' ? 'soft' : 'none'),
    provider: settings.provider, gpt_model: settings.gptModel,
    voice: profile().engine === 'browser' ? (profile().browserVoice || 'default') : profile().voice,
    speed: Number(profile().speed)});
  function send(value) {
    if (!socket || socket.readyState !== WebSocket.OPEN) {
      notify('서버 연결을 기다려주세요 / Waiting for connection.'); return false;
    }
    socket.send(JSON.stringify(value)); return true;
  }
  function voiceList() {
    if (!el('browserVoice')) return;
    const select = el('browserVoice');
    select.replaceChildren();
    const auto = document.createElement('option'); auto.value = ''; auto.textContent = '기본 음성 / Default';
    select.append(auto);
    for (const voice of (window.speechSynthesis?.getVoices() || [])) {
      if (!voice.lang.toLowerCase().startsWith(settings.language)) continue;
      const option = document.createElement('option');
      option.value = voice.voiceURI; option.textContent = `${voice.name} (${voice.lang})`;
      select.append(option);
    }
    select.value = profile().browserVoice;
    if (select.selectedIndex < 0) select.value = '';
  }
  function update() {
    if (!panel) return;
    el('voiceLanguage').value = settings.language;
    el('voiceLanguage').querySelector('option[value="en"]').disabled = settings.character === 'deckard';
    el('voiceCharacter').value = settings.character;
    el('answerProvider').value = settings.provider;
    el('gptModel').value = settings.gptModel;
    el('gptModelRow').hidden = settings.provider !== 'openai';
    el('voiceEngine').value = profile().engine;
    el('robotEffect').value = profile().robotEffect || (settings.character === 'deckard' ? 'soft' : 'none');
    el('robotRow').hidden = profile().engine !== 'qwen';
    el('qwenVoice').value = profile().voice;
    el('voiceSpeed').value = profile().speed;
    el('voiceSpeedLabel').textContent = Number(profile().speed).toFixed(2) + '×';
    el('qwenRow').hidden = profile().engine !== 'qwen';
    el('browserRow').hidden = profile().engine !== 'browser';
    document.documentElement.lang = settings.language;
    voiceList();
    const langDisplay = el('valLang'); if (langDisplay) langDisplay.textContent = settings.language.toUpperCase();
    if (el('windowsEngine')) el('windowsEngine').textContent = profile().engine.toUpperCase();
    if (el('windowsSpeed')) el('windowsSpeed').textContent = Number(profile().speed).toFixed(2) + 'x';
    notify(profile().engine === 'browser'
      ? '기본 음성 미리듣기 · 원하는 남성 음색은 Qwen에서 제작합니다.'
      : 'Qwen 서버 연결 필요 · 기존 영어 음성 ID 또는 design:en 사용');
    updateConnection();
  }
  function updateConnection() {
    if (!serverStatus || !el('voiceConnection')) return;
    const isGPT = settings.provider === 'openai';
    const available = isGPT ? serverStatus.openai : serverStatus.claude;
    el('voiceConnection').textContent = available
      ? (isGPT ? 'GPT 키 설정 감지됨 · API 사용 시 요금이 발생할 수 있습니다.' : 'Claude 실행 파일 감지됨 · 계정 로그인 필요')
      : (isGPT ? 'GPT API 키 설정 필요 · 음성 미리듣기는 사용 가능' : 'Claude Code 연결 필요 · 음성 미리듣기는 사용 가능');
    if (el('valModel')) el('valModel').textContent = available ? (isGPT ? 'GPT' : 'CLAUDE') : 'NOT CONNECTED';
  }
  function state(value) { if (typeof setUIState === 'function') setUIState(value); }
  function browserSpeak(msg) {
    if (!window.speechSynthesis) { notify('이 브라우저는 음성 재생을 지원하지 않습니다.'); state('idle'); return; }
    const synth = window.speechSynthesis;
    synth.cancel();
    const voices = synth.getVoices().filter(v => v.lang.toLowerCase().startsWith(msg.language));
    const utterance = new SpeechSynthesisUtterance(msg.text);
    const voice = voices.find(v => v.voiceURI === msg.voice) || voices[0];
    if (voice) utterance.voice = voice;
    utterance.lang = msg.language === 'ko' ? 'ko-KR' : 'en-GB';
    utterance.rate = msg.speed || 1;
    utterance.onstart = () => state('tts_playing');
    utterance.onend = () => state('idle');
    utterance.onerror = event => {
      if (!['canceled', 'interrupted'].includes(event.error)) notify('음성 재생 실패: ' + event.error);
      state('idle');
    };
    if (!voices.length) notify('해당 언어의 시스템 음성이 없을 수 있습니다. Qwen 연결 또는 음성 설치가 필요합니다.');
    // Retain a reference while speech is in progress (Chromium garbage collection).
    window.JarvisLanguage.utterance = utterance;
    synth.speak(utterance);
  }
  window.JarvisLanguage = {
    language: () => settings.language, locale, options,
    setRecognition: value => { recognition = value; },
    bind: value => { socket = value; },
    receive(msg) {
      if (msg.type === 'windows_status') {
        serverStatus = msg;
        updateConnection();
      }
      if (msg.type === 'tts_browser') browserSpeak(msg);
      if (msg.type === 'voice_warning') {
        notify(msg.error + ' · 시스템 기본 음성으로 전환합니다.');
        if (el('windowsEngine')) el('windowsEngine').textContent = 'SYSTEM (FALLBACK)';
      }
      if (msg.type === 'tts_audio' && typeof getTtsAudioEl === 'function') {
        getTtsAudioEl().playbackRate = msg.speed || 1;
      }
    }
  };
  document.addEventListener('DOMContentLoaded', () => {
    const style = document.createElement('style');
    style.textContent = `#windowsVoice{position:fixed;top:14px;right:14px;z-index:99999;width:310px;
      background:rgba(4,17,29,.97);border:1px solid #22748a;border-radius:12px;padding:12px;
      color:#cef4ff;font:13px/1.5 system-ui;box-shadow:0 8px 32px #0008}
      #windowsVoice summary{cursor:pointer;font-weight:600;letter-spacing:.03em}
      #windowsVoice label{display:flex;align-items:center;justify-content:space-between;gap:8px;margin-top:9px}
      #windowsVoice input,#windowsVoice select{max-width:190px;background:#0d2436;color:#e5f8ff;
      border:1px solid #28536a;border-radius:5px;padding:5px;font:inherit}
      #windowsVoice [hidden]{display:none!important} #windowsVoice small{display:block;color:#98baca;margin-top:8px}
      #windowsVoice button{background:#123d50;color:#baf4ff;border:1px solid #368ca3;
      padding:7px 12px;border-radius:6px;margin:10px 5px 0 0;cursor:pointer}
      @media(max-width:600px){#windowsVoice{top:8px;right:8px;width:min(310px,calc(100vw - 40px))}}`;
    document.head.append(style);
    panel = document.createElement('details'); panel.id = 'windowsVoice'; panel.open = true;
    panel.innerHTML = `<summary>음성 설정 · Voice</summary>
      <label>캐릭터 / Character<select id="voiceCharacter"><option value="jarvis">자비스 / JARVIS</option><option value="deckard">케이캅스 데커드 / Deckard</option></select></label>
      <label>언어 / Language<select id="voiceLanguage"><option value="ko">한국어</option><option value="en">English</option></select></label>
      <label>음성 / Voice<select id="voiceEngine"><option value="browser">시스템 기본 / System</option><option value="qwen">Qwen 맞춤 음성 / Custom</option></select></label>
      <label id="browserRow">목소리<select id="browserVoice"></select></label>
      <label id="qwenRow">음성 ID<input id="qwenVoice" maxlength="80" aria-label="Qwen voice ID"></label>
      <label id="robotRow">로봇 효과<select id="robotEffect"><option value="none">없음 / None</option><option value="soft">약하게 / Soft</option><option value="strong">강하게 / Strong</option></select></label>
      <label>속도 / Speed <input id="voiceSpeed" type="range" min="0.5" max="2" step="0.05"><span id="voiceSpeedLabel"></span></label>
      <button id="voicePreview" type="button">미리듣기 / Preview</button><button id="voiceStop" type="button">정지 / Stop</button>
      <small id="voiceNote" role="status"></small>
      <details style="margin-top:10px"><summary>독립 채팅 · Optional chat</summary>
        <label>대화 / Conversation<select id="answerProvider"><option value="claude">Claude Code</option><option value="openai">GPT (OpenAI API)</option></select></label>
        <label id="gptModelRow">GPT 모델<input id="gptModel" maxlength="100" aria-label="GPT model ID"></label>
        <small id="voiceConnection">서버 연결 중 / Connecting…</small>
      </details>`;
    document.body.append(panel);
    el('voiceCharacter').onchange = event => {
      window.dispatchEvent(new Event('jarvis-language-change'));
      send({type:'tts_interrupt'});
      settings.character = event.target.value;
      if (settings.character === 'deckard') settings.language = 'ko';
      save(); update();
    };
    el('answerProvider').onchange = event => { settings.provider = event.target.value; save(); update(); };
    el('gptModel').onchange = event => {
      settings.gptModel = event.target.value.trim() || defaults.gptModel; save(); update();
    };
    el('voiceLanguage').onchange = event => {
      if (window.speechSynthesis) window.speechSynthesis.cancel();
      window.dispatchEvent(new Event('jarvis-language-change'));
      settings.language = event.target.value;
      if (recognition) { try { recognition.abort(); } catch (_) {} recognition = null; }
      send({type: 'tts_interrupt'}); save(); update();
    };
    el('voiceEngine').onchange = event => { profile().engine = event.target.value; save(); update(); };
    el('robotEffect').onchange = event => { profile().robotEffect = event.target.value; save(); };
    el('browserVoice').onchange = event => { profile().browserVoice = event.target.value; save(); };
    el('qwenVoice').onchange = event => { profile().voice = event.target.value.trim() || defaults[settings.language].voice; save(); };
    el('voiceSpeed').oninput = event => {
      profile().speed = Number(event.target.value); save();
      el('voiceSpeedLabel').textContent = profile().speed.toFixed(2) + '×';
      if (el('windowsSpeed')) el('windowsSpeed').textContent = profile().speed.toFixed(2) + 'x';
    };
    el('voicePreview').onclick = () => {
      if (typeof unlockTtsAudio === 'function') unlockTtsAudio();
      if (typeof stopTtsPlayback === 'function') stopTtsPlayback();
      send({type: 'tts_preview', ...options()});
    };
    el('voiceStop').onclick = () => {
      if (window.speechSynthesis) window.speechSynthesis.cancel();
      if (typeof stopTtsPlayback === 'function') stopTtsPlayback();
      send({type: 'tts_interrupt'}); state('idle');
    };
    if (window.speechSynthesis) window.speechSynthesis.addEventListener('voiceschanged', voiceList);
    update();
    if (serverStatus) window.JarvisLanguage.receive({type:'windows_status', ...serverStatus});
  });
})();
