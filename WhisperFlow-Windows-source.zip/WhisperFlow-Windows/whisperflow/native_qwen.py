"""Small-process Qwen GGUF backend, using an official llama.cpp Windows build."""
import os
from pathlib import Path
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parents[1]


def paths():
    runtime = Path(os.getenv('JARVIS_NATIVE_DIR', ROOT / '.native/llama'))
    models = Path(os.getenv('JARVIS_NATIVE_MODEL_DIR', ROOT / '.models/gguf'))
    return runtime / 'llama-tts.exe', models / 'tts-q4.gguf', models / 'codec-q8.gguf'


def available():
    return all(path.is_file() for path in paths())


def generate(text, reference, language, seed=42):
    executable, model, codec = paths()
    if not available():
        raise RuntimeError('Run Setup-Native-Qwen.cmd first.')
    parent = ROOT / '.windows-data/tmp'
    parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(dir=parent) as temporary:
        output = Path(temporary) / 'speech.wav'
        # The native TTS file readers do not reliably handle absolute non-ASCII
        # Windows paths. Relative paths keep Unicode home names out of those readers.
        def relative(path):
            try:
                return os.path.relpath(path, ROOT)
            except ValueError:
                return str(path)
        command = [str(executable), '-m', relative(model), '--mmproj', relative(codec),
                   '-p', text, '--tts-lang', language, '--tts-speaker-file', relative(reference),
                   '--output', relative(output), '-ngl', '0', '-t', '4',
                   '-n', str(min(1024, max(96, len(text) * 6))),
                   '--seed', str(seed), '--repeat-penalty', '1.05']
        result = subprocess.run(command, cwd=str(ROOT), capture_output=True, timeout=300,
                                **({'creationflags': subprocess.CREATE_NO_WINDOW} if os.name == 'nt' else {}))
        if result.returncode or not output.is_file():
            (parent.parent/'native-error.log').write_bytes(result.stderr)
            raise RuntimeError('Local Qwen synthesis failed. Check the runtime and model files.')
        return output.read_bytes()
