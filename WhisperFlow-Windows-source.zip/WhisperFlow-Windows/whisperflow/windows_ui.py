"""Adapt the original visual UI without changing the macOS pages."""


def render_windows_ui(source: str) -> str:
    replacements = {
        "<head>": '<head>\n<script src="/windows-language.js"></script>',
        "'ws://' + window.location.hostname + ':8767'": "'ws://' + window.location.host",
        "const isMobileView = window.innerWidth <= 600;":
            "const isMobileView = window.innerWidth <= 600;",
        "recognition.lang = 'ko-KR';": "recognition.lang = window.JarvisLanguage.locale();",
        "if (isMobileView) {\n        // Mobile: use Web Speech API (phone mic)":
            "if (true) {\n        // Windows and mobile use the browser microphone.",
        "text: msgText\n": "text: msgText, ...window.JarvisLanguage.options()\n",
        "handleMessage(msg);": "window.JarvisLanguage.receive(msg);\n          handleMessage(msg);",
        "const msg = JSON.parse(event.data);":
            "const msg = JSON.parse(event.data); window.JarvisLanguage.bind(ws);",
        "recognition.onstart = () => {":
            "window.JarvisLanguage.setRecognition(recognition);\n      recognition.onstart = () => {",
        "// Play \"Yes, sir\" before starting recognition (original speed)":
            "// Preserve the original English acknowledgement in English mode.",
        "fetch('/sounds/yes_sir.wav')":
            "(window.JarvisLanguage.language() === 'en' ? fetch('/sounds/yes_sir.wav') : Promise.reject())",
        "case 'tts_done': {": "case 'tts_done': {",
        "function stopTtsPlayback() {":
            "function stopTtsPlayback() {\n      if (window.speechSynthesis) window.speechSynthesis.cancel();",
        "ttsAudioPlaying = false;\n        // 주의:":
            "ttsAudioPlaying = false;\n        setUIState('idle');\n        // 주의:",
        "chatAttachBtn.addEventListener('click', () => chatFileInput.click());":
            "chatAttachBtn.style.display = 'none'; // Voice-only bridge: no file uploads.",
        'id="valModel">LARGE-V3': 'id="valModel">NOT CONNECTED',
        '<span class="label">SAMPLE RATE</span>': '<span class="label">INPUT</span>',
        '<span class="value">16,000 Hz</span>': '<span class="value">BROWSER MIC</span>',
        '<span class="value">TYPE</span>': '<span class="value">VOICE + TEXT</span>',
        '<span class="value active">QWEN</span>': '<span class="value active" id="windowsEngine">SYSTEM</span>',
        'id="valMode">YOUTUBE': 'id="valMode">VOICE CHAT',
        '<span class="value">1.4x</span>': '<span class="value" id="windowsSpeed">1.0x</span>',
    }
    for old, new in replacements.items():
        if old not in source:
            raise RuntimeError(f"Upstream UI changed; expected fragment missing: {old[:70]}")
        source = source.replace(old, new)
    # Clear microphone transcript before aborting, so switching languages cannot auto-send it.
    source = source.replace("</body>", """<script>
window.addEventListener('jarvis-language-change', () => {
  if (typeof chatSlideInput !== 'undefined') chatSlideInput.value = '';
  if (typeof stopWebSpeech === 'function') stopWebSpeech();
  if (typeof stopTtsPlayback === 'function') stopTtsPlayback();
  if (typeof webSpeechRecognition !== 'undefined') webSpeechRecognition = null;
});
</script></body>""")
    return source
