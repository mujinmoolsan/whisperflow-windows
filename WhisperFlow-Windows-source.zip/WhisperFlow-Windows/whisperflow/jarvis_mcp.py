"""Shared voice tools for existing GPT/Codex and Claude MCP hosts.

This server does not start a second LLM or need an OpenAI API key. The host
assistant supplies text; the single local Qwen service generates and plays it.
"""
import json
import os
from typing import Literal
import urllib.request
import urllib.error
from pathlib import Path
import subprocess
import sys
import time
from urllib.parse import urlparse

from mcp.server.fastmcp import FastMCP

mcp = FastMCP('Jarvis Shared Voice', host='127.0.0.1', port=8768)
SERVICE_URL = os.getenv('QWEN_TTS_URL', 'http://127.0.0.1:9093').rstrip('/')


def ensure_local_service():
    try:
        request_service('/health', timeout=2)
        return
    except urllib.error.URLError:
        pass
    parsed = urlparse(SERVICE_URL)
    if parsed.hostname not in ('127.0.0.1','localhost') or parsed.port != 9093:
        raise RuntimeError('Start the configured voice server first.')
    root = Path(__file__).resolve().parents[1]
    data = root/'.windows-data'
    data.mkdir(exist_ok=True)
    # Both AI hosts converge on the same loopback port; a second launch exits
    # harmlessly if another client has already started the service.
    with (data/'service.log').open('ab') as log:
        subprocess.Popen([sys.executable, str(root/'launch_qwen_windows.py')], cwd=str(root),
                         stdin=subprocess.DEVNULL, stdout=log, stderr=log,
                         **({'creationflags': subprocess.CREATE_NO_WINDOW} if os.name == 'nt' else {}))
    for _ in range(20):
        time.sleep(.5)
        try:
            request_service('/health', timeout=1)
            return
        except urllib.error.URLError:
            continue
    raise RuntimeError('The local voice service did not start. Check its local service.log.')


def request_service(path, data=None, timeout=300):
    payload = json.dumps(data).encode('utf-8') if data is not None else None
    request = urllib.request.Request(SERVICE_URL + path, data=payload,
                                      headers={'Content-Type': 'application/json'})
    with urllib.request.urlopen(request, timeout=timeout) as response:
        return json.load(response)


@mcp.tool()
def jarvis_status() -> dict:
    """Check the local voice service and installed Jarvis/Deckard references."""
    try:
        return request_service('/health', timeout=3)
    except Exception:
        return {'ready': False, 'message': 'Start the local Qwen voice service first.'}


@mcp.tool()
def jarvis_speak(text: str, language: Literal['ko', 'en'] = 'ko',
                 character: Literal['jarvis', 'deckard'] = 'jarvis', speed: float = 1.0,
                 robot_effect: Literal['default', 'none', 'soft', 'strong'] = 'default') -> dict:
    """Speak your reply aloud on the user's PC in Korean or English.

    Jarvis supports Korean and English. The K-Cops robot police character
    Deckard supports Korean only (not Deckard Cain).
    Call when the user asks for speech. This tool only synthesizes speech;
    it does not execute operating-system commands or grant other tools access.
    A matching local reference recording must be installed for cloned voices.
    """
    if not text.strip() or len(text) > 2000:
        raise ValueError('Text must contain 1–2000 characters.')
    if character == 'deckard' and language != 'ko':
        raise ValueError('Deckard is Korean only. Choose Jarvis for English.')
    if not .5 <= speed <= 2:
        raise ValueError('Speed must be between 0.5 and 2.')
    ensure_local_service()
    effect = ('soft' if character == 'deckard' else 'none') if robot_effect == 'default' else robot_effect
    return request_service('/speak', {'text': text, 'language': language, 'robot_effect': effect,
                           'character': character, 'voice': 'clone:' + character,
                           'speed': speed})


@mcp.tool()
def jarvis_stop() -> dict:
    """Stop local voice playback. A model generation already running may still finish."""
    return request_service('/stop', {}, timeout=3)


if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--http', action='store_true', help='Loopback-only Streamable HTTP transport')
    args = parser.parse_args()
    mcp.run(transport='streamable-http' if args.http else 'stdio')
