"""Server-side GPT adapter. API credentials never go to the browser or Git."""
import asyncio
import json
import os
import urllib.error
import urllib.request


def request_gpt(messages, text, language, model):
    key = os.environ.get('OPENAI_API_KEY', '').strip()
    if not key:
        raise RuntimeError('GPT 연결에는 서버의 OPENAI_API_KEY 설정이 필요합니다. '
                           '키를 채팅이나 GitHub에 올리지 마세요.')
    history = [{'role': msg['role'], 'content': msg['content']} for msg in messages[-16:]
               if msg.get('role') in ('user', 'assistant')]
    payload = {'model': model, 'store': False, 'max_output_tokens': 2048,
               'instructions': 'You are a calm, intelligent voice assistant. Keep answers concise. '
               + ('Answer in natural Korean.' if language == 'ko' else 'Answer in natural English.'),
               'input': history + [{'role': 'user', 'content': text}]}
    request = urllib.request.Request('https://api.openai.com/v1/responses',
        data=json.dumps(payload, ensure_ascii=False).encode('utf-8'),
        headers={'Authorization': 'Bearer ' + key, 'Content-Type': 'application/json'})
    try:
        with urllib.request.urlopen(request, timeout=180) as response:
            result = json.load(response)
    except urllib.error.HTTPError as exc:
        # Do not reflect a remote response body or headers containing account details.
        raise RuntimeError(f'GPT API request failed (HTTP {exc.code}). Check API access, '
                           'model availability and billing in your OpenAI account.') from None
    output = '\n'.join(part['text'] for item in result.get('output', [])
                       if item.get('type') == 'message'
                       for part in item.get('content', []) if part.get('type') == 'output_text')
    if not output:
        raise RuntimeError('GPT returned no readable text. Check model and output limits.')
    return output


async def answer_with_gpt(messages, text, language, model, cwd):
    return await asyncio.to_thread(request_gpt, messages, text, language, model)
