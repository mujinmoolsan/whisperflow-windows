import asyncio
import io
import json
from pathlib import Path
import tempfile
import unittest
import urllib.request
import wave

from websockets.asyncio.client import connect
from websockets.asyncio.server import serve

from whisperflow.windows import WindowsBridge, validate_options, PROFILES
from whisperflow.windows_ui import render_windows_ui


def wav():
    out = io.BytesIO()
    with wave.open(out, 'wb') as f:
        f.setnchannels(1)
        f.setsampwidth(2)
        f.setframerate(24000)
        f.writeframes(b'\0\0' * 240)
    return out.getvalue()


class BridgeTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.directory = tempfile.TemporaryDirectory()
        self.requests = []

        async def answer(messages, text, language, model, cwd):
            self.requests.append((messages, text, language, model))
            return '준비됐습니다.' if language == 'ko' else 'Ready, sir.'

        self.bridge = WindowsBridge(self.directory.name, answer_provider=answer,
                                     tts_provider=lambda text, opts: wav())
        self.server = await serve(self.bridge.handler, '127.0.0.1', 0,
                                  process_request=self.bridge.http)
        self.port = self.server.sockets[0].getsockname()[1]
        self.ws = await connect(f'ws://127.0.0.1:{self.port}', proxy=None)
        await self.ws.recv()
        await self.ws.recv()

    async def asyncTearDown(self):
        await self.ws.close()
        self.server.close()
        await self.server.wait_closed()
        self.directory.cleanup()

    async def receive_until(self, kind):
        seen = []
        for _ in range(15):
            msg = json.loads(await asyncio.wait_for(self.ws.recv(), 3))
            seen.append(msg)
            if msg['type'] == kind:
                return seen
        self.fail('Missing ' + kind)

    async def test_language_controls_answer_and_voice_and_persists_history(self):
        for language in ('en', 'ko'):
            await self.ws.send(json.dumps({'type': 'chat_input', 'tab_id': 'test',
                                          'text': 'AI 1.4', 'language': language,
                                          'engine': 'browser', 'voice': 'default', 'speed': .9}))
            msgs = await self.receive_until('tts_done')
            speech = next(m for m in msgs if m['type'] == 'tts_browser')
            self.assertEqual(speech['language'], language)
            self.assertEqual(speech['speed'], .9)
            self.assertEqual(self.requests[-1][2], language)
            self.assertEqual(self.requests[-1][1], 'AI 1.4')
        await self.ws.send(json.dumps({'type': 'chat_history_request', 'tab_id': 'test'}))
        history = (await self.receive_until('chat_history'))[-1]['messages']
        self.assertEqual(len(history), 4)
        restored = WindowsBridge(self.directory.name)
        self.assertEqual(restored.session('test')['messages'], history)

    async def test_qwen_audio_and_errors_do_not_leak_to_other_client(self):
        async with connect(f'ws://127.0.0.1:{self.port}', proxy=None) as other:
            await other.recv()
            await other.recv()
            await self.ws.send(json.dumps({'type': 'tts_preview', 'language': 'en',
                                          'engine': 'qwen', 'voice': 'design:en'}))
            messages = await self.receive_until('tts_done')
            self.assertTrue(any(m['type'] == 'tts_audio' for m in messages))
            with self.assertRaises(asyncio.TimeoutError):
                await asyncio.wait_for(other.recv(), .1)

    async def test_qwen_failure_is_reported_before_fallback(self):
        def fail(*args):
            raise RuntimeError('test server offline')
        self.bridge.tts = fail
        await self.ws.send(json.dumps({'type': 'tts_preview', 'language': 'ko', 'engine': 'qwen'}))
        msgs = await self.receive_until('tts_done')
        self.assertIn('voice_warning', [m['type'] for m in msgs])
        self.assertIn('tts_browser', [m['type'] for m in msgs])

    async def test_invalid_language_and_non_object_message_are_recoverable(self):
        for message in ('[]', '{bad json', json.dumps({'type': 'tts_preview', 'language': 'xx'})):
            await self.ws.send(message)
            self.assertEqual((await self.receive_until('chat_error'))[-1]['type'], 'chat_error')
        await self.ws.send(json.dumps({'type': 'tts_preview', 'language': 'en'}))
        await self.receive_until('tts_done')

    async def test_static_serves_adapted_page_and_status(self):
        def fetch(path):
            with urllib.request.urlopen(f'http://127.0.0.1:{self.port}' + path) as result:
                return result.read().decode('utf-8')
        page = await asyncio.to_thread(fetch, '/')
        self.assertIn('/windows-language.js', page)
        self.assertIn('...window.JarvisLanguage.options()', page)
        self.assertNotIn("recognition.lang = 'ko-KR'", page)
        status = json.loads(await asyncio.to_thread(fetch, '/api/status'))
        self.assertEqual(status['languages'], ['ko', 'en'])

    async def test_busy_request_does_not_corrupt_first_reply(self):
        async def slow(*args):
            await asyncio.sleep(.1)
            return 'Ready.'
        self.bridge.answer = slow
        request = json.dumps({'type': 'chat_input', 'text': 'hello', 'language': 'en'})
        await self.ws.send(request)
        await self.ws.send(request)
        self.assertIn('wait', (await self.receive_until('chat_error'))[-1]['error'])
        await self.receive_until('tts_done')


class ProfileTests(unittest.TestCase):
    def test_original_english_voice_and_speed_remain_defaults(self):
        opts = validate_options({'language': 'en'})
        self.assertEqual(opts['voice'], PROFILES['en']['voice'])
        self.assertEqual(opts['language'], 'English')
        self.assertEqual(opts['speed'], PROFILES['en']['speed'])

    def test_invalid_speed_rejected(self):
        for speed in (0, 9, float('nan')):
            with self.assertRaises(ValueError):
                validate_options({'speed': speed})


if __name__ == '__main__':
    unittest.main()
