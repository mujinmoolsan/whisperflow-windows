import io
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
import wave

from whisperflow import native_qwen
from whisperflow.voice_effects import robot_effect


def sample():
    import numpy as np
    output = io.BytesIO()
    time = np.arange(4800)/24000
    audio = (.3*np.sin(2*np.pi*220*time)*32767).astype('<i2').tobytes()
    with wave.open(output,'wb') as file:
        file.setnchannels(1)
        file.setsampwidth(2)
        file.setframerate(24000)
        file.writeframes(audio)
    return output.getvalue()


class NativeTests(unittest.TestCase):
    def test_native_command_does_not_use_a_shell_and_keeps_unicode_text_intact(self):
        with tempfile.TemporaryDirectory() as temporary:
            paths = [Path(temporary)/name for name in ('runtime.exe','model.gguf','codec.gguf')]
            for file in paths:
                file.touch()
            def run(command, **kwargs):
                self.assertNotIn('shell',kwargs)
                self.assertEqual(command[command.index('-p')+1], '준비 완료. $(ignored)')
                Path(command[command.index('--output')+1]).write_bytes(sample())
                return type('Result',(),{'returncode':0})()
            with patch('whisperflow.native_qwen.paths',return_value=paths), \
                    patch('subprocess.run',side_effect=run):
                result = native_qwen.generate('준비 완료. $(ignored)',Path('reference.wav'),'ko')
                self.assertEqual(result[:4], b'RIFF')

    def test_soft_effect_is_valid_audio_and_none_preserves_original(self):
        original = sample()
        self.assertEqual(robot_effect(original,'none'), original)
        changed = robot_effect(original,'soft')
        self.assertNotEqual(changed, original)
        with wave.open(io.BytesIO(changed),'rb') as file:
            self.assertEqual(file.getframerate(),24000)
            self.assertEqual(file.getnchannels(),1)
            self.assertGreater(file.getnframes(),4000)
