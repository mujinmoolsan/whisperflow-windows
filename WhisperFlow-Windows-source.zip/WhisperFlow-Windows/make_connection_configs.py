"""Generate private, machine-specific MCP snippets; does not edit app settings."""
import json
from pathlib import Path
from launch_qwen_windows import runtime

ROOT = Path(__file__).resolve().parent

if __name__ == '__main__':
    python = str(runtime()).replace('\\', '/')
    script = str(ROOT / 'run_jarvis_mcp.py').replace('\\', '/')
    destination = ROOT / 'connections-local'
    destination.mkdir(exist_ok=True)
    config = {'mcpServers': {'jarvis_voice': {'command': python, 'args': [script]}}}
    (destination / 'claude-mcp.json').write_text(json.dumps(config, indent=2), encoding='utf-8')
    toml = f"[mcp_servers.jarvis_voice]\ncommand = '{python}'\nargs = ['{script}']\n"
    (destination / 'codex-mcp.toml').write_text(toml, encoding='utf-8')
    print('Prepared local connection snippets. No application settings were changed.')
