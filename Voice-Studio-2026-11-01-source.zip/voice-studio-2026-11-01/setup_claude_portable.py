"""Download the official Windows Claude binary locally and verify its SHA256."""
import hashlib
import json
from pathlib import Path
import urllib.request

ROOT=Path(__file__).resolve().parent
DEST=ROOT/'.native/claude'
BASE='https://downloads.claude.ai/claude-code-releases/'


def main():
    DEST.mkdir(parents=True,exist_ok=True)
    version=urllib.request.urlopen(BASE+'stable',timeout=30).read().decode().strip()
    manifest=json.load(urllib.request.urlopen(BASE+version+'/manifest.json',timeout=30))
    platform=manifest['platforms']['win32-x64']
    target=DEST/'claude.exe'
    if not target.exists() or hashlib.sha256(target.read_bytes()).hexdigest()!=platform['checksum']:
        temporary=DEST/'claude.download'
        digest=hashlib.sha256()
        with urllib.request.urlopen(BASE+version+'/win32-x64/'+platform['binary'],timeout=90) as source, temporary.open('wb') as output:
            while data:=source.read(1024*1024):
                output.write(data)
                digest.update(data)
        if digest.hexdigest()!=platform['checksum']:
            raise RuntimeError('Official Claude binary checksum mismatch.')
        temporary.replace(target)
    (DEST/'release.json').write_text(json.dumps({'version':version,'sha256':platform['checksum'],'source':BASE},indent=2),encoding='utf-8')
    print('Official Claude '+version+' verified and installed in the application folder.')


if __name__=='__main__':
    main()
