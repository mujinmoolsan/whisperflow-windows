import fs from 'node:fs';
import path from 'node:path';
import {stripTypeScriptTypes} from 'node:module';
const base=path.dirname(new URL(import.meta.url).pathname.replace(/^\/([A-Za-z]:)/,'$1'));
const root=decodeURIComponent(base);
let source=fs.readFileSync(path.join(root,'upstream/client/session.ts'),'utf8');
function replace(oldText,newText){if(!source.includes(oldText))throw new Error('Pinned upstream anchor missing: '+oldText.slice(0,70));source=source.replace(oldText,newText);}
const begin=source.indexOf('async function request('),end=source.indexOf('export class BrowserSession');
if(begin<0||end<begin)throw new Error('Pinned request helper not found.');
source=source.slice(0,begin)+`// Local adapter: preserve the existing Python server's request identities and voice gates.
async function request(path: string, _csrf: string, body: any) {
  const creating=path==='/api/sessions';
  const response=await fetch(creating?'/api/live/session':'/api/live/close',{
    method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/json'},
    body:JSON.stringify(creating?{sdp:body.sdp,client_request_id:body.operationId}:{client_request_id:body.operationId}),
    signal:AbortSignal.timeout(45000),
  });
  const result=await response.json();
  if(!response.ok)throw Object.assign(new Error(result.error?.message||result.message||'실시간 연결 요청을 완료하지 못했습니다.'),{code:result.error?.code});
  if(creating)return {id:result.session?.id,sdp:result.transport?.sdp};
  if(result.ignored||(!result.session_id&&result.confirmed))return {type:'cancelled'};
  return closeReceipt(result);
}
function closeReceipt(value: any) {
  const seconds=value.usage?.seconds;
  const finalized=value.confirmed===true&&typeof seconds==='number'&&Number.isFinite(seconds)&&seconds>=0;
  return {type:'closed',finalized,seconds:finalized?seconds:null,inputTokens:0,outputTokens:0,
    reason:value.confirmed?'통화 종료가 확인되었습니다.':'서버의 통화 종료 확인이 필요합니다.'};
}
function normalizeEvent(value: any, sessionId: string): any {
  if(value.session_id&&value.session_id!==sessionId)return null;
  if(value.type==='snapshot'&&value.live?.session_id===sessionId&&value.live.state==='connected')
    return {type:'ready',mode:'client',startedAt:Date.now(),maxSessionSeconds:0};
  if(value.type==='live_transcript')return {type:'transcript',role:value.role,text:value.text,startMs:value.start_ms,endMs:value.end_ms};
  if(value.type==='live_closed')return closeReceipt(value);
  if(value.type==='live_disconnected')return {type:'closing',reason:'실시간 서버 연결이 끊겼습니다.'};
  if(value.type==='live_error'||value.type==='live_protocol_error')return {type:'error',code:value.code||'live_error',message:value.message||'실시간 연결에 문제가 발생했습니다.',action:''};
  return null;
}
`+source.slice(end);
replace('  playbackBlocked(value: boolean): void;','  playbackBlocked(value: boolean): void;\n  output?(stream: MediaStream): void;');
replace("  private operationId = '';","  private operationId = '';\n  private sessionId = '';");
replace('        void this.audio.play().catch(() => this.callbacks.playbackBlocked(true));','        this.callbacks.output?.(this.audio.srcObject as MediaStream);\n        void this.audio.play().catch(() => this.callbacks.playbackBlocked(true));');
replace("      const socketUrl = new URL('/api/events', window.location.href);","      this.sessionId = created.id;\n      const socketUrl = new URL('/ws', window.location.href);");
replace("      socketUrl.searchParams.set('session', created.id);",'      // The existing local websocket supplies a session-identified snapshot.');
replace('          const value = JSON.parse(message.data) as ConsoleEvent;','          const value = normalizeEvent(JSON.parse(message.data), this.sessionId) as ConsoleEvent;\n          if (!value) return;');
replace("    this.setPhase('closing');\n    this.setMuted(true);","    this.setPhase('closing');\n    this.setMuted(true);\n    this.audio.pause(); // Stop local output immediately while the terminal receipt is awaited.");
replace("void fetch('/api/sessions/close', {","void fetch('/api/live/close', {");
replace("body: JSON.stringify({ operationId: this.operationId }),","body: JSON.stringify({ client_request_id: this.operationId }),");
const header=`/* Adapted from OpenAI Live Console, MIT, copyright 2026 OpenAI.
 * Source commit: 5f64ecb3009d8274da9953c825d469ea6b6b67c3
 * Original: https://github.com/openai/openai-live-console/blob/5f64ecb3009d8274da9953c825d469ea6b6b67c3/client/session.ts
 * Local differences: Python HTTP/event boundary, custom-voice readiness outside this class,
 * output-audio callback, immediate local speaker pause. See THIRD_PARTY_NOTICES.md.
 */\n`;
fs.mkdirSync(path.join(root,'..','..','whisperflow/static/vendor'),{recursive:true});
fs.writeFileSync(path.join(root,'adapted-session.ts'),header+source);
fs.writeFileSync(path.join(root,'..','..','whisperflow/static/vendor/openai-live-session.js'),header+stripTypeScriptTypes(source,{mode:'strip'}));
console.log('Official BrowserSession compiled with local boundary adapter.');
