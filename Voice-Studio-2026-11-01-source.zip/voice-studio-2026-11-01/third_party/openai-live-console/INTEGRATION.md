# Official-source integration

Status: integrated into the local application and included in this source snapshot. Session creation remains gated by API and custom-voice readiness. The integration was tested offline; no working end-to-end hosted voice session or latency result is claimed.

The active media transport is built from OpenAI's actual [`client/session.ts`](https://github.com/openai/openai-live-console/blob/5f64ecb3009d8274da9953c825d469ea6b6b67c3/client/session.ts). The existing Python backend remains responsible for selected voices, task execution, and request ownership. This replaces the application's custom browser media loop with the pinned official `BrowserSession`; it is not an unused source-code copy.

## Runtime files

Paths below are relative to the repository root:

| Staged path | Purpose |
| --- | --- |
| `whisperflow/static/vendor/openai-live-session.js` | Adapted official transport class |
| `whisperflow/static/vendor/OPENAI-LIVE-LICENSE.txt` | Complete upstream license |
| `whisperflow/static/live-client.js` | Studio UI/readiness/audio-animation wrapper |
| `whisperflow/static/companion.js` | Existing UI plus closing-state text; merge if visual work changed it |
| `whisperflow/companion.py` | Live status and websocket snapshot contract |
| `whisperflow/live_session.py` | Validated final-usage receipts and safe provenance |

`THIRD_PARTY_NOTICES.md`, `SOURCE.json`, the build script, and immutable upstream source are retained for attribution and rebuilding. `DEPLOYMENT.json` records the original integration-stage hashes; it is historical provenance rather than a manifest of this sanitized shared snapshot.

The HTML retains the classic deferred script order `live-client.js` before `companion.js`. The runtime module is imported only after a user-initiated start passes readiness. When changing this integration, preserve request identity, selected-voice ownership, and the lifecycle checks below.

`window.studioLive` is defined synchronously, preserving the existing companion startup call to `status()`. A failed-readiness status cannot capture audio or create a session. The selected custom voice remains server-owned, and the request body contains only SDP and a request ID. A sideband snapshot must match the created session and the primary data channel must independently report `session.started` before the transport becomes live. Stale terminal events with a different session ID are ignored.

The wrapper emits `studio-speech` events with `{type:'level',character,level}` from the remote audio stream, and `{type:'stop'}` on cleanup. The avatar needs both this live-level input and its existing local-envelope start/stop support. Input microphone energy does not animate the avatar.

## Offline validation

Run from the repository root (the rebuild script requires a Node.js version with `stripTypeScriptTypes`):

```powershell
node third_party/openai-live-console/build-runtime.mjs
node --test tests/web/test_official_browser.cjs
```

Run Python tests from the repository root using the application's prepared Python environment:

```powershell
$env:PYTHONPATH = Join-Path $PWD 'tests'
.\.qwen-env\Scripts\python.exe -m unittest tests.test_live_session tests.test_live_companion tests.test_official_bridge
```

Browser tests execute the actual compiled official class and local wrapper with mocked media/network surfaces. They cover original-source integrity, readiness gates, both startup-event orders, request ownership, cancellation, stale events, disconnection, unload, and finalization. Python tests cover the existing lifecycle/dispatch/readiness behaviors and the new snapshot/receipt boundary. They make no provider calls. Windows' asyncio self-pipe creation required running these offline Python tests outside the restricted sandbox; the tests themselves used mocked transports and direct route invocation.

## What remains unavailable

The user currently has no configured API project/key or registered custom voice IDs. Existing Jarvis/Deckard local voices therefore remain the available local playback option; they are not automatically turned into API voice IDs. The Live mode stays unavailable while these requirements are missing. No built-in replacement voice is selected.

Official sources: [OpenAI Live Console](https://github.com/openai/openai-live-console/tree/5f64ecb3009d8274da9953c825d469ea6b6b67c3), [custom voices documentation](https://developers.openai.com/api/docs/guides/custom-voices). Custom-voice eligibility, voice registration/consent and the selected language's quality must be established separately. API usage is separate from ChatGPT login. No claim of Dot-equivalent latency or working end-to-end Korean custom-voice audio is supported by the offline tests.
