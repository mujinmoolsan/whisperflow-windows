# OpenAI Live Console source reuse

This integration contains source from [openai/openai-live-console](https://github.com/openai/openai-live-console), pinned to commit `5f64ecb3009d8274da9953c825d469ea6b6b67c3` under the MIT License, copyright 2026 OpenAI. The complete license is in `upstream/LICENSE` and the deployed `whisperflow/static/vendor/OPENAI-LIVE-LICENSE.txt`.

`SOURCE.json` records the immutable source URL and SHA-256 of every original file. `upstream/` contains the originals, unchanged. The runtime is **actually derived from `client/session.ts`**: `build-runtime.mjs` adapts its boundaries and strips TypeScript using Node's built-in type stripper. `adapted-session.ts` is the inspectable intermediate; `whisperflow/static/vendor/openai-live-session.js` runs the resulting `BrowserSession` class. It has no third-party runtime package imports.

The reused class implements WebRTC offer/answer setup, ICE gathering, microphone acquisition, data-channel session lifecycle, the two-part startup gate, generation guards, playback recovery, startup/disconnection deadlines, explicit close/final-receipt handling, and page-unload cleanup.

Local modifications:

- Map the sample's `/api/sessions` and `/api/sessions/close` to the application's `/api/live/session` and `/api/live/close`, preserving `operationId` as the existing `client_request_id`.
- Map local `/ws` events and the matching-session snapshot into the sample's normalized events. A sideband-ready snapshot alone does not activate the microphone: the original class still requires the primary `session.started` data-channel event.
- Add an optional output-audio callback for the avatar, and pause local speaker playback immediately when closing starts.
- Keep the existing Python server, request tombstones, selected custom-voice checks, and Codex/Claude work dispatch. The sample's fictional catalog, Node HTTP server, built-in voice, and Responses tool loop are not installed.
- Wrap the official class with the application's existing `window.studioLive` interface. The wrapper checks readiness before media capture/session creation and animates only remote output audio.

The additional upstream server/type/package/README files are reference material, not runtime dependencies. Their presence does not mean the entire original console or all of its server protections were installed. The existing application's loopback/origin checks remain the server boundary.

This is reuse of an official public example, not disclosure of Dot internals or release of an offline voice model. The upstream README explicitly describes the sample as educational and says end-to-end Live compatibility requires verification.
