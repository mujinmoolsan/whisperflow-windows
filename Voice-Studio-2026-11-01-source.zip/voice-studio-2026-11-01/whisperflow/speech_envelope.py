"""Small output-audio envelope for mouth animation; no microphone or models.

This is energy-driven animation, not phoneme recognition. The envelope is built
from the final WAV that is played, after any tempo or robot effect processing.
"""
from array import array
import io
import math
import sys
import wave


def _pcm_samples(raw, width):
    if width == 1:
        # WAV PCM8 is unsigned; zero sound is 128.
        return (value - 128 for value in raw)
    if width in (2, 4):
        values = array('h' if width == 2 else 'i')
        values.frombytes(raw)
        if sys.byteorder != 'little':
            values.byteswap()
        return values
    if width == 3:
        return (int.from_bytes(raw[index:index + 3], 'little', signed=True)
                for index in range(0, len(raw), 3))
    raise ValueError('Mouth animation requires 8/16/24/32-bit PCM WAV.')


def speech_envelope(audio, *, frame_ms=40, max_points=600):
    """Return bounded RMS levels in [0,1] plus the actual frame/audio timing.

    Channel energies are combined, rather than averaging signed samples, so
    stereo phase cancellation cannot incorrectly close the mouth. Long clips
    use wider windows to keep the event small; normal voice segments use 40ms.
    """
    if not 10 <= frame_ms <= 1000 or not 1 <= max_points <= 2000:
        raise ValueError('Invalid envelope sampling settings.')
    with wave.open(io.BytesIO(audio), 'rb') as source:
        width, channels, rate = source.getsampwidth(), source.getnchannels(), source.getframerate()
        frames = source.getnframes()
        if source.getcomptype() != 'NONE' or width not in (1, 2, 3, 4) or channels < 1 or rate < 1:
            raise ValueError('Mouth animation requires uncompressed PCM WAV.')
        window = max(1, round(rate * frame_ms / 1000), math.ceil(frames / max_points))
        full_scale = float(1 << (width * 8 - 1))
        rms = []
        while raw := source.readframes(window):
            count = len(raw) // width
            if not count:
                break
            squares = sum(value * value for value in _pcm_samples(raw, width))
            rms.append(math.sqrt(squares / count) / full_scale)
    # Keep digital silence and near-silence fully shut. Compress the audible
    # range gently so quiet syllables remain visible without binary flapping.
    noise_floor = .002
    peak = max(rms, default=0)
    denominator = max(.04, peak) - noise_floor
    levels = [round(min(1.0, max(0.0, (level - noise_floor) / denominator) ** .7), 4)
              for level in rms]
    return {'envelope': levels, 'frame_ms': round(window * 1000 / rate, 4),
            'duration_ms': round(frames * 1000 / rate, 3)}
