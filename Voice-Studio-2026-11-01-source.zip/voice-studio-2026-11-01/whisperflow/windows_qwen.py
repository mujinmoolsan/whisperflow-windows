"""Optional local Qwen3-TTS VoiceDesign server; no Apple/MLX dependencies.

Starts on loopback. Models load lazily. Existing clone:jarvis can still be used
by pointing QWEN_TTS_URL at the original owner's compatible voice server.
"""
from __future__ import annotations

import argparse
from http.server import BaseHTTPRequestHandler, HTTPServer
import io
import json
import logging
import os
from pathlib import Path
import random
import threading
import subprocess
import tempfile
import time
from http.server import ThreadingHTTPServer

from .windows import PROFILES, ROOT

REFERENCES = ROOT / '.references'


def reference_status():
    return {name: (REFERENCES / (name + '.wav')).is_file() for name in ('jarvis', 'deckard')}


class VoiceDesigner:
    def __init__(self, device='auto'):
        self.model = None
        self.device = device
        self.lock = threading.Lock()
        self.model_kind = None
        self.idle_timer = None
        self.playback_lock = threading.Lock()
        self.playback_generation = 0

    def unload_idle(self):
        if self.lock.acquire(blocking=False):
            try:
                self.model = None
                self.model_kind = None
                import gc
                gc.collect()
                from .approved_voice import stop_worker
                stop_worker()
            finally:
                self.lock.release()

    def schedule_unload(self):
        if self.idle_timer:
            self.idle_timer.cancel()
        self.idle_timer = threading.Timer(300, self.unload_idle)
        self.idle_timer.daemon = True
        self.idle_timer.start()

    def generate(self, data):
        try:
            from . import native_qwen, approved_voice
            voice = data.get('voice', 'clone:jarvis')
            if voice == 'clone:deckard' and data.get('language') not in ('ko','Korean'):
                raise ValueError('Deckard is Korean only. Choose Jarvis for English.')
            code = {'Korean':'ko','English':'en','ko':'ko','en':'en'}.get(data.get('language'))
            preset = approved_voice.profile(voice,code) if code else None
            cache = None
            if preset:
                text = data.get('text','').strip()
                if not text or len(text)>2000:
                    raise ValueError('Text must contain 1–2000 characters.')
                effect = data.get('robot_effect','soft' if voice=='clone:deckard' else 'none')
                cache = approved_voice.cache_file(text,preset,data.get('seed'),effect)
                if cache and cache.is_file():
                    return cache.read_bytes()
                with self.lock:
                    audio = approved_voice.generate(text,preset,data.get('seed'))
            elif native_qwen.available() and voice in ('clone:jarvis', 'clone:deckard'):
                reference = REFERENCES / (voice.split(':')[1] + '.wav')
                if not reference.is_file():
                    raise ValueError('Reference recording is not installed for ' + voice + '.')
                text = data.get('text', '').strip()
                if not text or len(text) > 2000:
                    raise ValueError('Text must contain 1–2000 characters.')
                language = {'Korean': 'ko', 'English': 'en', 'ko':'ko', 'en':'en'}.get(data.get('language'))
                if language is None:
                    raise ValueError('Choose Korean or English.')
                with self.lock:
                    audio = native_qwen.generate(text, reference, language, int(data.get('seed',42)))
            else:
                audio = self._generate(data)
            default_effect = 'soft' if voice == 'clone:deckard' else 'none'
            effect = data.get('robot_effect', default_effect)
            if effect != 'none':
                from .voice_effects import robot_effect
                audio = robot_effect(audio, effect)
            if preset:
                audio = approved_voice.normalize(audio)
                if cache:
                    with tempfile.NamedTemporaryFile(dir=cache.parent,delete=False,suffix='.tmp') as pending:
                        pending.write(audio)
                        temporary=Path(pending.name)
                    os.replace(temporary,cache)
            return audio
        finally:
            self.schedule_unload()

    def _generate(self, data):
        import numpy as np
        import soundfile as sf
        import torch
        from qwen_tts import Qwen3TTSModel

        code = {'Korean': 'ko', 'English': 'en', 'ko': 'ko', 'en': 'en'}.get(data.get('language'), 'ko')
        voice = data.get('voice', 'design:' + code)
        if voice not in ('design:ko', 'design:en', 'clone:jarvis', 'clone:deckard'):
            raise ValueError('Choose design:ko, design:en, clone:jarvis or clone:deckard.')
        is_clone = voice.startswith('clone:')
        if not is_clone:
            code = voice.split(':')[1]
        reference = REFERENCES / (voice.split(':')[1] + '.wav')
        if is_clone and not reference.is_file():
            raise ValueError('Reference recording is not installed for ' + voice + '.')
        text = data.get('text', '').strip()
        if not text or len(text) > 2000:
            raise ValueError('Text must contain 1–2000 characters.')
        with self.lock:
            if self.idle_timer:
                self.idle_timer.cancel()
            kind = 'Base' if is_clone else 'VoiceDesign'
            if self.model is not None and self.model_kind != kind:
                self.model = None
                import gc
                gc.collect()
            if self.model is None:
                device = self.device
                if device == 'auto':
                    device = 'cuda:0' if torch.cuda.is_available() else 'cpu'
                # GTX 1660 does not support bfloat16. SDPA avoids a FlashAttention install.
                # bfloat16 on CPU halves Base-model weights; no GPU driver update is needed.
                # CPU kernels may emulate it on older hardware, so actual speed must be measured.
                dtype = torch.float16 if device.startswith('cuda') else (
                    torch.bfloat16 if is_clone else torch.float32)
                if device == 'cpu':
                    import psutil
                    minimum = 2 if is_clone else 8
                    if psutil.virtual_memory().available < minimum * 2**30:
                        raise RuntimeError(f'At least {minimum} GB of free RAM is required for this '
                                           'CPU mode. Close unused applications and retry.')
                model_id = ('Qwen/Qwen3-TTS-12Hz-0.6B-Base' if is_clone else
                            'Qwen/Qwen3-TTS-12Hz-1.7B-VoiceDesign')
                self.model = Qwen3TTSModel.from_pretrained(
                    model_id, device_map=device,
                    dtype=dtype, attn_implementation='sdpa', low_cpu_mem_usage=True)
                self.model_kind = kind
            seed = int(data.get('seed', 42))
            random.seed(seed)
            np.random.seed(seed)
            torch.manual_seed(seed)
            if is_clone:
                waves, rate = self.model.generate_voice_clone(
                    text=text, language=PROFILES[code]['language'],
                    ref_audio=str(reference), x_vector_only_mode=True,
                    max_new_tokens=min(1024, max(96, len(text) * 6)))
            else:
                waves, rate = self.model.generate_voice_design(
                    text=text, language=PROFILES[code]['language'],
                    instruct=data.get('instruct') or PROFILES[code]['instruct'],
                    max_new_tokens=2048)
            output = io.BytesIO()
            sf.write(output, waves[0], rate, format='WAV', subtype='PCM_16')
            return output.getvalue()


def play_local(audio, speed=1):
    """Local playback, independent of an open browser or which assistant called."""
    if os.name != 'nt':
        raise RuntimeError('Local playback is implemented for Windows.')
    import winsound
    output = ROOT / '.windows-data' / 'speech'
    output.mkdir(parents=True, exist_ok=True)
    destination = output / 'last-speech.wav'
    if speed != 1:
        import imageio_ffmpeg
        with tempfile.TemporaryDirectory() as temporary:
            source, target = Path(temporary) / 'input.wav', Path(temporary) / 'output.wav'
            source.write_bytes(audio)
            subprocess.run([imageio_ffmpeg.get_ffmpeg_exe(), '-v', 'error', '-i', str(source),
                            '-af', f'atempo={speed}', '-y', str(target)], check=True,
                           capture_output=True, timeout=30, creationflags=subprocess.CREATE_NO_WINDOW)
            audio = target.read_bytes()
    destination.write_bytes(audio)
    from .speech_envelope import speech_envelope
    # Analyze the exact output (including speed/effects) before playback starts.
    mouth = speech_envelope(audio)
    playback_started = time.monotonic()
    winsound.PlaySound(str(destination), winsound.SND_FILENAME | winsound.SND_ASYNC)
    import wave
    with wave.open(io.BytesIO(audio),'rb') as recording:
        seconds=recording.getnframes()/recording.getframerate()
    return {'accepted': True, 'playing': True, 'duration_seconds':seconds,
            'playback_started_monotonic':playback_started, **mouth}


def make_handler(designer):
    class Handler(BaseHTTPRequestHandler):
        def respond(self, code, body, content_type='application/json'):
            self.send_response(code)
            self.send_header('Content-Type', content_type)
            self.send_header('Content-Length', str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def do_GET(self):
            if self.path == '/health':
                from .approved_voice import status as approved_status
                self.respond(200, json.dumps({'ready': True, 'loaded': designer.model is not None,
                    'lip_sync': True,
                    'references': reference_status(),
                    'voices': ['clone:jarvis', 'clone:deckard', 'design:ko', 'design:en'],
                    **approved_status()}).encode())
            else:
                self.respond(404, b'{"error":"Not found"}')

        def do_POST(self):
            host = self.headers.get('Host', '').split(':')[0]
            origin = self.headers.get('Origin')
            if host not in ('127.0.0.1', 'localhost') or (
                origin is not None and origin not in ('http://127.0.0.1:8767', 'http://localhost:8767')):
                self.respond(403, b'{"error":"Local requests only"}')
                return
            if self.headers.get('Content-Type', '').split(';')[0] != 'application/json':
                self.respond(415, b'{"error":"Use application/json"}')
                return
            if self.path not in ('/generate', '/speak', '/stop', '/warmup'):
                self.respond(404, b'{"error":"Not found"}')
                return
            try:
                size = int(self.headers.get('Content-Length', 0))
                if not 0 < size <= 20000:
                    raise ValueError('Invalid request size.')
                data = json.loads(self.rfile.read(size))
                if self.path == '/warmup':
                    from .approved_voice import profile,prepare
                    preset=profile(data.get('voice','clone:deckard'),data.get('language','ko'))
                    if preset:
                        with designer.lock:
                            prepare(preset)
                        designer.schedule_unload()
                    self.respond(200,b'{"ready":true}')
                    return
                if self.path == '/stop':
                    import winsound
                    with designer.playback_lock:
                        designer.playback_generation += 1
                        winsound.PlaySound(None, 0)
                    from .approved_voice import stop_worker
                    stop_worker(only_busy=True)
                    from .native_qwen import stop_pending
                    stop_pending()
                    self.respond(200, b'{"stopped":true}')
                    return
                if self.path == '/speak':
                    speed = float(data.get('speed', 1))
                    if not .5 <= speed <= 2:
                        raise ValueError('Invalid speed.')
                    with designer.playback_lock:
                        designer.playback_generation += 1
                        generation = designer.playback_generation
                    audio = designer.generate(data)
                    with designer.playback_lock:
                        if generation != designer.playback_generation:
                            self.respond(200, b'{"accepted":true,"playing":false,"cancelled":true}')
                            return
                        result = play_local(audio, speed)
                    self.respond(200, json.dumps(result).encode())
                else:
                    self.respond(200, designer.generate(data), 'audio/wav')
            except Exception as exc:
                logging.exception('Voice generation failed')
                self.respond(500, json.dumps({'error': str(exc)}).encode())
    return Handler


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--port', type=int, default=9093)
    parser.add_argument('--device', default='auto')
    parser.add_argument('--sample', choices=['ko', 'en'])
    args = parser.parse_args()
    # Keep model cache beside the application, not in the user's home directory.
    os.environ.setdefault('HF_HOME', str(ROOT / '.models'))
    designer = VoiceDesigner(args.device)
    if args.sample:
        code = args.sample
        text = ('시스템 점검을 마쳤습니다. 모든 기능이 정상입니다.' if code == 'ko'
                else 'System checks are complete. Everything is operating normally.')
        audio = designer.generate({'text': text, 'voice': 'design:' + code,
                                   'language': PROFILES[code]['language']})
        destination = ROOT / 'samples'
        destination.mkdir(exist_ok=True)
        file = destination / f'voice-{code}.wav'
        file.write_bytes(audio)
        print(file)
        return
    print(f'Qwen VoiceDesign: http://127.0.0.1:{args.port}', flush=True)
    ThreadingHTTPServer(('127.0.0.1', args.port), make_handler(designer)).serve_forever()


if __name__ == '__main__':
    main()
