"""Local Windows microphone → GPT/Claude → desktop → selected voice companion."""
import argparse
import asyncio
import base64
import contextlib
import hashlib
import hmac
import io
import json
import os
from pathlib import Path
import re
import secrets
import subprocess
import sys
import tempfile
import time
import uuid
import wave
import webbrowser
from urllib.parse import quote

from aiohttp import web,ClientSession,ClientTimeout
from .agent_runner import AgentRunner,connection_status,executable
from .desktop_actions import Desktop
from .voice_commands import parse_command,short_message
from .speech_worker import SpeechWorker
from .speech_segments import segments
from .live_session import LiveSessionManager,LiveError,readiness

ROOT=Path(__file__).resolve().parents[1]
STATIC=ROOT/'whisperflow/static'


class Companion:
    def __init__(self,port=8770,data_dir=None):
        self.port=port
        self.url=f'http://127.0.0.1:{port}'
        self.data=Path(data_dir or ROOT/'.windows-data/companion')
        self.data.mkdir(exist_ok=True,parents=True)
        self.settings_path=self.data/'settings.json'
        self.settings={'character':'jarvis','language':'ko','provider':'codex','desktop_enabled':True,
                       'voice_enabled':True,'workspace':str(ROOT/'workspace')}
        if self.settings_path.exists():
            self.settings.update(json.loads(self.settings_path.read_text(encoding='utf-8')))
        Path(self.settings['workspace']).mkdir(exist_ok=True,parents=True)
        self.jobs=[]
        self.history=[]
        for path in sorted((self.data/'jobs').glob('*/job.json'),key=lambda value:value.stat().st_mtime)[-30:]:
            try:
                saved=json.loads(path.read_text(encoding='utf-8'))
                job=saved.get('job',saved)
                if job['status'] in ('queued','running'):
                    job['status']='cancelled'
                job['directory']=path.parent
                job['task']={'workspace':saved.get('workspace',self.settings['workspace'])}
                self.jobs.append(job)
                if job.get('reply'):
                    self.history += [{'role':'user','content':job['text']},{'role':'assistant','content':job['reply']}]
            except (ValueError,KeyError,OSError):
                continue
        self.history=self.history[-24:]
        self.clients=set()
        self.queue=asyncio.Queue()
        self.runner=AgentRunner()
        self.speech_worker=SpeechWorker(ROOT)
        self.desktop=Desktop()
        self.desktop_token=secrets.token_urlsafe(32)
        self.active=None
        self.active_task=None
        self.voice_tasks=set()
        self.voice_lock=asyncio.Lock()
        self.confirmations={}
        self.armed_until=0
        self.connections={}
        self.login_processes={}
        self.voice_busy=False
        self.job_waiters={}
        self.validated_jobs=set()
        self.job_transition_lock=asyncio.Lock()
        self.live=LiveSessionManager(self.dispatch_live,self.emit_live)

    def public_job(self,job):
        return {key:value for key,value in job.items() if key not in ('task','directory')}

    async def emit_live(self,event):
        await self.broadcast(event['type'],**{key:value for key,value in event.items() if key!='type'})

    def live_status(self):
        value=self.live.status()
        value['readiness']=readiness(self.settings['character'],self.settings['language'],self.live.env)
        value['implementation']={'source':'openai/openai-live-console',
            'commit':'5f64ecb3009d8274da9953c825d469ea6b6b67c3'}
        return value

    def resolve_job(self,job):
        future=self.job_waiters.get(job['id'])
        if future and not future.done():
            # This marks a finalized result from our existing runner contract.
            # It is not independent proof of an external action or draft text.
            future.set_result({'status':job['status'],'reply':job.get('reply',''),
                'artifacts':list(job.get('artifacts',[])),
                'verified':job['status']=='completed' and job['id'] in self.validated_jobs})

    async def dispatch_live(self,text,context):
        identity=uuid.uuid4().hex
        try:
            conversation=[{'role':part['role'],'content':part['text'][:500]} for part in
                context.get('transcripts',[])[-24:] if isinstance(part,dict)
                and part.get('role') in ('user','assistant') and isinstance(part.get('text'),str)]
            submitted=await self.submit({'text':text,**{key:context[key] for key in
                ('character','language','provider')}},voice_output='live',job_id=identity,conversation=conversation)
            if submitted.get('action')!='queued':
                return {'status':'needs_input','reply':'요청할 작업 내용을 말씀해 주세요.','verified':False}
            return await asyncio.shield(self.job_waiters[identity])
        except asyncio.CancelledError:
            await self.cancel_job(identity)
            raise
        finally:
            future=self.job_waiters.pop(identity,None)
            if future and not future.done():
                future.cancel()
            self.validated_jobs.discard(identity)

    async def cancel_job(self,identity):
        async with self.job_transition_lock:
            job=next((item for item in self.jobs if item['id']==identity),None)
            if not job or job['status'] not in ('queued','running'):
                return
            job['status']='cancelled'
            job['reply']=short_message(job['character'],'stopped',job['language'])
            if self.active is job and self.active_task:
                execution=self.active_task
                execution.cancel()
                await self.runner.stop()
                await asyncio.gather(execution,return_exceptions=True)
            self.resolve_job(job)
            await self.broadcast('job',job=self.public_job(job))
            (job['directory']/'job.json').write_text(json.dumps({'job':self.public_job(job),
                'workspace':job['task']['workspace']},ensure_ascii=False,indent=2),encoding='utf-8')

    async def broadcast(self,kind,**data):
        message={'type':kind,**data}
        stale=[]
        for socket in list(self.clients):
            try:
                await socket.send_json(message)
            except (ConnectionError,RuntimeError):
                stale.append(socket)
        for socket in stale:
            self.clients.discard(socket)

    async def status(self,refresh=False):
        if refresh or not self.connections:
            gpt,claude=await asyncio.gather(connection_status('codex'),connection_status('claude'))
            self.connections={'codex':gpt,'claude':claude}
        return {'settings':self.settings,'connections':self.connections,
                'jobs':[self.public_job(job) for job in self.jobs[-30:]],
                'active_job':self.active['id'] if self.active else None,'voice_busy':self.voice_busy}

    def save_settings(self):
        self.settings_path.write_text(json.dumps(self.settings,ensure_ascii=False,indent=2),encoding='utf-8')

    async def submit(self,data,*,voice_output='local',job_id=None,conversation=None):
        text=data.get('text','')
        if not isinstance(text,str) or not 1<=len(text.strip())<=12000:
            raise web.HTTPBadRequest(text='명령을 입력해 주세요. 최대 12,000자입니다.')
        values={**self.settings,**{key:data[key] for key in ('character','language','provider') if key in data}}
        if values['character'] not in ('jarvis','deckard') or values['language'] not in ('ko','en') or values['provider'] not in ('codex','claude'):
            raise web.HTTPBadRequest(text='지원하지 않는 음성 또는 실행 도구입니다.')
        parsed=parse_command(text,values['character'],values['language'],values['provider'],
                             bool(data.get('require_wake')),time.monotonic()<self.armed_until)
        if not parsed['accepted']:
            return parsed
        for key in ('character','language','provider'):
            self.settings[key]=parsed[key]
        self.save_settings()
        await self.broadcast('settings',settings=self.settings)
        if parsed['action']=='stop':
            await self.stop()
            return parsed
        if parsed['action']=='wake':
            self.armed_until=time.monotonic()+20
            if voice_output!='live':
                self.schedule_voice(short_message(parsed['character'],'wake',parsed['language']),parsed)
            await self.broadcast('heard',text=text,reply='명령을 말씀해 주세요.')
            return parsed
        self.armed_until=0
        if self.voice_tasks:
            await self.stop_voice()
        job_id=job_id or uuid.uuid4().hex
        directory=self.data/'jobs'/job_id
        directory.mkdir(parents=True)
        task={**parsed,'id':job_id,'desktop_enabled':self.settings['desktop_enabled'],
              'workspace':self.settings['workspace'],'voice_output':voice_output}
        if conversation is not None:
            task['conversation']=conversation
        job={'id':job_id,'text':parsed['text'],'character':parsed['character'],'language':parsed['language'],
             'provider':parsed['provider'],'status':'queued','reply':'','artifacts':[],
             'created':time.time(),'task':task,'directory':directory}
        self.jobs.append(job)
        if voice_output=='live':
            self.job_waiters[job_id]=asyncio.get_running_loop().create_future()
        self.queue.put_nowait(job)
        await self.broadcast('job',job=self.public_job(job))
        return {'accepted':True,'action':'queued','job_id':job_id,**{key:parsed[key] for key in ('character','language','provider')}}

    async def work(self):
        while True:
            job=await self.queue.get()
            async with self.job_transition_lock:
                if job['status']=='cancelled':
                    self.resolve_job(job)
                    self.queue.task_done()
                    continue
                self.active=job
                self.active_task=asyncio.create_task(self.execute(job))
            try:
                await self.active_task
            except asyncio.CancelledError:
                job['status']='cancelled'
                job['reply']=short_message(job['character'],'stopped',job['language'])
                await self.broadcast('job',job=self.public_job(job))
                if asyncio.current_task().cancelling():
                    raise
            except Exception as error:
                job['status']='failed'
                job['reply']=short_message(job['character'],'failed',job['language'])
                job['detail']=str(error)[:800]
                await self.broadcast('job',job=self.public_job(job))
                if job['task'].get('voice_output')!='live':
                    self.schedule_voice(job['reply'],job)
            finally:
                try:
                    (job['directory']/'job.json').write_text(json.dumps({'job':self.public_job(job),'workspace':job['task']['workspace']},ensure_ascii=False,indent=2),encoding='utf-8')
                finally:
                    self.resolve_job(job)
                    self.active=None
                    self.active_task=None
                    self.queue.task_done()

    async def execute(self,job):
        job['status']='running'
        await self.broadcast('job',job=self.public_job(job))
        task=job['task']
        direct=re.fullmatch(r'(계산기|메모장|그림판|탐색기|크롬)(?:를|을)?\s*(?:열어|켜|실행해)\s*(?:줘|주세요)?[.!?\s]*',task['text'])
        if direct and task['desktop_enabled']:
            name={'계산기':'calculator','메모장':'notepad','그림판':'paint','탐색기':'explorer','크롬':'chrome'}[direct.group(1)]
            await asyncio.to_thread(self.desktop.open_app,name)
            reply=(f'친구야, {direct.group(1)}를 열었어.' if task['character']=='deckard' else f'{direct.group(1)}를 실행했습니다.')
            result={'status':'completed','reply':reply,'artifacts':[]}
        else:
            async def progress(text):
                if isinstance(text,dict) and 'reply_draft' in text:
                    job['draft']=text['reply_draft']
                    job.setdefault('first_text_seconds',round(time.time()-job['created'],2))
                    await self.broadcast('reply_draft',job_id=job['id'],text=job['draft'],character=job['character'])
                else:
                    await self.broadcast('progress',job_id=job['id'],text=text)
            history=self.history+task.get('conversation',[])
            result=await self.runner.run(task,history,Path(task['workspace']),job['directory'],
                                         self.url,self.desktop_token,progress)
        if not isinstance(result,dict) or result.get('status') not in ('completed','needs_input','failed') or not isinstance(result.get('reply'),str):
            raise RuntimeError('The task runner did not return a validated final result.')
        job.update(result)
        if job['task'].get('voice_output')=='live':
            self.validated_jobs.add(job['id'])
        job.pop('draft',None)
        job['response_seconds']=round(time.time()-job['created'],2)
        if job['character']=='deckard' and not job['reply'].startswith('친구야'):
            job['reply']='친구야, '+job['reply'].replace('해 주세요','해 줘').replace('확인해 주십시오','확인해 줘')
        self.history += [{'role':'user','content':task['text']},{'role':'assistant','content':job['reply']}]
        self.history=self.history[-24:]
        await self.broadcast('job',job=self.public_job(job))
        spoken=re.sub(r'[`*#]','',job['reply']).strip()
        if len(spoken)>180:
            spoken=short_message(job['character'],'completed' if job['status']=='completed' else 'failed',job['language'])
        if job['task'].get('voice_output')!='live':
            self.schedule_voice(spoken,job)

    def schedule_voice(self,text,options):
        if not self.settings['voice_enabled']:
            return
        previous=list(self.voice_tasks)
        async def latest():
            if previous:
                await self.stop_voice(previous)
            parts = segments(text)
            await self.speak_segments(parts, options)
        task=asyncio.create_task(latest())
        self.voice_tasks.add(task)
        task.add_done_callback(self.voice_tasks.discard)

    async def prefetch_voice(self, text, options):
        """Generate silently into the existing exact-text cache during playback."""
        try:
            url=os.environ.get('QWEN_TTS_URL','http://127.0.0.1:9093').rstrip('/')
            async with ClientSession(timeout=ClientTimeout(total=1800)) as client:
                async with client.post(url+'/generate',json={'text':text,
                    'voice':'clone:'+options['character'],'language':options['language'],
                    'robot_effect':'soft' if options['character']=='deckard' else 'none'}) as response:
                    await response.read()
        except Exception:
            pass  # speak() retries and reports an actionable error.

    async def speak_segments(self, parts, options):
        pending = None
        try:
            for index, part in enumerate(parts):
                if pending:
                    await pending
                    pending = None
                async def playing():
                    nonlocal pending
                    if index+1 < len(parts):
                        pending=asyncio.create_task(self.prefetch_voice(parts[index+1],options))
                await self.speak(part, options, on_playing=playing, last=index==len(parts)-1)
        finally:
            if pending:
                pending.cancel()
                await asyncio.gather(pending,return_exceptions=True)
            self.voice_busy=False
            await self.broadcast('voice_done')

    async def speak(self,text,options,on_playing=None,last=True):
        async with self.voice_lock:
            self.voice_busy=True
            played=False
            await self.broadcast('voice_pending',text=text,character=options['character'])
            started=time.monotonic()
            try:
                from .jarvis_mcp import ensure_local_service
                await asyncio.to_thread(ensure_local_service)
                url=os.environ.get('QWEN_TTS_URL','http://127.0.0.1:9093').rstrip('/')
                async with ClientSession(timeout=ClientTimeout(total=1800)) as client:
                    async with client.post(url+'/speak',json={'text':text,'voice':'clone:'+options['character'],
                              'character':options['character'],'language':options['language'],'speed':1,
                              'robot_effect':'soft' if options['character']=='deckard' else 'none'}) as response:
                        result=await response.json()
                        if response.status!=200 or not result.get('playing'):
                            raise RuntimeError(result.get('error','음성 재생이 중지되었습니다.'))
                seconds=float(result.get('duration_seconds',max(2,len(text)/5)))
                preparation=round(time.monotonic()-started,2)
                animation={key:result[key] for key in ('envelope','frame_ms','duration_ms') if key in result}
                playback_started=result.get('playback_started_monotonic')
                if isinstance(playback_started,(int,float)):
                    animation['playback_offset_ms']=max(0,round((time.monotonic()-playback_started)*1000,2))
                await self.broadcast('voice_playing',text=text,seconds=seconds,
                    preparation_seconds=preparation,character=options['character'],**animation)
                job=next((item for item in self.jobs if item['id']==options.get('id')),None)
                if job:
                    job.setdefault('voice_preparation_seconds',preparation)
                    job.setdefault('first_audio_seconds',round(time.time()-job['created'],2))
                    await self.broadcast('job',job=self.public_job(job))
                    (job['directory']/'job.json').write_text(json.dumps({'job':self.public_job(job),'workspace':job['task']['workspace']},ensure_ascii=False,indent=2),encoding='utf-8')
                if on_playing:
                    await on_playing()
                await asyncio.sleep(min(seconds+.1,180))
                played=True
            except asyncio.CancelledError:
                raise
            except Exception as error:
                await self.broadcast('notice',text='음성을 재생하지 못했습니다. '+str(error)[:200])
            finally:
                self.voice_busy=not last
                if played and options.get('action')=='wake':
                    self.armed_until=time.monotonic()+20
                if last:
                    await self.broadcast('voice_done')

    async def stop_voice(self,tasks=None):
        pending=list(self.voice_tasks) if tasks is None else tasks
        for task in pending:
            task.cancel()
        await asyncio.gather(*pending,return_exceptions=True)
        try:
            async with ClientSession(timeout=ClientTimeout(total=3)) as client:
                async with client.post(os.environ.get('QWEN_TTS_URL','http://127.0.0.1:9093').rstrip('/')+'/stop',json={}):
                    pass
        except Exception:
            pass

    async def stop(self):
        self.armed_until=0
        if self.active_task:
            self.active_task.cancel()
        await self.runner.stop()
        for job in self.jobs:
            if job['status']=='queued':
                job['status']='cancelled'
                job['reply']=short_message(job['character'],'stopped',job['language'])
                self.resolve_job(job)
                await self.broadcast('job',job=self.public_job(job))
        await self.stop_voice()
        for future in self.confirmations.values():
            if not future.done():
                future.set_result(False)
        await self.broadcast('stopped')

    async def desktop_request(self,data):
        job=self.active
        if not job or job['id']!=data.get('job_id') or job['status']!='running' or not job['task']['desktop_enabled']:
            raise web.HTTPForbidden(text='현재 작업에 화면 조작이 허용되지 않았습니다.')
        action=data.get('action')
        if action=='confirm':
            future=asyncio.get_running_loop().create_future()
            confirmation=uuid.uuid4().hex
            self.confirmations[confirmation]=future
            await self.broadcast('confirmation',id=confirmation,question=str(data.get('question',''))[:2000],job_id=job['id'])
            try:
                approved=await asyncio.wait_for(future,600)
                return {'approved':approved}
            finally:
                self.confirmations.pop(confirmation,None)
        await self.broadcast('progress',job_id=job['id'],text='화면을 확인하고 있습니다.' if action=='observe' else '화면에서 작업하고 있습니다.')
        try:
            if action=='observe':
                return await asyncio.to_thread(self.desktop.observe)
            return await asyncio.to_thread(self.desktop.action,data)
        except (ValueError,RuntimeError,OSError) as error:
            raise web.HTTPBadRequest(text=str(error))

    async def cleanup(self,app):
        preparation=getattr(self,'preparation',None)
        if preparation:
            preparation.cancel()
            await asyncio.gather(preparation,return_exceptions=True)
        await self.live.close(cancel_jobs=True)
        await self.stop()
        await self.runner.close()
        await self.speech_worker.close()
        await asyncio.gather(*list(self.voice_tasks),return_exceptions=True)
        self.worker.cancel()
        with contextlib.suppress(asyncio.CancelledError):
            await self.worker

    def app(self):
        @web.middleware
        async def local_only(request,handler):
            if request.host.split(':')[0] not in ('127.0.0.1','localhost'):
                raise web.HTTPForbidden()
            origin=request.headers.get('Origin')
            if origin and origin not in (self.url,f'http://localhost:{self.port}'):
                raise web.HTTPForbidden()
            if request.path=='/api/desktop':
                token=request.headers.get('Authorization','').removeprefix('Bearer ')
                if not hmac.compare_digest(token,self.desktop_token):
                    raise web.HTTPForbidden()
            return await handler(request)
        app=web.Application(middlewares=[local_only],client_max_size=3*1024*1024)

        async def home(request):
            return web.FileResponse(STATIC/'companion.html',headers={'Cache-Control':'no-store'})
        async def status(request):
            return web.json_response(await self.status(request.query.get('refresh')=='1'))
        async def command(request):
            return web.json_response(await self.submit(await request.json()))
        async def live_status(request):
            return web.json_response(self.live_status())
        async def live_request(request):
            try:
                data=await request.json()
            except (ValueError,UnicodeError):
                raise web.HTTPBadRequest(text='브라우저 연결 정보를 읽지 못했습니다.')
            if not isinstance(data,dict):
                raise web.HTTPBadRequest(text='브라우저 연결 정보를 읽지 못했습니다.')
            identity=data.get('client_request_id')
            if not isinstance(identity,str) or not re.fullmatch(r'[A-Za-z0-9_-]{8,128}',identity):
                raise web.HTTPBadRequest(text='대화 요청 식별자가 필요합니다. 화면을 새로고침해 주세요.')
            return data
        async def live_session(request):
            data=await live_request(request)
            check=readiness(self.settings['character'],self.settings['language'],self.live.env)
            if not check['ready']:
                return web.json_response({'error':{'code':'not_ready',
                    'message':' '.join(item['message'] for item in check['reasons'])},
                    'readiness':check},status=409)
            try:
                answer=await self.live.create(data.get('sdp'),character=self.settings['character'],
                    language=self.settings['language'],provider=self.settings['provider'],history=self.history,
                    client_request_id=data['client_request_id'])
                return web.json_response(answer)
            except LiveError as error:
                status=409 if error.code in ('not_ready','session_exists','request_cancelled') else 400 if error.code in ('invalid_sdp','invalid_request_id') else 502
                return web.json_response({'error':error.public()},status=status)
        async def live_close(request):
            data=await live_request(request)
            return web.json_response(await self.live.close(cancel_jobs=True,client_request_id=data['client_request_id']))
        async def settings(request):
            data=await request.json()
            selected={key:data.get(key,self.settings[key]) for key in ('character','language','provider')}
            if selected['character']=='deckard':
                selected['language']='ko'
            if selected['character'] not in ('jarvis','deckard') or selected['language'] not in ('ko','en') or selected['provider'] not in ('codex','claude'):
                raise web.HTTPBadRequest(text='지원하지 않는 설정입니다.')
            if 'workspace' in data:
                folder=Path(data['workspace']).expanduser().resolve()
                if not folder.is_absolute() or str(folder)==folder.anchor:
                    raise web.HTTPBadRequest(text='작업할 폴더를 지정해 주세요.')
                folder.mkdir(exist_ok=True,parents=True)
                self.settings['workspace']=str(folder)
            for key in ('voice_enabled','desktop_enabled'):
                if key in data:
                    self.settings[key]=bool(data[key])
            self.settings.update(selected)
            self.save_settings()
            await self.broadcast('settings',settings=self.settings)
            return web.json_response({'ok':True})
        async def stop(request):
            await self.live.close(cancel_jobs=True)
            await self.stop()
            return web.json_response({'stopped':True})
        async def socket(request):
            ws=web.WebSocketResponse(heartbeat=25)
            await ws.prepare(request)
            self.clients.add(ws)
            await ws.send_json({'type':'snapshot',**await self.status(),'live':self.live_status()})
            try:
                async for _ in ws:
                    pass
            finally:
                self.clients.discard(ws)
            return ws
        async def desktop(request):
            return web.json_response(await self.desktop_request(await request.json()))
        async def approval(request):
            data=await request.json()
            future=self.confirmations.get(data.get('id'))
            if not future or future.done():
                raise web.HTTPNotFound()
            future.set_result(data.get('approved') is True)
            return web.json_response({'ok':True})
        async def artifact(request):
            job=next((item for item in self.jobs if item['id']==request.query.get('job')),None)
            try:
                selected=job['artifacts'][int(request.query.get('index','-1'))]
            except (TypeError,KeyError,ValueError,IndexError):
                raise web.HTTPNotFound()
            workspace=Path(job['task']['workspace']).resolve()
            file=Path(selected)
            file=(file if file.is_absolute() else workspace/file).resolve()
            if not file.is_relative_to(workspace) or not file.is_file():
                raise web.HTTPForbidden(text='이 작업 폴더 안의 결과 파일만 받을 수 있습니다.')
            return web.FileResponse(file,headers={'Content-Disposition':"attachment; filename*=UTF-8''"+quote(file.name)})
        async def connect(request):
            provider=request.match_info['provider']
            if provider not in ('codex','claude'):
                raise web.HTTPNotFound()
            path=executable(provider)
            if not path:
                raise web.HTTPBadRequest(text='실행 도구가 설치되지 않았습니다.')
            existing=self.login_processes.get(provider)
            if existing and existing.poll() is None:
                return web.json_response({'opened':True,'already_open':True})
            state=await connection_status(provider)
            self.connections[provider]=state
            if state.get('logged_in'):
                self.runner.auth_cache.pop(provider,None)
                return web.json_response({'opened':False,'already_connected':True})
            try:
                self.login_processes[provider]=subprocess.Popen(
                    [sys.executable,'-u','-m','whisperflow.login_console',provider,path],cwd=str(ROOT),
                    creationflags=subprocess.CREATE_NEW_CONSOLE if os.name=='nt' else 0)
            except OSError:
                raise web.HTTPBadRequest(text='로그인 창을 열지 못했습니다. 실행 도구 경로와 실행 권한을 확인해 주세요.')
            return web.json_response({'opened':True})
        async def open_browser(request):
            candidates=[Path(os.environ.get('PROGRAMFILES','C:/Program Files'))/'Google/Chrome/Application/chrome.exe',
                        Path(os.environ.get('PROGRAMFILES(X86)','C:/Program Files (x86)'))/'Google/Chrome/Application/chrome.exe',
                        Path(os.environ.get('LOCALAPPDATA',''))/'Google/Chrome/Application/chrome.exe']
            chrome=next((path for path in candidates if path.is_file()),None)
            if not chrome:
                raise web.HTTPBadRequest(text='Chrome 실행 파일을 찾지 못했습니다. 이 주소를 Chrome이나 Edge에서 열어 주세요: '+self.url)
            subprocess.Popen([str(chrome),self.url],stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
            return web.json_response({'opened':True})
        async def transcribe(request):
            body=await request.read()
            if len(body)<44 or body[:4]!=b'RIFF' or body[8:12]!=b'WAVE':
                raise web.HTTPBadRequest(text='마이크 녹음을 읽지 못했습니다.')
            with tempfile.TemporaryDirectory(dir=self.data) as temporary:
                source,output=Path(temporary)/'command.wav',Path(temporary)/'transcript.json'
                source.write_bytes(body)
                started=time.monotonic()
                try:
                    result=await self.speech_worker.transcribe(source,output)
                except asyncio.TimeoutError:
                    raise web.HTTPRequestTimeout(text='음성 인식 시간이 초과되었습니다.')
                except (RuntimeError,ValueError,OSError) as error:
                    (self.data/'speech-error.log').write_text(str(error),encoding='utf-8')
                    raise web.HTTPBadRequest(text='음성 인식을 완료하지 못했습니다. 마이크 입력을 확인해 주세요.')
                result['recognition_seconds']=round(time.monotonic()-started,2)
                return web.json_response(result)
        async def startup(app):
            self.worker=asyncio.create_task(self.work())
            async def prepare_voice():
                if not self.settings['voice_enabled']:
                    return
                try:
                    from .jarvis_mcp import ensure_local_service
                    await asyncio.to_thread(ensure_local_service)
                    async with ClientSession(timeout=ClientTimeout(total=120)) as client:
                        async with client.post(os.environ.get('QWEN_TTS_URL','http://127.0.0.1:9093').rstrip('/')+'/warmup',
                            json={'voice':'clone:'+self.settings['character'],'language':self.settings['language']}) as response:
                            await response.read()
                except Exception:
                    # Warm-up is optional; speak() reports actionable failures.
                    pass
            self.preparation=asyncio.create_task(prepare_voice())
        app.add_routes([web.get('/',home),web.get('/api/status',status),web.post('/api/command',command),
             web.get('/api/live/status',live_status),web.post('/api/live/session',live_session),
             web.post('/api/live/close',live_close),
             web.post('/api/settings',settings),web.post('/api/stop',stop),web.get('/ws',socket),
             web.post('/api/desktop',desktop),web.post('/api/approval',approval),
             web.get('/api/artifact',artifact),
             web.post('/api/connect/{provider}',connect),web.post('/api/transcribe',transcribe),
             web.post('/api/open-browser',open_browser),
             web.static('/static/',STATIC)])
        app.on_startup.append(startup)
        app.on_cleanup.append(self.cleanup)
        return app


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--port',type=int,default=8770)
    parser.add_argument('--no-open',action='store_true')
    args=parser.parse_args()
    config=ROOT/'windows-config.json'
    if config.exists():
        values=json.loads(config.read_text(encoding='utf-8-sig'))
        for key in ('HF_HOME','QWEN_TTS_URL','JARVIS_CODEX_PATH','JARVIS_CLAUDE_PATH'):
            if values.get(key):
                os.environ[key]=str(values[key])
    os.environ.setdefault('HF_HOME',str(ROOT/'.models'))
    companion=Companion(args.port)
    if not args.no_open:
        webbrowser.open(companion.url)
    web.run_app(companion.app(),host='127.0.0.1',port=args.port,print=lambda _:None)


if __name__=='__main__':
    main()
