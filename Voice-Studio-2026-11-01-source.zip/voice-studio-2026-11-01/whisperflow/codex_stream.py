"""Persistent stdio transport for authenticated Codex, with visible reply deltas."""
import asyncio
import contextlib
import json
import os
from pathlib import Path
import re
import subprocess
import tomllib


def partial_reply(value):
    """Decode only the reply JSON string; never display schema or reasoning."""
    match=re.search(r'"reply"\s*:\s*"',value)
    if not match:
        return ''
    start=match.end()-1
    try:
        text,_=json.JSONDecoder().raw_decode(value[start:])
        return text if isinstance(text,str) else ''
    except ValueError:
        content=value[start+1:]
        # Drop an unfinished escape sequence until the next chunk arrives.
        content=re.sub(r'\\(?:u[0-9a-fA-F]{0,3})?$','',content)
        try:
            return json.loads('"'+content+'"')
        except ValueError:
            return ''


class CodexStream:
    def __init__(self,path):
        self.path=path
        self.process=None
        self.pending={}
        self.events={}
        self.next_id=0
        self.reader=None
        self.errors=None
        self.active=None
        self.start_lock=asyncio.Lock()

    async def start(self):
        async with self.start_lock:
            if self.process and self.process.returncode is None:
                return
            command=[self.path,'app-server','--stdio']
            # This app exposes only its own per-job desktop server, not the user's
            # unrelated MCPs. Keep credentials and global settings untouched.
            config=Path(os.environ.get('CODEX_HOME',Path.home()/'.codex'))/'config.toml'
            try:
                names=tomllib.loads(config.read_text(encoding='utf-8')).get('mcp_servers',{})
            except (OSError,ValueError):
                names={}
            for name in names:
                command+=['-c',f'mcp_servers.{name}.enabled=false']
            command+=['-c','model_reasoning_effort="low"']
            self.process=await asyncio.create_subprocess_exec(*command,stdin=asyncio.subprocess.PIPE,
                stdout=asyncio.subprocess.PIPE,stderr=asyncio.subprocess.PIPE,limit=8*1024*1024,
                **({'creationflags':subprocess.CREATE_NO_WINDOW} if os.name=='nt' else {}))
            self.reader=asyncio.create_task(self.read())
            self.errors=asyncio.create_task(self.drain_errors())
            await self.call('initialize',{'clientInfo':{'name':'whisperflow','title':'음성 작업실','version':'0.2.0'}})
            await self.send({'method':'initialized'})

    async def drain_errors(self):
        self.last_error=b''
        while chunk:=await self.process.stderr.read(4096):
            self.last_error=(self.last_error+chunk)[-16000:]

    async def send(self,value):
        self.process.stdin.write((json.dumps(value,ensure_ascii=False)+'\n').encode('utf-8'))
        await self.process.stdin.drain()

    async def call(self,method,params):
        self.next_id+=1
        request_id=self.next_id
        future=asyncio.get_running_loop().create_future()
        self.pending[request_id]=future
        try:
            await self.send({'id':request_id,'method':method,'params':params})
            return await asyncio.wait_for(future,90)
        finally:
            self.pending.pop(request_id,None)

    async def read(self):
        try:
            async for line in self.process.stdout:
                try:
                    message=json.loads(line)
                except ValueError:
                    continue
                if 'id' in message and 'method' not in message:
                    future=self.pending.get(message['id'])
                    if future and not future.done():
                        if 'error' in message:
                            future.set_exception(RuntimeError(str(message['error'])))
                        else:
                            future.set_result(message.get('result',{}))
                elif 'id' in message:
                    # Automatic review handles ordinary approvals. Never silently
                    # approve an unexpected request at the transport layer.
                    await self.send({'id':message['id'],'error':{'code':-32601,
                        'message':'This request needs user interaction in the companion.'}})
                else:
                    queue=self.events.get(message.get('params',{}).get('threadId'))
                    if queue:
                        queue.put_nowait(message)
        finally:
            for future in self.pending.values():
                if not future.done():
                    future.set_exception(RuntimeError('GPT connection closed.'))
            for queue in self.events.values():
                queue.put_nowait({'method':'connection/closed'})

    async def run(self,task,prompt,folder,job_dir,desktop,schema,progress):
        await self.start()
        config={'model_reasoning_effort':'low'}
        if task['desktop_enabled']:
            config['mcp_servers.whisperflow_desktop']={**desktop,'enabled':True,'tool_timeout_sec':600}
        started=await self.call('thread/start',{'cwd':str(folder),'sandbox':'workspace-write',
            'approvalPolicy':'on-request','approvalsReviewer':'auto_review','ephemeral':True,'config':config})
        thread=started['thread']['id']
        queue=asyncio.Queue()
        self.events[thread]=queue
        final_text=''
        accumulated={}
        self.active=(thread,None)
        try:
            turn=await self.call('turn/start',{'threadId':thread,'input':[{'type':'text','text':prompt}],
                'effort':'low','outputSchema':schema})
            self.active=(thread,turn['turn']['id'])
            async with asyncio.timeout(1800):
                while True:
                    event=await queue.get()
                    method,params=event['method'],event.get('params',{})
                    if method=='item/agentMessage/delta':
                        key=params['itemId']
                        accumulated[key]=accumulated.get(key,'')+params['delta']
                        draft=partial_reply(accumulated[key])
                        if draft:
                            await progress({'reply_draft':draft})
                    elif method=='item/completed':
                        item=params.get('item',{})
                        if item.get('type')=='agentMessage' and item.get('phase')!='commentary':
                            final_text=item.get('text','')
                    elif method=='item/started' and params.get('item',{}).get('type') in ('commandExecution','mcpToolCall','fileChange'):
                        await progress('작업을 실행하고 있습니다.')
                    elif method=='turn/completed':
                        status=params['turn']['status']
                        if status!='completed':
                            raise RuntimeError('GPT turn '+status)
                        break
                    elif method=='connection/closed':
                        raise RuntimeError('GPT connection closed.')
            result=json.loads(final_text)
            (job_dir/'result.json').write_text(json.dumps(result,ensure_ascii=False),encoding='utf-8')
            return result
        except (asyncio.CancelledError,TimeoutError):
            await self.stop()
            raise
        finally:
            self.active=None
            self.events.pop(thread,None)
            (job_dir/'runner-error.log').write_bytes(getattr(self,'last_error',b''))
            with contextlib.suppress(Exception):
                await self.call('thread/archive',{'threadId':thread})

    async def stop(self):
        if self.active and self.active[1] and self.process and self.process.returncode is None:
            with contextlib.suppress(Exception):
                await self.call('turn/interrupt',{'threadId':self.active[0],'turnId':self.active[1]})

    async def close(self):
        await self.stop()
        if self.process and self.process.returncode is None:
            if os.name=='nt':
                killer=await asyncio.create_subprocess_exec('taskkill','/PID',str(self.process.pid),'/T','/F',
                    stdout=asyncio.subprocess.DEVNULL,stderr=asyncio.subprocess.DEVNULL,
                    creationflags=subprocess.CREATE_NO_WINDOW)
                await killer.wait()
            else:
                self.process.terminate()
            await self.process.wait()
        for task in (self.reader,self.errors):
            if task:
                task.cancel()
                with contextlib.suppress(asyncio.CancelledError):
                    await task
