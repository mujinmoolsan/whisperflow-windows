/* Layered electron-cloud hologram. Cached turbulent density textures and luminous
 * curling filaments, not a point/line wireframe. Passive studio-speech events only: no microphone,
 * API requests or audio synthesis. Its motion preference is local to this app. */
(() => {
  'use strict';
  const orb=document.getElementById('orb');
  if(!orb||orb.querySelector('.neuralCanvas'))return;
  const canvas=document.createElement('canvas');canvas.className='neuralCanvas';
  canvas.setAttribute('aria-hidden','true');orb.append(canvas);
  const ctx=canvas.getContext('2d',{alpha:true});if(!ctx)return;
  const motion=matchMedia('(prefers-reduced-motion: reduce)');
  const preferenceKey='jarvisMotionPreference';
  let preference=null;
  try{const saved=localStorage.getItem(preferenceKey);if(saved==='on'||saved==='off')preference=saved;}catch{}
  const motionEnabled=()=>preference==='on'||(preference!=='off'&&!motion.matches);
  const toggle=document.createElement('button');toggle.type='button';toggle.className='jarvisMotionToggle';
  toggle.setAttribute('aria-label','자비스 계속 움직임');
  toggle.style.cssText='position:absolute;right:2px;bottom:2px;z-index:3;border:1px solid #4f8daa77;border-radius:20px;padding:6px 10px;background:#071c2be8;color:#aedbed;font-size:11px;line-height:1.2;font-family:inherit;letter-spacing:.01em;cursor:pointer;pointer-events:auto;box-shadow:0 2px 9px #0003';
  // The old stage was entirely decorative. The explicit control must be reachable.
  orb.removeAttribute('aria-hidden');orb.append(toggle);
  function syncToggle(){
    const enabled=motionEnabled();toggle.setAttribute('aria-pressed',String(enabled));
    toggle.textContent=enabled?'움직임 끄기':'움직임 켜기';toggle.hidden=!selected();toggle.style.display=selected()?'':'none';
  }
  function toggleMotion(){
    preference=motionEnabled()?'off':'on';
    try{localStorage.setItem(preferenceKey,preference);}catch{}
    resume();
  }
  toggle.addEventListener('click',toggleMotion);
  const TAU=Math.PI*2;
  let seed=74397;
  const random=()=>{seed=(seed*16807)%2147483647;return(seed-1)/2147483646;};
  const clouds=[],filaments=[],dust=[];
  const hash=(x,y,s)=>{const n=Math.sin(x*127.1+y*311.7+s*73.7)*43758.5453;return n-Math.floor(n);};
  function noise(x,y,s){
    const ix=Math.floor(x),iy=Math.floor(y),fx=x-ix,fy=y-iy;
    const u=fx*fx*(3-2*fx),v=fy*fy*(3-2*fy);
    const a=hash(ix,iy,s),b=hash(ix+1,iy,s),c=hash(ix,iy+1,s),d=hash(ix+1,iy+1,s);
    return(a+(b-a)*u)*(1-v)+(c+(d-c)*u)*v;
  }
  function density(x,y,s){return noise(x,y,s)*.58+noise(x*2.1,y*2.1,s+7)*.28+noise(x*4.3,y*4.3,s+13)*.14;}
  // Generate turbulent density once. Per-frame work only scales cached sprites.
  const textures=Array.from({length:3},(_,variant)=>{
    const image=document.createElement('canvas');image.width=image.height=128;
    const paint=image.getContext('2d'),pixels=paint.createImageData(128,128);
    for(let y=0;y<128;y++)for(let x=0;x<128;x++){
      const nx=(x-64)/64,ny=(y-64)/64,r=Math.sqrt(nx*nx+ny*ny);
      const curl=noise(nx*2.1+4,ny*2.1+4,variant)*2.8;
      const field=density(nx*3.2+curl,ny*3.2-curl,variant+11);
      const veil=Math.max(0,1-r*r);const edge=veil*veil;
      const vein=Math.pow(Math.max(0,1-Math.abs(field-.53)*15),3);
      const volume=Math.pow(Math.max(0,field-.20),1.25);
      const i=(y*128+x)*4;
      pixels.data[i]=45+vein*155;pixels.data[i+1]=155+vein*95;pixels.data[i+2]=244+vein*11;
      pixels.data[i+3]=Math.min(255,edge*(volume*.92+vein*.94)*255);
    }
    paint.putImageData(pixels,0,0);return image;
  });
  for(let i=0;i<64;i++){
    const a=random()*TAU,z=random()*2-1,w=Math.sqrt(1-z*z),r=.10+Math.cbrt(random())*.82;
    clouds.push({x:Math.cos(a)*w*r,y:z*r,z:Math.sin(a)*w*r,phase:random()*TAU,scale:.90+random()*.62,spin:(random()-.5)*.18,texture:i%3});
  }
  for(let i=0;i<24;i++)filaments.push({phase:random()*TAU,tilt:random()*TAU,radius:.32+random()*.72,speed:.12+random()*.18,length:.6+random()*1.5,roll:random()*TAU});
  for(let i=0;i<90;i++){
    const a=random()*TAU,z=random()*2-1,w=Math.sqrt(1-z*z),r=.72+random()*.50;
    dust.push({x:Math.cos(a)*w*r,y:z*r,z:Math.sin(a)*w*r,phase:random()*TAU});
  }
  const projectedClouds=clouds.map(()=>({x:0,y:0,z:0,scale:1,rotation:0,alpha:0,texture:0}));
  let size=300,dpr=1,time=0,raf=0,lastTick=0,lastDraw=-Infinity;
  let visible=true,destroyed=false,active=false,speech=null,liveAt=-Infinity,liveLevel=0,energy=0;
  const frameMs=1000/24;
  const selected=()=>!orb.classList.contains('deckard');
  const canAnimate=()=>!destroyed&&selected()&&!document.hidden&&visible&&motionEnabled();
  const clamp=x=>Math.max(0,Math.min(1,x));
  function voiceLevel(now){
    if(speech){
      const elapsed=now-speech.started;
      if(elapsed>=speech.duration){speech=null;return 0;}
      const step=elapsed/speech.step,i=Math.floor(step),a=speech.values[i]||0,b=speech.values[i+1]??a;
      return a+(b-a)*(step-i);
    }
    return now-liveAt<180?liveLevel:0;
  }
  function projection(x,y,z,az,tilt,radius,center){
    const ca=Math.cos(az),sa=Math.sin(az),ct=Math.cos(tilt),st=Math.sin(tilt);
    const xx=x*ca+z*sa,zz=z*ca-x*sa,yy=y*ct-zz*st,depth=zz*ct+y*st;
    const perspective=3.8/(3.8-depth);
    return{x:center+xx*radius*perspective,y:center+yy*radius*perspective,z:depth,scale:perspective};
  }
  function draw(now=performance.now(),dt=0){
    if(destroyed||!selected()||document.hidden||!visible)return;
    const state=orb.classList.contains('listening')?1:orb.classList.contains('working')?.6:0;
    const target=motionEnabled()?voiceLevel(now):0;
    energy+=(target-energy)*(dt>0?1-Math.exp(-dt/.10):1);
    const activity=Math.max(state*.45,energy);
    const radius=size*.32,center=size/2,az=time*.13,tilt=.16+Math.sin(time*.21)*.12;
    ctx.globalAlpha=1;ctx.globalCompositeOperation='source-over';ctx.clearRect(0,0,size,size);
    const atmosphere=ctx.createRadialGradient(center,center,0,center,center,radius*1.6);
    atmosphere.addColorStop(0,`rgba(12,123,222,${.19+activity*.07})`);
    atmosphere.addColorStop(.5,'rgba(11,101,190,.10)');atmosphere.addColorStop(1,'rgba(0,44,95,0)');
    ctx.fillStyle=atmosphere;ctx.fillRect(0,0,size,size);
    for(let i=0;i<clouds.length;i++){
      const n=clouds[i],p=projectedClouds[i];
      const breath=1+Math.sin(time*.77+n.phase)*.07+activity*.035;
      const twist=Math.sin(time*.48+n.y*2.9)*.18;
      const x=(n.x*Math.cos(twist)+n.z*Math.sin(twist))*breath;
      const z=(n.z*Math.cos(twist)-n.x*Math.sin(twist))*breath;
      Object.assign(p,projection(x,n.y*breath+Math.sin(time*.58+n.phase)*.055,z,az,tilt,radius,center));
      p.rotation=n.phase+time*n.spin;p.texture=n.texture;
      p.spriteSize=radius*n.scale*(1+activity*.035)*p.scale;
      p.alpha=(.54+(.5+.5*Math.sin(time*.64+n.phase))*.17)*(1+activity*.15);
    }
    const depthOrder=projectedClouds.slice().sort((a,b)=>a.z-b.z);
    ctx.globalCompositeOperation='lighter';
    // Overlapping translucent density lobes make a continuous, irregular volume.
    // The texture has dark pockets and luminous ridges, never a filled solid disc.
    for(const p of depthOrder){
      ctx.save();ctx.translate(p.x,p.y);ctx.rotate(p.rotation);ctx.globalAlpha=p.alpha;
      ctx.drawImage(textures[p.texture],-p.spriteSize/2,-p.spriteSize/2,p.spriteSize,p.spriteSize);ctx.restore();
    }
    ctx.globalAlpha=1;
    // Large curling tendrils cross and disappear into the cloud at different depths.
    for(let i=0;i<filaments.length;i++){
      const f=filaments[i],path=[],phase=f.phase+time*f.speed*(i%2?-1:1);
      const swell=1+Math.sin(time*.71+f.phase)*.06+activity*.025;
      let meanDepth=0;
      for(let j=0;j<=40;j++){
        const s=j/40,a=phase+s*f.length,r=f.radius*swell*(.94+Math.sin(s*9+time*.43+f.phase)*.14);
        const x=Math.cos(a)*r,y=Math.sin(a)*r;
        const wobble=Math.sin(a*2.4+f.roll+time*.52)*.095;
        const p=projection(x,y*Math.cos(f.tilt)+wobble,y*Math.sin(f.tilt),az,tilt,radius,center);
        path.push(p);meanDepth+=p.z;
      }
      meanDepth/=path.length;
      const brightness=.025+clamp((meanDepth+1)*.5)*.055+activity*.03;
      ctx.beginPath();ctx.moveTo(path[0].x,path[0].y);for(let j=1;j<path.length;j++)ctx.lineTo(path[j].x,path[j].y);
      ctx.strokeStyle=`rgba(30,168,255,${brightness*.65})`;ctx.lineWidth=3.0+size*.005;ctx.stroke();
      ctx.strokeStyle=`rgba(110,224,255,${brightness})`;ctx.lineWidth=1.15+size*.0009;ctx.stroke();
      if(i%3===0){ctx.strokeStyle=`rgba(207,249,255,${brightness*.9})`;ctx.lineWidth=.55;ctx.stroke();}
      // A short concentrated pulse flows along each tendril, with soft shoulders.
      if(i%2===0){
        const lead=Math.floor(((time*.38+f.phase/TAU)%1)*31),tail=Math.min(40,lead+8);
        ctx.beginPath();ctx.moveTo(path[lead].x,path[lead].y);for(let j=lead+1;j<=tail;j++)ctx.lineTo(path[j].x,path[j].y);
        ctx.strokeStyle=`rgba(177,243,255,${brightness*1.5})`;ctx.lineWidth=1.15;ctx.stroke();
      }
    }
    // Sparse drifting sparks sit outside the cloud, subordinate to its flowing body.
    for(let i=0;i<dust.length;i++){
      const n=dust[i],p=projection(n.x+Math.sin(time*.49+n.phase)*.045,n.y+Math.cos(time*.57+n.phase)*.04,n.z,az,tilt,radius,center);
      const alpha=(.07+clamp((p.z+1.3)/2.6)*.20)*(.7+.3*Math.sin(time*1.4+n.phase));
      ctx.fillStyle=`rgba(140,225,255,${alpha})`;ctx.beginPath();ctx.arc(p.x,p.y,.48*p.scale,0,TAU);ctx.fill();
    }
    ctx.globalAlpha=1;ctx.globalCompositeOperation='source-over';
  }

  function loop(now){
    raf=0;if(!canAnimate())return;
    const elapsed=lastTick?Math.min(.1,Math.max(0,(now-lastTick)/1000)):0;lastTick=now;time+=elapsed;
    if(now-lastDraw>=frameMs){
      const drawDt=Number.isFinite(lastDraw)?Math.min(.1,(now-lastDraw)/1000):frameMs/1000;
      lastDraw=Number.isFinite(lastDraw)?now-((now-lastDraw)%frameMs):now;draw(now,drawDt);
    }
    raf=requestAnimationFrame(loop);
  }
  function stop(){if(raf)cancelAnimationFrame(raf);raf=0;lastTick=0;}
  function resume(){
    stop();if(destroyed)return;
    syncToggle();
    const next=selected();if(next!==active){active=next;speech=null;liveAt=-Infinity;energy=0;}
    if(!selected()||document.hidden||!visible)return;
    draw();if(canAnimate()){lastDraw=-Infinity;raf=requestAnimationFrame(loop);}
  }
  function resize(){
    size=Math.max(1,Math.min(orb.clientWidth,orb.clientHeight));dpr=Math.min(devicePixelRatio||1,1.5);
    canvas.width=Math.round(size*dpr);canvas.height=Math.round(size*dpr);ctx.setTransform(dpr,0,0,dpr,0,0);resume();
  }
  function onSpeech(event){
    const d=event.detail||{};
    if(d.type==='stop'){speech=null;liveAt=-Infinity;liveLevel=0;return;}
    if(!selected()||d.character!=='jarvis')return;
    if(d.type==='level'){speech=null;liveAt=performance.now();liveLevel=Number.isFinite(d.level)?clamp(d.level):0;}
    if(d.type==='start'&&Array.isArray(d.envelope)){
      const values=d.envelope.slice(0,6000).map(v=>Number.isFinite(v)?clamp(v):0);
      const step=Number.isFinite(d.frame_ms)?Math.max(10,Math.min(10000,d.frame_ms)):40;
      const duration=Number.isFinite(d.duration_ms)?Math.max(0,d.duration_ms):values.length*step;
      speech={values,step,duration,started:performance.now()-(Number.isFinite(d.offset_ms)?Math.max(0,d.offset_ms):0)};liveAt=-Infinity;
    }
  }
  const observer=new ResizeObserver(resize);observer.observe(orb);
  const characters=new MutationObserver(resume);characters.observe(orb,{attributes:true,attributeFilter:['class']});
  const intersection=new IntersectionObserver(entries=>{visible=entries[0].isIntersecting;resume();});intersection.observe(orb);
  document.addEventListener('visibilitychange',resume);motion.addEventListener('change',resume);
  window.addEventListener('studio-speech',onSpeech);window.addEventListener('pageshow',resume);
  window.addEventListener('pagehide',event=>{
    stop();if(event.persisted)return;destroyed=true;observer.disconnect();intersection.disconnect();characters.disconnect();
    document.removeEventListener('visibilitychange',resume);motion.removeEventListener('change',resume);
    window.removeEventListener('studio-speech',onSpeech);window.removeEventListener('pageshow',resume);
    toggle.removeEventListener('click',toggleMotion);
  });
  resize();resume();
})();
