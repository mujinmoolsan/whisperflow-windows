/* Small procedural 3D armor props, built from geometry (not downloaded artwork).
 * Decorative only: no microphone, network, model loading or synthetic telemetry.
 * The fixed camera aligns the three figures with the existing 1983 × 793 room.
 */
import * as THREE from './vendor/three.module.js';

const room = document.querySelector('.commandArea');
const orb = document.getElementById('orb');
if (room && orb && !room.querySelector('.armorDisplay')) installArmorDisplay(room, orb);

function installArmorDisplay(host, avatar) {
  const canvas = document.createElement('canvas');
  canvas.className = 'armorDisplay';
  canvas.setAttribute('aria-hidden', 'true');
  host.prepend(canvas);
  let renderer;
  try {
    renderer = new THREE.WebGLRenderer({ canvas, alpha: true, antialias: true, powerPreference: 'low-power' });
    renderer.setClearColor(0x000000, 0);
    renderer.setPixelRatio(1);
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.7;
  } catch { canvas.remove(); return; }

  const scene = new THREE.Scene();
  const camera = new THREE.OrthographicCamera(0, 285, 793, 0, .1, 1000);
  camera.position.z = 500;
  scene.add(new THREE.HemisphereLight(0xccecff, 0x33251c, 2.1));
  const key = new THREE.DirectionalLight(0xfff1d5, 4.4); key.position.set(120, 600, 300); scene.add(key);
  const rim = new THREE.DirectionalLight(0x64dfff, 3.1); rim.position.set(-200, 300, 140); scene.add(rim);
  const fill = new THREE.DirectionalLight(0xffffff, 1.3); fill.position.set(400, 250, 230); scene.add(fill);

  const materials = [];
  const material = options => { const m = new THREE.MeshStandardMaterial({ roughness: .30, metalness: .68, ...options }); materials.push(m); return m; };
  const joint = material({ color: 0x10191e, metalness: .42, roughness: .48 });
  const inner = material({ color: 0x44555b, roughness: .32 });
  const light = material({ color: 0xdfffff, emissive: 0x81eaff, emissiveIntensity: 2.4, metalness: .0 });
  const trim = material({ color: 0x99b9c5, metalness: .75 });
  const figures = [];

  // Bake static parts by material to keep the three detailed props inexpensive.
  function bake(group) {
    const buckets = new Map(); group.updateMatrixWorld(true);
    for (const mesh of [...group.children]) {
      if (!mesh.isMesh) continue;
      mesh.updateMatrix();
      let geometry = mesh.geometry.clone().applyMatrix4(mesh.matrix);
      if (geometry.index) { const flat = geometry.toNonIndexed(); geometry.dispose(); geometry = flat; }
      const bucket = buckets.get(mesh.material) || []; bucket.push(geometry); buckets.set(mesh.material, bucket);
      mesh.geometry.dispose(); group.remove(mesh);
    }
    for (const [mat, parts] of buckets) {
      const length = parts.reduce((n, geo) => n + geo.attributes.position.array.length, 0);
      const positions = new Float32Array(length), normals = new Float32Array(length);
      let offset = 0;
      for (const geo of parts) { positions.set(geo.attributes.position.array, offset); normals.set(geo.attributes.normal.array, offset); offset += geo.attributes.position.array.length; geo.dispose(); }
      const geometry = new THREE.BufferGeometry();
      geometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
      geometry.setAttribute('normal', new THREE.BufferAttribute(normals, 3));
      group.add(new THREE.Mesh(geometry, mat));
    }
  }
  function mesh(group, geo, mat, x, y, z, rx = 0, ry = 0, rz = 0) {
    const m = new THREE.Mesh(geo, mat); m.position.set(x, y, z); m.rotation.set(rx, ry, rz); group.add(m); return m;
  }
  function box(g, m, x, y, z, w, h, d, rz = 0) { return mesh(g, new THREE.BoxGeometry(w, h, d), m, x, y, z, 0, 0, rz); }
  function oval(g, m, x, y, z, w, h, d) { const a = mesh(g, new THREE.SphereGeometry(1, 12, 8), m, x, y, z); a.scale.set(w, h, d); return a; }
  function plate(g, m, coords, depth, x, y, z, bevel = .04) {
    const s = new THREE.Shape(); coords.forEach(([px, py], i) => i ? s.lineTo(px, py) : s.moveTo(px, py)); s.closePath();
    const geometry = new THREE.ExtrudeGeometry(s, { depth, bevelEnabled: bevel > 0, bevelSize: bevel, bevelThickness: bevel, bevelSegments: 1, steps: 1, curveSegments: 1 });
    return mesh(g, geometry, m, x, y, z);
  }
  function disc(g, m, x, y, z, radius, thick = .04, segments = 20) {
    return mesh(g, new THREE.CylinderGeometry(radius, radius, thick, segments), m, x, y, z, Math.PI / 2);
  }
  const torsoOutline = [[-.82,.5],[-.38,.65],[.38,.65],[.82,.5],[.7,-.15],[.47,-.45],[-.47,-.45],[-.7,-.15]];

  function armor({ x, floor, scale, silver = false, triangle = false, turn = 0 }) {
    const root = new THREE.Group(), body = new THREE.Group(), head = new THREE.Group(), rightWrist = new THREE.Group();
    root.position.set(x, 793 - floor, 10); root.scale.set(scale * .77, scale, scale); root.rotation.y = turn;
    root.add(body, head, rightWrist); scene.add(root);
    const red = material({ color: silver ? 0x9baeb9 : 0x8d1417, metalness: .72, roughness: .26 });
    const gold = material({ color: silver ? 0xd1d7d8 : 0xd8ab49, metalness: .76, roughness: .31 });
    const darkRed = material({ color: silver ? 0x677d89 : 0x4a1216, metalness: .68, roughness: .35 });
    oval(body, joint, 0, 5.12, 0, .69, 1.1, .37);
    plate(body, red, torsoOutline, .43, 0, 5.95, -.16, .08);
    for (const sign of [-1, 1]) {
      plate(body, red, [[0,.35],[.61,.31],[.65,.03],[.35,-.13],[0,-.05]], .13, sign * .07, 6.08, .35, .04).scale.x = sign;
      plate(body, gold, [[0,.28],[.22,.22],[.23,-.26],[0,-.36]], .05, sign * .51, 5.3, .3, .02).scale.x = sign;
      oval(body, joint, sign * .84, 6.02, 0, .33, .30, .32);
      oval(body, red, sign * .99, 6.16, .01, .41, .34, .40);
      box(body, darkRed, sign * .99, 6.37, .02, .56, .11, .55, sign * -.15);
      oval(body, gold, sign * 1.05, 5.46, .03, .25, .52, .27);
      box(body, red, sign * 1.18, 5.56, .04, .16, .64, .42, sign * .08);
      oval(body, joint, sign * 1.08, 4.91, .02, .23, .23, .25);
      disc(body, inner, sign * 1.08, 4.91, .27, .14, .05, 12);
      const forearmGroup = sign === 1 ? rightWrist : body;
      const offset = sign === 1 ? 4.7 : 0;
      if (sign === 1) rightWrist.position.y = offset;
      oval(forearmGroup, darkRed, sign * 1.11, 4.37 - offset, .03, .28, .54, .29);
      plate(forearmGroup, red, [[-.23,.48],[.23,.48],[.3,.03],[.20,-.47],[-.19,-.47],[-.29,.03]], .18, sign * 1.11, 4.36 - offset, .17, .035);
      box(forearmGroup, gold, sign * 1.11, 4.31 - offset, .39, .10, .53, .028);
      oval(forearmGroup, joint, sign * 1.10, 3.80 - offset, .03, .18, .13, .19);
      box(forearmGroup, red, sign * 1.10, 3.58 - offset, .07, .36, .38, .26);
      for (let i = 0; i < 4; i++) box(forearmGroup, darkRed, sign * 1.1 + (i - 1.5) * .078, 3.36 - offset, .08, .062, .18, .19);
      oval(body, joint, sign * .43, 3.52, -.02, .35, .39, .35);
      oval(body, gold, sign * .44, 2.92, -.01, .32, .71, .33);
      plate(body, gold, [[-.27,.60],[.27,.60],[.24,-.46],[.13,-.64],[-.13,-.64],[-.24,-.46]], .12, sign * .44, 2.98, .25, .03);
      box(body, red, sign * .69, 3.03, .03, .15, 1.15, .38, sign * -.03);
      oval(body, joint, sign * .43, 2.16, -.02, .29, .23, .28);
      plate(body, red, [[-.27,.19],[.27,.19],[.25,-.13],[0,-.29],[-.25,-.13]], .18, sign * .43, 2.16, .22, .03);
      oval(body, darkRed, sign * .43, 1.25, 0, .31, .80, .31);
      plate(body, red, [[-.27,.71],[.27,.71],[.25,.15],[.17,-.67],[-.19,-.67],[-.25,.15]], .16, sign * .43, 1.26, .22, .045);
      box(body, gold, sign * .43, 1.43, .42, .055, .9, .025);
      box(body, joint, sign * .43, .43, .03, .37, .19, .45);
      box(body, red, sign * .43, .22, .17, .58, .32, .88);
      box(body, darkRed, sign * .43, .065, .22, .59, .085, .91);
      box(body, red, sign * .43, .4, .15, .45, .24, .56);
    }
    oval(body, joint, 0, 3.92, -.01, .62, .38, .34);
    plate(body, red, [[-.62,.31],[.62,.31],[.47,-.2],[.15,-.37],[-.15,-.37],[-.47,-.2]], .25, 0, 3.99, .1, .04);
    for (let i = 0; i < 4; i++) {
      const y = 5.5 - i * .30, width = .61 - Math.abs(i - 1) * .045;
      plate(body, i % 2 ? darkRed : red, [[-width,.12],[width,.12],[width-.09,-.12],[0,-.17],[-width+.09,-.12]], .12, 0, y, .31, .025);
    }
    box(body, gold, 0, 4.28, .42, .18, .09, .025);
    oval(body, joint, 0, 6.7, 0, .22, .25, .23);
    head.position.set(0, 7.18, .015);
    oval(head, red, 0, .02, 0, .43, .58, .43);
    plate(head, gold, [[-.32,.36],[-.18,.44],[.18,.44],[.32,.36],[.34,.04],[.25,-.31],[.13,-.46],[-.13,-.46],[-.25,-.31],[-.34,.04]], .055, 0, 0, .343, .025);
    plate(head, gold, [[-.10,.17],[.10,.17],[.15,-.15],[0,-.23],[-.15,-.15]], .04, 0, 0, .40, .01);
    for (const sign of [-1, 1]) {
      plate(head, joint, [[.075,.12],[.32,.15],[.29,.045],[.09,.045]], .01, 0, 0, .43, 0).scale.x = sign;
      plate(head, light, [[.09,.105],[.302,.126],[.278,.068],[.103,.065]], .012, 0, 0, .445, 0).scale.x = sign;
      box(head, darkRed, sign * .405, .04, -.02, .095, .40, .30);
    }
    box(head, joint, 0, -.306, .432, .24, .023, .018);
    box(head, gold, 0, -.36, .41, .17, .07, .04);
    if (triangle) {
      plate(body, trim, [[-.23,.15],[.23,.15],[0,-.25]], .04, 0, 6.05, .56, .025);
      plate(body, light, [[-.16,.10],[.16,.10],[0,-.17]], .03, 0, 6.05, .62, 0);
    } else {
      disc(body, darkRed, 0, 6.05, .56, .25, .055);
      disc(body, trim, 0, 6.05, .6, .20, .06);
      disc(body, light, 0, 6.05, .64, .145, .025);
      for (let i = 0; i < 8; i++) { const a = i * Math.PI / 4; box(body, inner, Math.cos(a) * .18, 6.05 + Math.sin(a) * .18, .645, .025, .045, .015, a); }
    }
    bake(body); bake(head); bake(rightWrist);
    figures.push({ root, head, wrist: rightWrist, turn });
    return root;
  }
  armor({ x: 61, floor: 508, scale: 36.2, silver: true, turn: .07 });
  armor({ x: 159, floor: 508, scale: 33.5, turn: .10 });
  armor({ x: 239, floor: 505, scale: 29.4, triangle: true, turn: .11 });

  const media = matchMedia('(prefers-reduced-motion: reduce)');
  let visible = true, disposed = false, pageVisible = true, contextLost = false, frame = 0, last = 0, time = 0;
  const enabled = () => { let setting = null; try { setting = localStorage.getItem('jarvisMotionPreference'); } catch {} return setting === 'on' || (setting !== 'off' && !media.matches); };
  const selected = () => !avatar.classList.contains('deckard');
  const active = () => !disposed && !contextLost && pageVisible && !document.hidden && visible && selected();
  function render() {
    figures.forEach((figure, i) => {
      figure.head.rotation.y = Math.sin(time * .24 + i * 1.6) * .035;
      figure.wrist.rotation.z = Math.sin(time * .27 + i) * .012;
    });
    light.emissiveIntensity = 2.15 + Math.sin(time * .75) * .2;
    renderer.render(scene, camera);
  }
  function tick(stamp) {
    frame = 0;
    if (!active() || !enabled()) return;
    if (stamp - last >= 50) { time += Math.min(.1, (stamp - last) / 1000); last = stamp; render(); }
    frame = requestAnimationFrame(tick);
  }
  function resume() {
    if (frame) cancelAnimationFrame(frame); frame = 0;
    canvas.hidden = !selected();
    if (!active()) return;
    render(); last = performance.now();
    if (enabled()) frame = requestAnimationFrame(tick);
  }
  function resize() {
    const width = Math.max(1, Math.round(canvas.clientWidth));
    renderer.setSize(width, Math.round(width * 793 / 285), false); resume();
  }
  function onClick(event) { if (event.target.closest?.('.jarvisMotionToggle')) queueMicrotask(resume); }
  const selectionObserver = new MutationObserver(resume); selectionObserver.observe(avatar, { attributes: true, attributeFilter: ['class'] });
  const resizeObserver = new ResizeObserver(resize); resizeObserver.observe(canvas);
  const intersectionObserver = new IntersectionObserver(entries => { visible = entries[0]?.isIntersecting ?? true; resume(); }); intersectionObserver.observe(host);
  document.addEventListener('visibilitychange', resume);
  host.addEventListener('click', onClick);
  canvas.addEventListener('webglcontextlost', event => { event.preventDefault(); contextLost = true; resume(); });
  canvas.addEventListener('webglcontextrestored', () => { contextLost = false; resume(); });
  window.addEventListener('storage', resume);
  media.addEventListener('change', resume);
  window.addEventListener('pageshow', () => { pageVisible = true; resume(); });
  window.addEventListener('pagehide', event => {
    pageVisible = false; if (frame) cancelAnimationFrame(frame); frame = 0;
    if (event.persisted) return;
    disposed = true; selectionObserver.disconnect(); resizeObserver.disconnect(); intersectionObserver.disconnect();
    document.removeEventListener('visibilitychange', resume); host.removeEventListener('click', onClick); window.removeEventListener('storage', resume); media.removeEventListener('change', resume);
    scene.traverse(object => { if (object.isMesh) object.geometry.dispose(); }); materials.forEach(m => m.dispose()); renderer.dispose();
  });
  resize();
}
