(() => {
  'use strict';
  const $ = id => document.getElementById(id);
  const state = {settings:{character:'jarvis',language:'ko',provider:'codex'},connections:{},jobs:new Map(),
    connected:false,listening:false,recognizing:false,voiceBusy:false,playing:false,progress:'',confirmation:null,livePhase:'idle'};
  let socket,stream,audioContext,processor,source,asrController;
  const capture={pre:[],parts:[],active:false,silence:0,frames:0,noise:.002};

  async function api(path,data) {
    const response=await fetch(path,data===undefined?{}:{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(data)});
    if (!response.ok) throw new Error((await response.text()).slice(0,400));
    return response.json();
  }
  function notice(text) { $('notice').textContent=text; $('notice').hidden=!text; }
  function current() { return state.settings; }
  function activeJob() { return [...state.jobs.values()].find(job=>job.status==='running'); }
  function updatePhase() {
    let title='무엇을 도와드릴까요?', detail='마이크를 켠 뒤 “자비스” 또는 “데커드”라고 불러 주세요.';
    if (!state.connected) { title='프로그램에 연결 중입니다'; detail='잠시 기다려 주세요.'; }
    else if (state.livePhase==='connecting') {title='실시간 대화를 연결하고 있습니다';detail='등록된 맞춤 음성으로 연결을 준비합니다.';}
    else if (state.livePhase==='closing') {title='통화를 종료하고 있습니다';detail='마이크와 재생을 멈추고 종료를 확인하고 있습니다.';}
    else if (state.livePhase==='connected') {title='이야기하고 있어요';detail='작업 중에도 편하게 이야기하세요.';}
    else if (state.voiceBusy) { title=state.playing?'말하고 있습니다':'음성을 준비하고 있습니다'; detail='답변 글자는 먼저 확인하실 수 있습니다.'; }
    else if (state.recognizing) { title='말씀을 확인하고 있습니다'; detail='이 PC에서 음성을 글자로 바꾸고 있습니다.'; }
    else if (activeJob()) { title='작업하고 있습니다'; detail=state.progress||'진행 상황은 오른쪽 작업 기록에서 확인할 수 있습니다.'; }
    else if (state.listening) { title='듣고 있습니다'; detail='“자비스” 또는 “데커드”를 부르고 명령해 주세요.'; }
    else if (current().character==='deckard') { title='친구야, 무엇을 할까?'; }
    $('stateTitle').textContent=title;
    $('stateDetail').textContent=detail;
    $('orb').classList.toggle('listening',state.listening&&!state.voiceBusy&&!state.recognizing);
    $('orb').classList.toggle('working',!!activeJob()||state.recognizing||state.voiceBusy);
    $('micButton').classList.toggle('active',state.listening);
    $('micLabel').textContent=state.listening?'마이크 끄기':'마이크 켜기';
    if(['connecting','connected','closing'].includes(state.livePhase))$('micLabel').textContent='대화 종료';
    $('micNote').textContent=state.listening?'호출 이름 뒤에 말씀하면 자동으로 전송합니다.':'음성 인식은 이 PC에서 처리합니다.';
    if($('conversationMode')?.value==='live')$('micNote').textContent='OpenAI 실시간 대화 · API 사용량이 발생합니다.';
    $('connectionStatus').textContent=state.connected?'이 PC에 연결됨':'연결 중';
    $('connectionStatus').classList.toggle('online',state.connected);
    $('footerState').textContent=state.voiceBusy?'선택한 목소리로 응답 중':state.listening?'마이크 켜짐':state.connected?'이 PC에 연결됨':'연결을 확인하고 있습니다';
  }
  function renderSettings() {
    const settings=current();
    for (const button of document.querySelectorAll('[data-character]')) {const selected=button.dataset.character===settings.character;button.classList.toggle('selected',selected);button.setAttribute('aria-pressed',String(selected));}
    for (const button of document.querySelectorAll('[data-provider]')) {const selected=button.dataset.provider===settings.provider;button.classList.toggle('selected',selected);button.setAttribute('aria-pressed',String(selected));}
    for (const button of document.querySelectorAll('[data-language]')) {
      button.classList.toggle('selected',button.dataset.language===settings.language);
      button.setAttribute('aria-pressed',String(button.dataset.language===settings.language));
      button.disabled=settings.character==='deckard'&&button.dataset.language==='en';
    }
    $('desktopEnabled').checked=!!settings.desktop_enabled;
    $('voiceEnabled').checked=!!settings.voice_enabled;
    $('workspaceInput').value=settings.workspace||'';
    $('characterLabel').textContent=(settings.character==='deckard'?'DECKARD':'JARVIS')+' · '+(settings.language==='en'?'English':'한국어');
    $('orb').classList.toggle('deckard',settings.character==='deckard');
    $('orb').querySelector('.core').textContent=settings.character==='deckard'?'D':'J';
    $('languageHint').textContent=settings.character==='deckard'?'데커드는 한국어로 “친구야”라고 부르며 응답합니다.':'“자비스”라고 부르면 기본은 한국어입니다.';
    updatePhase();
  }
  function renderConnections() {
    for (const provider of ['codex','claude']) {
      const connection=state.connections[provider]||{};
      const text=connection.logged_in?'연결됨':connection.installed?'로그인 필요':'설치 필요';
      const badge=$(provider+'Badge');
      badge.textContent=text; badge.className='badge '+(connection.logged_in?'ready':'pending');
      $(provider+'Connection').textContent=connection.logged_in?'현재 계정으로 작업할 수 있습니다.':connection.installed?'로그인 창에서 계정을 연결해 주세요.':'실행 도구를 설치해 주세요.';
    }
  }
  const labels={queued:'대기 중',running:'실행 중',completed:'완료',needs_input:'확인 필요',failed:'진행 못함',cancelled:'중지됨'};
  function renderJobs() {
    $('jobCount').textContent=state.jobs.size;
    $('emptyJobs').hidden=state.jobs.size>0;
    $('jobList').replaceChildren();
    for (const job of [...state.jobs.values()].reverse()) {
      const card=document.createElement('article'); card.className='jobCard '+job.status;
      const top=document.createElement('div'); top.className='jobTop';
      const who=document.createElement('span'); who.textContent=(job.character==='deckard'?'데커드':'자비스')+' · '+(job.provider==='claude'?'Claude':'GPT');
      const badge=document.createElement('span'); badge.className='jobStatus '+job.status; badge.textContent=labels[job.status]||job.status;
      top.append(who,badge); card.append(top);
      const text=document.createElement('p'); text.className='jobText'; text.textContent=job.text; card.append(text);
      if (job.reply) { const reply=document.createElement('p');reply.className='jobReply';reply.textContent=job.reply;card.append(reply); }
      for (let index=0;index<(job.artifacts||[]).length;index++) {
        const link=document.createElement('a');link.className='artifact';link.href='/api/artifact?job='+encodeURIComponent(job.id)+'&index='+index;
        link.textContent='↓ '+job.artifacts[index].split(/[\\/]/).pop();link.download='';card.append(link);
      }
      const time=document.createElement('p');time.className='jobTime';time.textContent=new Date(job.created*1000).toLocaleTimeString('ko-KR',{hour:'2-digit',minute:'2-digit'});card.append(time);
      $('jobList').append(card);
    }
    updatePhase();
  }
  function showReply(text,character) {
    $('replyPanel').hidden=false;$('replyText').textContent=text;$('replyLabel').textContent=character==='deckard'?'DECKARD':'JARVIS';
  }
  function receive(message) {
    if (message.type==='snapshot') {
      state.settings=message.settings;state.connections=message.connections;state.voiceBusy=!!message.voice_busy;
      state.jobs=new Map(message.jobs.map(job=>[job.id,job]));renderSettings();renderConnections();renderJobs();
    } else if (message.type==='settings') { state.settings=message.settings;renderSettings();window.studioLive?.status().catch(()=>{}); }
    else if (message.type==='reply_draft') {
      const job=state.jobs.get(message.job_id);if(job)job.draft=message.text;
      showReply(message.text,message.character);
    }
    else if (message.type==='job') {
      state.jobs.set(message.job.id,message.job);state.progress='';renderJobs();
      if (message.job.reply) showReply(message.job.reply,message.job.character);
    } else if (message.type==='progress') { state.progress=message.text;updatePhase(); }
    else if (message.type==='notice') notice(message.text);
    else if (message.type==='voice_pending') { window.dispatchEvent(new CustomEvent('studio-speech',{detail:{type:'stop'}}));state.voiceBusy=true;state.playing=false;resetCapture();showReply(message.text,message.character);updatePhase(); }
    else if (message.type==='voice_playing') { state.voiceBusy=true;state.playing=true;window.dispatchEvent(new CustomEvent('studio-speech',{detail:{type:'start',character:message.character||current().character,envelope:message.envelope||[],frame_ms:message.frame_ms||40,duration_ms:message.duration_ms||message.seconds*1000,offset_ms:message.playback_offset_ms||0}}));updatePhase(); }
    else if (message.type==='voice_done') { window.dispatchEvent(new CustomEvent('studio-speech',{detail:{type:'stop'}}));state.voiceBusy=false;state.playing=false;resetCapture();updatePhase(); }
    else if (message.type==='stopped') { state.voiceBusy=false;state.playing=false;stopMic();state.progress='';notice('작업과 음성 재생을 중지했습니다.');updatePhase(); }
    else if (message.type==='confirmation') {
      state.confirmation=message.id;$('confirmationText').textContent=message.question;$('confirmationDialog').showModal();
    }
  }
  function connect() {
    socket=new WebSocket((location.protocol==='https:'?'wss://':'ws://')+location.host+'/ws');
    socket.onopen=()=>{state.connected=true;updatePhase();};
    socket.onmessage=event=>{try{receive(JSON.parse(event.data));}catch(error){notice('화면 상태를 갱신하지 못했습니다.');}};
    socket.onclose=()=>{window.dispatchEvent(new CustomEvent('studio-speech',{detail:{type:'stop'}}));state.connected=false;resetCapture();updatePhase();setTimeout(connect,1500);};
  }
  async function changeSettings(values) { try { await api('/api/settings',values); } catch(error) { notice(error.message); } }
  async function submit(text,requireWake=false) {
    if (!text.trim()) return;
    try {
      const result=await api('/api/command',{text,...{character:current().character,language:current().language,provider:current().provider},require_wake:requireWake});
      if (!result.accepted) {
        $('transcriptStatus').textContent=result.reason==='deckard_korean_only'?'데커드는 한국어로 응답합니다.':'“자비스” 또는 “데커드”로 불러 주세요.';
        return;
      }
      notice('');$('transcriptStatus').textContent=result.action==='wake'?'네, 이어서 명령해 주세요.':'명령을 전달했습니다.';
      if (!requireWake&&$('commandInput').value===text) $('commandInput').value='';
    } catch(error) { notice(error.message); }
  }
  function resetCapture() { capture.pre=[];capture.parts=[];capture.active=false;capture.silence=0;capture.frames=0; }
  function wavBlob(parts,rate) {
    const length=parts.reduce((total,part)=>total+part.length,0);
    const samples=new Float32Array(length);let position=0;for(const part of parts){samples.set(part,position);position+=part.length;}
    const count=Math.floor(length*16000/rate),buffer=new ArrayBuffer(44+count*2),view=new DataView(buffer);
    const write=(offset,text)=>{for(let i=0;i<text.length;i++)view.setUint8(offset+i,text.charCodeAt(i));};
    write(0,'RIFF');view.setUint32(4,36+count*2,true);write(8,'WAVE');write(12,'fmt ');view.setUint32(16,16,true);view.setUint16(20,1,true);view.setUint16(22,1,true);view.setUint32(24,16000,true);view.setUint32(28,32000,true);view.setUint16(32,2,true);view.setUint16(34,16,true);write(36,'data');view.setUint32(40,count*2,true);
    for(let i=0;i<count;i++) {
      const start=Math.floor(i*rate/16000),end=Math.max(start+1,Math.floor((i+1)*rate/16000));let sum=0;
      for(let j=start;j<end&&j<length;j++)sum+=samples[j];const value=Math.max(-1,Math.min(1,sum/(end-start)));
      view.setInt16(44+i*2,value<0?value*32768:value*32767,true);
    }
    return new Blob([buffer],{type:'audio/wav'});
  }
  async function recognize(parts,rate) {
    state.recognizing=true;resetCapture();updatePhase();asrController=new AbortController();
    try {
      const response=await fetch('/api/transcribe',{method:'POST',headers:{'Content-Type':'audio/wav'},body:wavBlob(parts,rate),signal:asrController.signal});
      if(!response.ok)throw new Error(await response.text());
      const result=await response.json();
      if(state.listening&&result.text) { $('transcriptStatus').textContent='들은 말: '+result.text;await submit(result.text,true); }
    } catch(error) { if(error.name!=='AbortError')notice(error.message); }
    finally { state.recognizing=false;asrController=null;updatePhase(); }
  }
  async function startMic() {
    notice('');
    if(!navigator.mediaDevices?.getUserMedia) { notice('이 브라우저에서는 마이크를 사용할 수 없습니다. Chrome 또는 Edge에서 이 화면을 열어 주세요.');return; }
    try {
      stream=await navigator.mediaDevices.getUserMedia({audio:{channelCount:1,echoCancellation:true,noiseSuppression:true,autoGainControl:true}});
      audioContext=new (window.AudioContext||window.webkitAudioContext)();await audioContext.resume();
      source=audioContext.createMediaStreamSource(stream);processor=audioContext.createScriptProcessor(2048,1,1);
      processor.onaudioprocess=event=>{
        event.outputBuffer.getChannelData(0).fill(0);
        if(!state.listening||!state.connected||state.voiceBusy||state.recognizing){resetCapture();return;}
        const samples=new Float32Array(event.inputBuffer.getChannelData(0));let sum=0;for(const sample of samples)sum+=sample*sample;
        const rms=Math.sqrt(sum/samples.length),seconds=samples.length/audioContext.sampleRate;
        const threshold=Math.max(.008,Math.min(.04,capture.noise*3));
        if(!capture.active) {
          capture.noise=capture.noise*.98+Math.min(rms,.02)*.02;capture.pre.push(samples);if(capture.pre.length>8)capture.pre.shift();
          if(rms>threshold) {capture.active=true;capture.parts=[...capture.pre];capture.frames=capture.parts.reduce((n,p)=>n+p.length,0);capture.silence=0;}
        } else {
          capture.parts.push(samples);capture.frames+=samples.length;capture.silence=rms>threshold?0:capture.silence+seconds;
          if(capture.silence>.9||capture.frames/audioContext.sampleRate>=20) {
            const parts=capture.parts.slice(),duration=capture.frames/audioContext.sampleRate;resetCapture();
            if(duration>1.0)recognize(parts,audioContext.sampleRate);
          }
        }
      };
      source.connect(processor);processor.connect(audioContext.destination);state.listening=true;resetCapture();updatePhase();
    } catch(error) {
      await stopMic();$('openChromeButton').hidden=false;
      if(error.name==='NotAllowedError')notice('마이크 사용이 허용되지 않았습니다. 브라우저에서 마이크 권한을 직접 허용해 주세요.');
      else if(error.name==='NotFoundError'||error.name==='DevicesNotFoundError')notice('마이크 입력 장치를 찾지 못했습니다. PC에 마이크를 연결한 뒤 다시 켜 주세요. Chrome에서도 이 화면을 열 수 있습니다.');
      else if(error.name==='NotReadableError')notice('마이크를 사용하지 못했습니다. 다른 프로그램이 마이크를 사용 중인지 확인해 주세요.');
      else notice('마이크를 시작하지 못했습니다. 장치 연결과 브라우저 마이크 권한을 확인해 주세요.');
    }
  }
  async function stopMic() {
    state.listening=false;resetCapture();asrController?.abort();
    if(processor){processor.onaudioprocess=null;processor.disconnect();processor=null;}
    if(source){source.disconnect();source=null;}
    if(stream){stream.getTracks().forEach(track=>track.stop());stream=null;}
    if(audioContext){const context=audioContext;audioContext=null;await context.close().catch(()=>{});}
    updatePhase();
  }
  window.addEventListener('studio-live-state',event=>{state.livePhase=event.detail.phase;if(event.detail.message)notice(event.detail.message);updatePhase();});
  $('micButton').onclick=()=>{
    if($('conversationMode')?.value==='live')return window.studioLive.active?window.studioLive.stop():window.studioLive.start();
    return state.listening?stopMic():startMic();
  };
  $('conversationMode')?.addEventListener('change',async()=>{await stopMic();if(window.studioLive.active)await window.studioLive.stop();updatePhase();});
  $('openChromeButton').onclick=async()=>{try{await api('/api/open-browser',{});}catch(error){notice(error.message);}};
  $('sendButton').onclick=()=>submit($('commandInput').value);
  $('commandInput').onkeydown=event=>{if(event.key==='Enter'&&!event.shiftKey&&!event.isComposing){event.preventDefault();submit($('commandInput').value);}};
  $('stopButton').onclick=async()=>{await stopMic();if(window.studioLive?.active)await window.studioLive.stop();try{await api('/api/stop',{});}catch(error){notice(error.message);}};
  document.addEventListener('keydown',event=>{if(event.key==='Escape'&&!$('settingsDialog').open&&!$('confirmationDialog').open)$('stopButton').click();});
  for(const button of document.querySelectorAll('[data-character]'))button.onclick=()=>changeSettings({character:button.dataset.character,language:'ko'});
  for(const button of document.querySelectorAll('[data-language]'))button.onclick=()=>changeSettings({language:button.dataset.language});
  for(const button of document.querySelectorAll('[data-provider]'))button.onclick=()=>changeSettings({provider:button.dataset.provider});
  for(const button of document.querySelectorAll('[data-example]'))button.onclick=()=>{$('commandInput').value=button.dataset.example;$('commandInput').focus();};
  $('desktopEnabled').onchange=()=>changeSettings({desktop_enabled:$('desktopEnabled').checked});
  $('voiceEnabled').onchange=()=>changeSettings({voice_enabled:$('voiceEnabled').checked});
  $('settingsButton').onclick=()=>{$('settingsDialog').showModal();refreshConnections();window.studioLive?.status().catch(error=>connectionNotice(error.message));};
  $('closeSettings').onclick=()=>$('settingsDialog').close();
  $('saveWorkspace').onclick=()=>changeSettings({workspace:$('workspaceInput').value}).then(()=>notice('작업 폴더를 저장했습니다.'));
  function connectionNotice(text) {
    let feedback=$('connectionFeedback');
    if(!feedback){feedback=document.createElement('p');feedback.id='connectionFeedback';feedback.className='connectionFeedback';feedback.setAttribute('role','status');$('settingsDialog').querySelector('.dialogHeader').after(feedback);}
    feedback.textContent=text;feedback.hidden=!text;
  }
  let refreshingConnections=null;
  async function refreshConnections(){
    if(refreshingConnections)return refreshingConnections;
    refreshingConnections=(async()=>{try{const snapshot=await api('/api/status?refresh=1');state.connections=snapshot.connections;renderConnections();return snapshot.connections;}catch(error){connectionNotice(error.message);return null;}})();
    try{return await refreshingConnections;}finally{refreshingConnections=null;}
  }
  const loginWatches=new Map();
  async function watchLogin(provider){
    if(loginWatches.has(provider))return;
    loginWatches.set(provider,true);
    try{
      const deadline=Date.now()+180000;
      while(Date.now()<deadline){
        await new Promise(resolve=>setTimeout(resolve,2500));
        const connections=await refreshConnections();
        if(connections?.[provider]?.logged_in){connectionNotice((provider==='codex'?'GPT':'Claude')+' 연결이 완료되었습니다.');return;}
      }
      connectionNotice('로그인을 기다리고 있습니다. 로그인 후 “로그인 상태 다시 확인”을 눌러 주세요.');
    }finally{loginWatches.delete(provider);}
  }
  $('refreshConnections').onclick=refreshConnections;
  for(const button of document.querySelectorAll('[data-connect]'))button.onclick=async()=>{
    if(button.disabled)return;
    button.disabled=true;connectionNotice('로그인 연결을 확인하고 있습니다…');
    try{
      const result=await api('/api/connect/'+button.dataset.connect,{});
      if(result.already_connected){await refreshConnections();connectionNotice('이미 연결된 계정입니다. 바로 작업할 수 있습니다.');}
      else{connectionNotice(result.already_open?'이미 열린 로그인 창에서 진행해 주세요.':'로그인 창을 열었습니다. 브라우저에서 직접 로그인하면 연결 상태가 자동으로 갱신됩니다.');watchLogin(button.dataset.connect);}
    }catch(error){connectionNotice(error.message);}
    finally{button.disabled=false;}
  };
  window.addEventListener('focus',()=>{if($('settingsDialog').open||loginWatches.size)refreshConnections();});
  for(const [id,approved] of [['approveAction',true],['denyAction',false]])$(id).onclick=async()=>{
    try{await api('/api/approval',{id:state.confirmation,approved});$('confirmationDialog').close();state.confirmation=null;}catch(error){notice(error.message);}
  };
  $('confirmationDialog').addEventListener('cancel',event=>{event.preventDefault();$('denyAction').click();});
  window.addEventListener('beforeunload',()=>{stream?.getTracks().forEach(track=>track.stop());});
  renderSettings();connect();window.studioLive?.status().catch(()=>{});
})();
