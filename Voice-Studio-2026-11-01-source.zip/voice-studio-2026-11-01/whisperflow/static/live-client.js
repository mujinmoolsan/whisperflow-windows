/* Studio UI adapter for OpenAI's MIT-licensed BrowserSession implementation.
 * The transport comes from the pinned official source, not a separate media loop.
 */
(() => {
  'use strict';
  const $=id=>document.getElementById(id);
  let session=null,sessionPromise=null,audio=null,phase='idle',attempt=0,starting=false,locked=[],meter=null;
  let outputText='',selectedCharacter='jarvis';
  const notify=(next,message='')=>window.dispatchEvent(new CustomEvent('studio-live-state',{detail:{phase:next,message}}));
  const phaseName=p=>p==='live'?'connected':p==='incomplete'?'error':p==='closed'?'idle':p;
  function lock(){
    if(locked.length)return;
    locked=[...document.querySelectorAll('[data-character],[data-provider],[data-language],#commandInput,#sendButton,#conversationMode')].map(el=>[el,el.disabled]);
    for(const [el] of locked)el.disabled=true;
  }
  function unlock(){for(const [el,disabled] of locked)el.disabled=disabled;locked=[];}
  function stopMeter(){
    if(meter){cancelAnimationFrame(meter.frame);meter.source.disconnect();meter.context.close().catch(()=>{});meter=null;}
    window.dispatchEvent(new CustomEvent('studio-speech',{detail:{type:'stop'}}));
  }
  function outputMeter(stream){
    stopMeter();
    try{
      const context=new AudioContext(),source=context.createMediaStreamSource(stream),analyser=context.createAnalyser();
      analyser.fftSize=256;source.connect(analyser);const data=new Uint8Array(analyser.fftSize);
      const owned={context,source,frame:0,last:0};meter=owned;context.resume().catch(()=>{});
      const tick=time=>{
        if(meter!==owned)return;
        if(time-owned.last>=40){analyser.getByteTimeDomainData(data);const rms=Math.sqrt(data.reduce((sum,n)=>sum+((n-128)/128)**2,0)/data.length);window.dispatchEvent(new CustomEvent('studio-speech',{detail:{type:'level',character:selectedCharacter,level:Math.min(1,rms*7)}}));owned.last=time;}
        owned.frame=requestAnimationFrame(tick);
      };owned.frame=requestAnimationFrame(tick);
    }catch{/* Optional animation cannot interrupt audio. */}
  }
  async function status(){
    const response=await fetch('/api/live/status');
    const value=await response.json();if(!response.ok)throw new Error('실시간 연결 상태를 확인하지 못했습니다.');
    const readiness=value.readiness,option=$('liveModeOption');
    if(option){option.disabled=!readiness.ready;option.textContent=readiness.ready?'실시간 대화 · 등록 목소리':'실시간 대화 · 설정 필요';}
    if($('liveSetupFeedback'))$('liveSetupFeedback').textContent=readiness.ready?'등록한 목소리로 연결할 준비가 되었습니다. 통화 중 OpenAI API 사용량이 발생합니다.':readiness.reasons.map(x=>x.message).join(' ');
    return value;
  }
  function ensureSession(){
    if(session)return Promise.resolve(session);
    if(!sessionPromise)sessionPromise=makeSession().catch(error=>{sessionPromise=null;throw error;});
    return sessionPromise;
  }
  async function makeSession(){
    const {BrowserSession}=await import('/static/vendor/openai-live-session.js?v=official-5f64ecb');
    audio=document.createElement('audio');audio.autoplay=true;audio.hidden=true;document.body.append(audio);
    session=new BrowserSession(audio,{
      phase(value){phase=value;if(!['connecting','live','closing'].includes(value)){starting=false;unlock();stopMeter();}notify(phaseName(value),value==='incomplete'?'종료 정보 또는 최종 사용량을 확인하지 못했습니다.':'');},
      error(message){notify(phaseName(phase),message);},
      level(){}, // The official input meter never drives the avatar's mouth.
      output:outputMeter,
      playbackBlocked(blocked){
        $('resumeLiveAudio')?.remove();
        if(blocked){notify(phaseName(phase),'브라우저에서 소리 재생을 허용해 주세요.');const button=document.createElement('button');button.id='resumeLiveAudio';button.className='quiet';button.textContent='소리 재생';button.onclick=()=>session.resumePlayback();$('notice')?.append(button);}
      },
      event(value){
        if(value.type==='transcript'){
          if(value.role==='user'){$('transcriptStatus').textContent='들은 말: '+value.text;outputText='';}
          else{outputText=(outputText+value.text).slice(-6000);$('replyPanel').hidden=false;$('replyText').textContent=outputText;}
        }else if(value.type==='error')notify(phaseName(phase),value.message);
      },
    });
    return session;
  }
  async function start(){
    if(starting||['connecting','live','closing'].includes(phase))return;
    const token=++attempt;starting=true;
    try{
      const health=await status();if(token!==attempt)return;
      if(!health.readiness.ready)throw new Error(health.readiness.reasons.map(x=>x.message).join(' '));
      selectedCharacter=health.readiness.character;const transport=await ensureSession();if(token!==attempt)return;
      lock();outputText='';
      await transport.start({csrf:'',configured:true,model:'gpt-live-1',backendModel:'existing-task-runner',maxSessionSeconds:0},'client','','');
    }catch(error){if(token===attempt){phase='error';unlock();stopMeter();notify('error',error.message);}}
    finally{if(token===attempt)starting=false;}
  }
  async function stop(){
    attempt++;starting=false;audio?.pause();stopMeter();
    if(session)await session.stop();
    else{phase='idle';unlock();notify('idle');}
  }
  window.studioLive={start,stop,status,get active(){return starting||['connecting','live','closing'].includes(phase);},source:'openai/openai-live-console@5f64ecb3009d8274da9953c825d469ea6b6b67c3'};
  window.addEventListener('pagehide',()=>{attempt++;starting=false;stopMeter();unlock();});
})();
