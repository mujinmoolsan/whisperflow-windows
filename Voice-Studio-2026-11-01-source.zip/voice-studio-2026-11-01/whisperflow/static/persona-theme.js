/* Visual themes follow the application's existing selected avatar. No voice,
 * microphone, login, provider, or network behavior is changed here. */
(() => {
  'use strict';
  const orb = document.getElementById('orb');
  if (!orb || !document.body) return;
  const brand = document.querySelector('.brand');
  const brandName = document.querySelector('.brand > span:last-child');
  const brandText = brandName && [...brandName.childNodes].find(n => n.nodeType === 3);
  const subtitle = document.querySelector('.brandSubtitle');
  const eyebrow = document.querySelector('.workspaceHeading .eyebrow');
  const tag = document.querySelector('.workspaceTag');
  const footerBrand = document.querySelector('.footerBrand');
  const metaColor = document.querySelector('meta[name="theme-color"]');
  let currentTheme = '';
  const themes = {
    jarvis: {name:'JARVIS',ko:'자비스',subtitle:'PRIVATE LABORATORY',eyebrow:'IDEAS INTO REALITY',tag:'나만의 연구실',footer:'JARVIS · LABORATORY',color:'#061017'},
    deckard: {name:'DECKARD',ko:'데커드',subtitle:'BRAVE POLICE WORKSPACE',eyebrow:'ALWAYS BY YOUR SIDE',tag:'우리들의 작업 기지',footer:'DECKARD · BRAVE POLICE',color:'#173e67'}
  };
  function syncTheme() {
    const next = orb.classList.contains('deckard') ? 'deckard' : 'jarvis';
    if (next === currentTheme) return;
    currentTheme = next;
    const theme = themes[next];
    document.body.dataset.studioTheme = next;
    if (brandText) brandText.nodeValue = theme.name;
    if (brand) brand.setAttribute('aria-label', `${theme.ko} 음성 작업실 홈`);
    if (subtitle) subtitle.textContent = theme.subtitle;
    if (eyebrow) eyebrow.textContent = theme.eyebrow;
    if (tag) tag.textContent = theme.tag;
    if (footerBrand) footerBrand.textContent = theme.footer;
    if (metaColor) metaColor.setAttribute('content', theme.color);
    document.title = `음성 작업실 · ${theme.name}`;
  }
  const observer = new MutationObserver(syncTheme);
  observer.observe(orb, {attributes:true,attributeFilter:['class']});
  window.addEventListener('pageshow', syncTheme);
  window.addEventListener('pagehide', event => {if (!event.persisted) observer.disconnect();});
  syncTheme();
})();
