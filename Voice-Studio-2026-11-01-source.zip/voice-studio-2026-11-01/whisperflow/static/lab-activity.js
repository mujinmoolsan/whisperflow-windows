/* Authored decorative engineering studies, aligned with the six monitor planes in
 * jarvis-cinematic-lab.png (1983 x 793). Values are animation geometry, never PC,
 * microphone, account, model, or system telemetry. No network or input listeners. */
(() => {
  'use strict';
  const area = document.querySelector('.commandArea');
  const orb = document.getElementById('orb');
  if (!area || !orb || area.querySelector('.labActivityLayer')) return;
  const WIDTH = 1983, ARM_TOP = 450, ARM_WIDTH = 650, ARM_HEIGHT = 343, FRAME_MS = 1000 / 24, TAU = Math.PI * 2;
  const layer = document.createElement('div');
  layer.className = 'labActivityLayer';
  layer.setAttribute('aria-hidden', 'true');
  const stage = document.createElement('div');
  stage.className = 'labActivityStage';
  layer.append(stage);
  area.append(layer);

  // Source image corners, inset from each glass bezel: TL, TR, BR, BL.
  const definitions = [
    {kind:'blueprint',title:'PROPULSION / SECTION A',quad:[[307,294],[529,325],[529,489],[307,489]]},
    {kind:'orbit',title:'ROTOR STUDY',quad:[[559,329],[655,339],[655,406],[559,400]]},
    {kind:'wave',title:'SIGNAL STUDY',quad:[[560,429],[656,435],[656,490],[560,489]]},
    {kind:'circuit',title:'PATH GEOMETRY',quad:[[1325,339],[1417,326],[1417,401],[1325,406]]},
    {kind:'spectrum',title:'HARMONIC STUDY',quad:[[1325,430],[1417,425],[1417,488],[1325,490]]},
    {kind:'assembly',title:'MECHANICAL / EXPLODED VIEW',quad:[[1451,322],[1679,285],[1679,489],[1451,489]]}
  ];
  function projectionMatrix(points, width, height) {
    const [[x0,y0],[x1,y1],[x2,y2],[x3,y3]] = points;
    const dx1=x1-x2,dx2=x3-x2,dx3=x0-x1+x2-x3;
    const dy1=y1-y2,dy2=y3-y2,dy3=y0-y1+y2-y3;
    const determinant=dx1*dy2-dx2*dy1;
    const g=determinant ? (dx3*dy2-dx2*dy3)/determinant : 0;
    const h=determinant ? (dx1*dy3-dx3*dy1)/determinant : 0;
    const a=x1-x0+g*x1,b=x3-x0+h*x3,d=y1-y0+g*y1,e=y3-y0+h*y3;
    return `matrix3d(${[a/width,d/width,0,g/width,b/height,e/height,0,h/height,0,0,1,0,x0,y0,0,1].join(',')})`;
  }
  const screens = definitions.map(definition => {
    const canvas=document.createElement('canvas');
    canvas.className='labDisplay';
    canvas.width=480;canvas.height=360;
    canvas.style.width='480px';canvas.style.height='360px';
    canvas.style.transform=projectionMatrix(definition.quad,480,360);
    stage.append(canvas);
    return {...definition,canvas,ctx:canvas.getContext('2d',{alpha:true})};
  });
  const arm=document.createElement('canvas');
  arm.className='labArmCanvas';arm.width=ARM_WIDTH;arm.height=ARM_HEIGHT;
  stage.append(arm);
  const armCtx=arm.getContext('2d',{alpha:true});
  if (!armCtx || screens.some(screen=>!screen.ctx)) {layer.remove();return;}
  // Retain room-space drawing coordinates while backing only the foreground crop.
  armCtx.setTransform(1,0,0,1,0,-ARM_TOP);

  function line(ctx, points, color='#6de2f1', width=1) {
    if (!points.length) return;
    ctx.strokeStyle=color;ctx.lineWidth=width;ctx.beginPath();
    points.forEach((point,index)=>index ? ctx.lineTo(...point) : ctx.moveTo(...point));
    ctx.stroke();
  }
  function circle(ctx,x,y,r,color='#78ddeb',width=1,start=0,end=TAU) {
    ctx.beginPath();ctx.arc(x,y,r,start,end);ctx.strokeStyle=color;ctx.lineWidth=width;ctx.stroke();
  }
  function label(ctx,text,x,y,size=10,color='#8cd9e5') {
    ctx.font=`${size}px "Segoe UI", sans-serif`;ctx.fillStyle=color;ctx.fillText(text,x,y);
  }
  function panelFrame(ctx,title,t) {
    ctx.clearRect(0,0,480,360);
    ctx.fillStyle='rgba(2,20,32,.58)';ctx.fillRect(0,0,480,360);
    for(let x=18;x<480;x+=24)line(ctx,[[x,37],[x,327]],'#68b9c611',.65);
    for(let y=39;y<330;y+=24)line(ctx,[[16,y],[464,y]],'#68b9c611',.65);
    label(ctx,title,16,21,10,'#adecf2');
    line(ctx,[[16,30],[462,30]],'#91e9ee57',1);
    line(ctx,[[16,332],[462,332]],'#91e9ee32',1);
    label(ctx,'DESIGN VISUAL',16,349,8,'#7baeba');
    for(let i=0;i<14;i++) {
      const alpha=.25+.28*(.5+.5*Math.sin(t*.7+i*.47));
      ctx.fillStyle=`rgba(102,214,229,${alpha})`;ctx.fillRect(372+i*6,341,3,4);
    }
  }
  function dimensions(ctx,x1,y1,x2,y2,caption) {
    line(ctx,[[x1,y1],[x2,y2]],'#b8edf25c',.8);
    line(ctx,[[x1-4,y1-4],[x1+4,y1+4]],'#b8edf266',.8);
    line(ctx,[[x2-4,y2-4],[x2+4,y2+4]],'#b8edf266',.8);
    label(ctx,caption,(x1+x2)/2+5,(y1+y2)/2-5,8,'#91c8d2');
  }
  function blueprint(ctx,t) {
    const cx=215,cy=177;
    for(let i=0;i<5;i++) {
      const radius=27+i*14;
      circle(ctx,cx,cy,radius,i%2?'#6adceb75':'#b8eff3bb',i===3?1.6:.8);
      for(let k=0;k<16;k++) {
        const angle=k*TAU/16+(i%2?t*.07:-t*.035);
        line(ctx,[[cx+Math.cos(angle)*(radius-4),cy+Math.sin(angle)*(radius-4)],[cx+Math.cos(angle)*(radius+4),cy+Math.sin(angle)*(radius+4)]],'#83d7e58c',.7);
      }
    }
    for(let k=0;k<9;k++) {
      const angle=k*TAU/9+t*.12;
      const shape=[];
      for(let j=0;j<12;j++) {const r=29+j*4.2,a=angle+j*.035;shape.push([cx+Math.cos(a)*r,cy+Math.sin(a)*r]);}
      line(ctx,shape,'#b8f3f0bc',1.1);
    }
    circle(ctx,cx,cy,7,'#e1fffb',1.7);
    line(ctx,[[70,cy],[340,cy]],'#aadce450',.75);
    line(ctx,[[cx,61],[cx,287]],'#aadce450',.75);
    dimensions(ctx,126,277,304,277,'SECTION A—A');
    dimensions(ctx,105,89,105,262,'IMPELLER');
    line(ctx,[[274,119],[332,72],[423,72]],'#93d6df99');
    label(ctx,'FLOW CHANNEL',338,65,9);
    line(ctx,[[276,225],[338,254],[440,254]],'#93d6df99');
    label(ctx,'BEARING HOUSING',338,248,9);
    for(let i=0;i<5;i++) {
      label(ctx,['GEOMETRY','SECTION','MATERIAL','ASSEMBLY','TOLERANCE'][i],340,115+i*21,8,'#91b9c4');
      line(ctx,[[340,122+i*21],[441-i*7,122+i*21]],'#68bdcd57',2);
    }
    // A second, smaller orthographic section grounds the circular drawing.
    line(ctx,[[22,307],[22,288],[42,281],[61,281],[61,301],[76,301],[76,282],[96,282],[114,288],[114,307],[22,307]],'#94dce2a6');
    for(let x=30;x<110;x+=9)line(ctx,[[x,290],[x,304]],'#6ac2d04d',.7);
    label(ctx,'PROFILE B',132,305,8,'#8ebac5');
  }
  function orbit(ctx,t) {
    const x=239,y=182;
    for(let i=0;i<6;i++)circle(ctx,x,y,27+i*17,i%2?'#82dbe877':'#aee8eeaa',i===4?2:1);
    for(let k=0;k<32;k++){const a=k*TAU/32;line(ctx,[[x+Math.cos(a)*113,y+Math.sin(a)*113],[x+Math.cos(a)*120,y+Math.sin(a)*120]],'#a2dce799',1);}
    for(let j=0;j<3;j++){const a=t*.18+j*TAU/3;line(ctx,[[x,y],[x+Math.cos(a)*98,y+Math.sin(a)*98]],'#9fe8ee8c',2);circle(ctx,x+Math.cos(a)*98,y+Math.sin(a)*98,5,'#e1ffff',1.8);}
    line(ctx,[[75,182],[400,182]],'#64c8d440');line(ctx,[[239,53],[239,311]],'#64c8d440');
    label(ctx,'CROSS SECTION',25,67,10);label(ctx,'KINEMATIC AXIS',306,306,10);
  }
  function wave(ctx,t) {
    for(let band=0;band<4;band++) {
      const baseline=78+band*63,points=[];
      for(let x=22;x<461;x+=3) {
        const envelope=.35+.65*Math.pow(Math.sin(x/440*Math.PI),2);
        const y=baseline+(Math.sin(x*.038-t*1.4+band*.8)*17+Math.sin(x*.079+t*.6)*7)*envelope;
        points.push([x,y]);
      }
      line(ctx,[[22,baseline],[460,baseline]],'#6facbf40');
      line(ctx,points,band===1?'#c6fbfa':'#6bd4e0b3',band===1?2:1.4);
    }
    const scan=24+(t*28)%431;line(ctx,[[scan,46],[scan,317]],'#b1e9ee40',1);
  }
  function spectrum(ctx,t) {
    for(let i=0;i<32;i++) {
      const x=22+i*13.7;
      const height=26+140*Math.pow(.5+.5*Math.sin(i*.21+t*.55),2)+32*Math.sin(i*.56-t*.3);
      const gradient=ctx.createLinearGradient(0,310-height,0,310);
      gradient.addColorStop(0,'#a9edf0c7');gradient.addColorStop(1,'#298ba640');
      ctx.fillStyle=gradient;ctx.fillRect(x,310-height,8,height);
      line(ctx,[[x,305-height],[x+8,305-height]],'#c4f5f7b3',2);
    }
    for(let i=0;i<5;i++)line(ctx,[[18,67+i*52],[463,67+i*52]],'#a1d9e03d',.7);
    label(ctx,'HARMONIC ENVELOPE',24,58,10);
  }
  const circuitPaths=[[[30,86],[104,86],[129,111],[224,111],[247,88],[321,88],[347,61],[449,61]],[[31,139],[75,139],[113,177],[205,177],[245,137],[366,137],[407,177],[449,177]],[[30,237],[98,237],[138,197],[237,197],[267,227],[359,227],[392,194],[449,194]],[[31,288],[81,288],[113,256],[224,256],[260,292],[449,292]]];
  function circuit(ctx,t) {
    circuitPaths.forEach((path,i)=>{
      line(ctx,path,'#82d6e1a6',2);
      path.forEach(([x,y],j)=>{if(j%2===0)circle(ctx,x,y,4,'#c8f3f2',1.3);});
      const segment=(t*.42+i*.53)%(path.length-1),at=Math.floor(segment),u=segment-at;
      const x=path[at][0]+(path[at+1][0]-path[at][0])*u,y=path[at][1]+(path[at+1][1]-path[at][1])*u;
      ctx.fillStyle='#cafffa';ctx.fillRect(x-3,y-3,6,6);
    });
    ctx.fillStyle='#173d4ecc';ctx.fillRect(192,140,63,94);ctx.strokeStyle='#a9e6e9';ctx.lineWidth=1;ctx.strokeRect(192,140,63,94);
    label(ctx,'MODULE',199,181,9);label(ctx,'A / B',209,198,9);
  }
  function assembly(ctx,t) {
    const separation=6+Math.sin(t*.3)*3;
    const cx=231,cy=182;
    for(let i=0;i<7;i++) {
      const y=cy+(i-3)*(15+separation),rx=83-(Math.abs(i-3)*9),ry=24-Math.abs(i-3)*2;
      ctx.beginPath();ctx.ellipse(cx,y,rx,ry,-.12,0,TAU);ctx.strokeStyle=i===3?'#c5f6f6':'#80d7e4aa';ctx.lineWidth=i===3?2:1;ctx.stroke();
      ctx.beginPath();ctx.ellipse(cx,y,rx*.62,ry*.62,-.12,0,TAU);ctx.strokeStyle='#6db9c88c';ctx.lineWidth=1;ctx.stroke();
      if(i<6)for(const offset of[-1,1])line(ctx,[[cx+offset*rx*.78,y-ry*.3],[cx+offset*(rx-4)*.78,y+(15+separation)-ry*.3]],'#6bb6c16b',1);
    }
    line(ctx,[[cx,45],[cx,320]],'#92cbd459',.7);
    for(let i=0;i<4;i++) {
      const y=95+i*60;line(ctx,[[280,y],[341,y-15],[442,y-15]],'#95d4de7d');
      label(ctx,['COVER / A','CORE / B','HOUSING / C','BASE / D'][i],343,y-21,9);
    }
    dimensions(ctx,104,75,104,286,'EXPLODED ASSEMBLY');
    for(let i=0;i<4;i++) {
      const x=27+i*35;ctx.strokeStyle='#7ac6d088';ctx.lineWidth=1;ctx.strokeRect(x,299,23,17);
      line(ctx,[[x+4,307],[x+19,307]],'#7ac6d088');
    }
  }
  const painters={blueprint,orbit,wave,circuit,spectrum,assembly};

  function metalGradient(ctx,x0,y0,x1,y1) {
    const gradient=ctx.createLinearGradient(x0,y0,x1,y1);
    gradient.addColorStop(0,'#182b36');gradient.addColorStop(.18,'#647a83');
    gradient.addColorStop(.35,'#bbc9c8');gradient.addColorStop(.49,'#e2e8dc');
    gradient.addColorStop(.58,'#899da2');gradient.addColorStop(.83,'#405966');gradient.addColorStop(1,'#172d39');
    return gradient;
  }
  function polygon(ctx,points,fill,stroke='#0a1b26',strokeWidth=2) {
    ctx.beginPath();points.forEach((p,i)=>i?ctx.lineTo(...p):ctx.moveTo(...p));ctx.closePath();
    ctx.fillStyle=fill;ctx.fill();if(stroke){ctx.strokeStyle=stroke;ctx.lineWidth=strokeWidth;ctx.stroke();}
  }
  function link(ctx,a,b,widthA,widthB) {
    const dx=b.x-a.x,dy=b.y-a.y,len=Math.hypot(dx,dy),nx=-dy/len,ny=dx/len;
    const shape=[[a.x+nx*widthA,a.y+ny*widthA],[b.x+nx*widthB,b.y+ny*widthB],[b.x-nx*widthB,b.y-ny*widthB],[a.x-nx*widthA,a.y-ny*widthA]];
    polygon(ctx,shape,metalGradient(ctx,a.x-nx*widthA,a.y-ny*widthA,a.x+nx*widthA,a.y+ny*widthA));
    line(ctx,[[a.x+nx*(widthA-5),a.y+ny*(widthA-5)],[b.x+nx*(widthB-5),b.y+ny*(widthB-5)]],'#e3f1e5b3',2);
    const q1={x:a.x+dx*.21,y:a.y+dy*.21},q2={x:a.x+dx*.81,y:a.y+dy*.81};
    polygon(ctx,[[q1.x+nx*8,q1.y+ny*8],[q2.x+nx*6,q2.y+ny*6],[q2.x-nx*6,q2.y-ny*6],[q1.x-nx*8,q1.y-ny*8]],'#263f4b','#6e879022',1);
    ctx.beginPath();ctx.moveTo(a.x-nx*(widthA+5),a.y-ny*(widthA+5));
    ctx.quadraticCurveTo((a.x+b.x)/2-nx*64,(a.y+b.y)/2-ny*64,b.x-nx*(widthB+5),b.y-ny*(widthB+5));
    ctx.strokeStyle='#0b171e';ctx.lineWidth=8;ctx.stroke();ctx.strokeStyle='#66828b66';ctx.lineWidth=2;ctx.stroke();
  }
  function joint(ctx,x,y,r,rotation=0) {
    const gradient=ctx.createRadialGradient(x-r*.28,y-r*.32,r*.1,x,y,r);
    gradient.addColorStop(0,'#becbc8');gradient.addColorStop(.5,'#839a9e');gradient.addColorStop(.78,'#34515f');gradient.addColorStop(1,'#0c222e');
    ctx.beginPath();ctx.arc(x,y,r,0,TAU);ctx.fillStyle=gradient;ctx.fill();ctx.strokeStyle='#05131b';ctx.lineWidth=3;ctx.stroke();
    circle(ctx,x,y,r*.78,'#b6cdca9c',1.4);circle(ctx,x,y,r*.58,'#1b3542',5);circle(ctx,x,y,r*.50,'#82a3ad',1.2);
    circle(ctx,x,y,r*.64,'#67dbe4aa',2,rotation,rotation+1.1);
    for(let i=0;i<6;i++){const a=i*TAU/6+rotation;const bx=x+Math.cos(a)*r*.82,by=y+Math.sin(a)*r*.82;circle(ctx,bx,by,2.2,'#172d37',2);}
    line(ctx,[[x-r*.22,y],[x+r*.22,y]],'#142d3a',3);
  }
  const smooth=u=>u*u*(3-2*u);
  const mix=(a,b,u)=>a+(b-a)*smooth(u);
  function workCycle(t) {
    const clock=t%14;
    const poses=[{at:0,x:420,y:625,grip:18},{at:1.8,x:420,y:673,grip:18},{at:2.4,x:420,y:673,grip:5},{at:4.2,x:470,y:596,grip:5},{at:6,x:543,y:655,grip:5},{at:8.7,x:543,y:655,grip:5},{at:9.2,x:543,y:655,grip:18},{at:11,x:470,y:596,grip:18},{at:14,x:420,y:625,grip:18}];
    let i=0;while(i<poses.length-2&&clock>poses[i+1].at)i++;
    const a=poses[i],b=poses[i+1],u=(clock-a.at)/(b.at-a.at);
    const active=clock>6.2&&clock<8.5;
    return {x:mix(a.x,b.x,u),y:mix(a.y,b.y,u)+(active?Math.sin(t*18)*1.8:0),grip:mix(a.grip,b.grip,u),clock,active,carried:clock>2.2&&clock<8.9};
  }
  function component(ctx,x,y,rotation=0) {
    ctx.save();ctx.translate(x,y);ctx.rotate(rotation);
    const points=[];for(let i=0;i<6;i++){const a=i*TAU/6;points.push([Math.cos(a)*20,Math.sin(a)*15]);}
    polygon(ctx,points,metalGradient(ctx,-20,-12,20,16),'#102633',2);
    circle(ctx,0,0,7,'#1c4b5d',4);circle(ctx,0,0,4,'#77dfdf',1.5);
    ctx.restore();
  }
  function drawArm(t) {
    const ctx=armCtx;ctx.clearRect(0,ARM_TOP,ARM_WIDTH,ARM_HEIGHT);
    const pose=workCycle(t),shoulder={x:155,y:679},L1=191,L2=235;
    const dx=pose.x-shoulder.x,dy=pose.y-shoulder.y,distance=Math.min(L1+L2-1,Math.hypot(dx,dy));
    const angle=Math.atan2(dy,dx)-Math.acos(Math.max(-1,Math.min(1,(distance*distance+L1*L1-L2*L2)/(2*distance*L1))));
    const elbow={x:shoulder.x+Math.cos(angle)*L1,y:shoulder.y+Math.sin(angle)*L1};
    const wrist={x:pose.x,y:pose.y};
    // Foreground platform: all motion stays below the rear-left suit alcoves.
    const shadow=ctx.createRadialGradient(270,758,25,270,758,220);shadow.addColorStop(0,'#0009');shadow.addColorStop(1,'#0000');
    ctx.fillStyle=shadow;ctx.beginPath();ctx.ellipse(270,758,220,31,0,0,TAU);ctx.fill();
    polygon(ctx,[[73,751],[209,751],[239,778],[44,778]],'#263d48','#051721',2);
    polygon(ctx,[[73,735],[209,735],[209,751],[73,751]],metalGradient(ctx,73,735,209,751));
    polygon(ctx,[[108,684],[197,684],[208,734],[76,734]],metalGradient(ctx,76,0,208,0));
    ctx.beginPath();ctx.ellipse(153,686,49,17,0,0,TAU);ctx.fillStyle='#799097';ctx.fill();ctx.strokeStyle='#1a3442';ctx.lineWidth=4;ctx.stroke();
    line(ctx,[[92,745],[192,745]],'#7bc9cf88',2);
    polygon(ctx,[[379,723],[589,723],[620,751],[355,751]],metalGradient(ctx,355,723,620,751),'#18303e',2);
    polygon(ctx,[[355,751],[620,751],[620,767],[355,767]],'#263e4b','#142934',1);
    for(const x of[420,543]){ctx.beginPath();ctx.ellipse(x,720,32,10,0,0,TAU);ctx.fillStyle='#0a2534';ctx.fill();circle(ctx,x,717,19,'#6898a577',1,0,Math.PI);}
    if(!pose.carried && pose.clock<2.3)component(ctx,420,714);
    if(pose.clock>=8.9)component(ctx,543,714);
    link(ctx,shoulder,elbow,40,29);link(ctx,elbow,wrist,28,18);
    joint(ctx,shoulder.x,shoulder.y,48,angle);joint(ctx,elbow.x,elbow.y,35,-angle*.7);joint(ctx,wrist.x,wrist.y,22,t*.12);
    // Wrist housing and opposing tool fingers, with a visible grasp/release cycle.
    polygon(ctx,[[wrist.x-17,wrist.y+8],[wrist.x+17,wrist.y+8],[wrist.x+13,wrist.y+30],[wrist.x-13,wrist.y+30]],metalGradient(ctx,wrist.x-17,0,wrist.x+17,0));
    for(const side of[-1,1]) {
      const x=wrist.x+side*pose.grip;
      line(ctx,[[wrist.x+side*11,wrist.y+27],[x,wrist.y+37],[x,wrist.y+50],[x-side*6,wrist.y+52]],'#102a38',7);
      line(ctx,[[wrist.x+side*11,wrist.y+27],[x,wrist.y+37],[x,wrist.y+50],[x-side*6,wrist.y+52]],'#b8c7c4',3.3);
    }
    if(pose.carried)component(ctx,wrist.x,wrist.y+43,Math.sin(t*.8)*.08);
    if(pose.active) {
      const x=wrist.x,y=wrist.y+58;
      const glow=ctx.createRadialGradient(x,y,0,x,y,31);glow.addColorStop(0,'#c7faffcc');glow.addColorStop(.18,'#61e3ff77');glow.addColorStop(1,'#28a6d300');
      ctx.fillStyle=glow;ctx.fillRect(x-32,y-32,64,64);
      for(let i=0;i<7;i++) {
        const phase=(t*3.2+i*.17)%1,a=i*1.94+t*.28,r=8+phase*31;
        line(ctx,[[x+Math.cos(a)*r,y+Math.sin(a)*r*.45],[x+Math.cos(a)*(r+5),y+Math.sin(a)*(r+5)*.45]],`rgba(179,238,252,${(1-phase)*.7})`,1.4);
      }
    }
  }
  function draw(t) {
    for(const screen of screens){panelFrame(screen.ctx,screen.title,t);painters[screen.kind](screen.ctx,t);}
    drawArm(t);
  }

  const reducedMotion=matchMedia('(prefers-reduced-motion: reduce)');
  let raf=0,lastDraw=-Infinity,lastTick=0,time=0,drawn=false,intersecting=true,destroyed=false,pageSuspended=false,width=0;
  const selected=()=>!orb.classList.contains('deckard')&&document.body.dataset.studioTheme!=='deckard';
  function motionEnabled() {
    const button=orb.querySelector('.jarvisMotionToggle');
    const pressed=button?.getAttribute('aria-pressed');
    if(pressed==='true'||pressed==='false')return pressed==='true';
    let saved=null;try{saved=localStorage.getItem('jarvisMotionPreference');}catch{}
    return saved==='on'||(saved!=='off'&&!reducedMotion.matches);
  }
  const canAnimate=()=>!destroyed&&!pageSuspended&&selected()&&!document.hidden&&intersecting&&width>0&&motionEnabled();
  function stop(){if(raf){cancelAnimationFrame(raf);raf=0;}lastTick=0;}
  function tick(now) {
    raf=0;if(!canAnimate()){sync();return;}
    if(lastTick)time+=Math.min(100,now-lastTick)/1000;
    lastTick=now;
    if(now-lastDraw>=FRAME_MS){draw(time);lastDraw=now;drawn=true;}
    raf=requestAnimationFrame(tick);
  }
  function sync() {
    if(destroyed)return;
    layer.hidden=!selected();
    const active=canAnimate();
    layer.dataset.motion=active?'running':'paused';
    if(!drawn&&selected()&&!document.hidden&&intersecting&&width>0&&!pageSuspended){draw(time);drawn=true;lastDraw=performance.now();}
    if(active&&!raf){lastTick=performance.now();raf=requestAnimationFrame(tick);}
    else if(!active)stop();
  }
  function resize(){width=area.clientWidth||area.getBoundingClientRect().width;stage.style.transform=`scale(${width/WIDTH})`;sync();}
  const mutations=new MutationObserver(sync);
  mutations.observe(orb,{attributes:true,attributeFilter:['class','aria-pressed'],childList:true,subtree:true});
  mutations.observe(document.body,{attributes:true,attributeFilter:['data-studio-theme']});
  const resizeObserver=typeof ResizeObserver==='function'?new ResizeObserver(resize):null;
  resizeObserver?.observe(area);
  const intersectionObserver=typeof IntersectionObserver==='function'?new IntersectionObserver(entries=>{intersecting=entries.some(entry=>entry.isIntersecting);sync();},{threshold:0}):null;
  intersectionObserver?.observe(layer);
  const onVisibility=()=>sync();
  const onMotion=()=>sync();
  const onStorage=event=>{if(event.key==='jarvisMotionPreference')sync();};
  function onPageHide(event){pageSuspended=true;stop();if(!event.persisted)destroy();}
  function onPageShow(){pageSuspended=false;resize();}
  function destroy(){
    destroyed=true;stop();mutations.disconnect();resizeObserver?.disconnect();intersectionObserver?.disconnect();
    document.removeEventListener('visibilitychange',onVisibility);
    reducedMotion.removeEventListener?.('change',onMotion);
    window.removeEventListener('resize',resize);window.removeEventListener('storage',onStorage);
    window.removeEventListener('pagehide',onPageHide);window.removeEventListener('pageshow',onPageShow);
  }
  document.addEventListener('visibilitychange',onVisibility);
  reducedMotion.addEventListener?.('change',onMotion);
  window.addEventListener('resize',resize);window.addEventListener('storage',onStorage);
  window.addEventListener('pagehide',onPageHide);window.addEventListener('pageshow',onPageShow);
  resize();
})();
