/* Deckard reference-based portrait on an articulated, shallow 3D relief.
 * The generated artwork preserves the character design; only the lip/face mesh
 * is deformed. This is a 2.5D portrait, not a freely rotatable volumetric model.
 * Mouth motion follows played output amplitude, not phoneme recognition.
 */
import * as THREE from './vendor/three.module.js';

const mount = document.getElementById('orb');
if (mount) installDeckard(mount);

function installDeckard(host) {
  if (host.querySelector('.deckardCanvas')) return;
  const art = {width:1448,height:1086,mouthX:725,mouthY:470,mouthRadius:48,chinY:572};
  const imageURL = new URL('./deckard-resynthesized.png?v=3',import.meta.url).href;
  const canvas=document.createElement('canvas');
  canvas.className='deckardCanvas';canvas.setAttribute('aria-hidden','true');host.append(canvas);
  const fallback=document.createElement('img');
  fallback.className='deckardFallbackPortrait';fallback.src=imageURL;
  fallback.alt='원본 이미지를 참고해 다시 합성한 데커드 상반신';host.append(fallback);
  const reduced=matchMedia('(prefers-reduced-motion: reduce)');
  let renderer;
  try {
    renderer=new THREE.WebGLRenderer({canvas,alpha:true,antialias:true,powerPreference:'low-power'});
    renderer.setClearColor(0x000000,0);renderer.outputColorSpace=THREE.SRGBColorSpace;
    renderer.toneMapping=THREE.NoToneMapping;
  } catch {
    host.classList.add('deckardUnavailable');return;
  }

  const scene=new THREE.Scene(),root=new THREE.Group();scene.add(root);
  const camera=new THREE.OrthographicCamera(-2,2,1.5,-1.5,.1,10);camera.position.set(0,0,5);
  const height=3,width=height*art.width/art.height,unit=height/art.height;
  const toX=x=>(x-art.width/2)*unit,toY=y=>(art.height/2-y)*unit;
  const clamp=(n,a=0,b=1)=>Math.max(a,Math.min(b,n));
  function relief(x,y) {
    const ellipse=(cx,cy,rx,ry)=>Math.exp(-(((x-cx)/rx)**2+((y-cy)/ry)**2)*2);
    return .055*ellipse(724,255,290,330)+.067*ellipse(724,438,180,175)
      +.022*ellipse(724,405,33,100)+.045*ellipse(724,805,400,300);
  }
  const unique=values=>[...new Set(values.map(v=>Math.round(v*100)/100))].sort((a,b)=>a-b);
  const xs=unique([...Array.from({length:85},(_,i)=>art.width*i/84),
    ...Array.from({length:17},(_,i)=>art.mouthX-art.mouthRadius+art.mouthRadius*2*i/16)]);
  const ys=unique([...Array.from({length:75},(_,i)=>art.height*i/74),
    420,444,454,461,art.mouthY,480,494,514,542,art.chinY,592]);
  const seam=ys.indexOf(art.mouthY);ys.splice(seam+1,0,art.mouthY);
  const positions=[],uvs=[],base=[],weights=[],indices=[];
  for(let r=0;r<ys.length;r++)for(const x of xs){
    const mouthT=(x-art.mouthX)/art.mouthRadius;
    const round=clamp(1-mouthT*mouthT);
    const curve=-6*Math.pow(round,.65);
    const y=ys[r]+curve*clamp(1-Math.abs(ys[r]-art.mouthY)/24);
    const xyz=[toX(x),toY(y),relief(x,y)];positions.push(...xyz);base.push(...xyz);uvs.push(x/art.width,1-y/art.height);
    const side=clamp(1-((x-art.mouthX)/108)**2);
    let weight=0;
    if(r===seam+1)weight=Math.pow(round,.7);
    else if(r>seam+1){
      const below=ys[r]-art.mouthY;
      const falloff=below<26?1:clamp((art.chinY+14-ys[r])/(art.chinY+14-art.mouthY-26));
      const near=clamp(below/25);
      weight=(Math.pow(round,.7)*(1-near)+Math.pow(side,1.6)*near*.67)*falloff;
    }
    weights.push(weight);
  }
  const columns=xs.length;
  for(let r=0;r<ys.length-1;r++)for(let c=0;c<columns-1;c++){
    if(r===seam&&xs[c]>=art.mouthX-art.mouthRadius-.01&&xs[c+1]<=art.mouthX+art.mouthRadius+.01)continue;
    const a=r*columns+c,b=a+1,d=a+columns,e=d+1;indices.push(a,d,b,b,d,e);
  }
  const geometry=new THREE.BufferGeometry();
  geometry.setAttribute('position',new THREE.Float32BufferAttribute(positions,3));
  geometry.setAttribute('uv',new THREE.Float32BufferAttribute(uvs,2));
  geometry.setIndex(indices);geometry.computeVertexNormals();
  const texture=new THREE.TextureLoader().load(imageURL,()=>{
    if(disposed)return;loaded=true;host.classList.add('deckardModelReady');host.classList.remove('deckardUnavailable');resume();
  },undefined,()=>{
    if(disposed)return;host.classList.add('deckardUnavailable');
    window.dispatchEvent(new CustomEvent('studio-avatar-error',{detail:{message:'데커드 이미지를 불러오지 못했습니다.'}}));
  });
  texture.colorSpace=THREE.SRGBColorSpace;
  texture.anisotropy=Math.min(2,renderer.capabilities?.getMaxAnisotropy?.()||1);
  const material=new THREE.MeshBasicMaterial({map:texture,transparent:true,alphaTest:.015,side:THREE.DoubleSide});
  const portrait=new THREE.Mesh(geometry,material);portrait.name='DeckardArticulatedPortrait';root.add(portrait);

  // A recessed interior is exposed by the split lip seam, never painted on top.
  const inner=new THREE.Shape();
  inner.moveTo(toX(art.mouthX-art.mouthRadius),toY(art.mouthY+2));
  inner.quadraticCurveTo(toX(art.mouthX),toY(art.mouthY-14),toX(art.mouthX+art.mouthRadius),toY(art.mouthY+2));
  inner.quadraticCurveTo(toX(art.mouthX+40),toY(art.mouthY+48),toX(art.mouthX),toY(art.mouthY+50));
  inner.quadraticCurveTo(toX(art.mouthX-40),toY(art.mouthY+48),toX(art.mouthX-art.mouthRadius),toY(art.mouthY+2));
  const innerGeometry=new THREE.ShapeGeometry(inner,16);
  const innerMaterial=new THREE.MeshBasicMaterial({color:0x23343b,side:THREE.DoubleSide});
  const cavity=new THREE.Mesh(innerGeometry,innerMaterial);cavity.name='DeckardMouthInterior';
  cavity.position.z=relief(art.mouthX,art.mouthY)-.026;root.add(cavity);
  function setMouth(value){
    const p=geometry.attributes.position;
    for(let i=0;i<weights.length;i++){
      p.setY(i,base[i*3+1]-value*21*unit*weights[i]);
      p.setZ(i,base[i*3+2]-value*.004*weights[i]);
    }
    p.needsUpdate=true;cavity.visible=value>.005;
  }

  let active=false,visible=true,disposed=false,contextLost=false,loaded=false;
  let scheduled=0,lastFrame=0,lastDraw=performance.now();
  let timeline=null,liveLevel=0,liveAt=-Infinity,openness=0;
  const frameMs=1000/24;
  function sampleSpeech(now){
    if(timeline){
      const elapsed=now-timeline.started;
      if(elapsed>=timeline.duration){timeline=null;return 0;}
      const index=Math.max(0,elapsed/timeline.frameMs),low=Math.floor(index);
      const a=timeline.values[low]||0,b=timeline.values[low+1]??a;
      return a+(b-a)*(index-low);
    }
    return now-liveAt<180?liveLevel:0;
  }
  function closeMouth(){timeline=null;liveLevel=0;liveAt=-Infinity;openness=0;setMouth(0);}
  function render(now=performance.now()){
    if(disposed||contextLost)return;
    const dt=Math.min(.12,Math.max(.001,(now-lastDraw)/1000));lastDraw=now;
    const energy=clamp(sampleSpeech(now));
    const target=energy<.035?0:Math.pow((energy-.035)/.965,.64);
    openness+=(target-openness)*(1-Math.exp(-dt/(target>openness?.045:.09)));
    if(!timeline&&now-liveAt>=180&&openness<.003)openness=0;
    setMouth(openness);renderer.render(scene,camera);
  }
  function loop(now){
    scheduled=0;
    if(disposed||contextLost||!loaded||!active||document.hidden||!visible)return;
    if(now-lastFrame>=frameMs-.3){lastFrame=now;render(now);}
    if(timeline||now-liveAt<180||openness>0)scheduled=requestAnimationFrame(loop);
  }
  function resume(){
    if(scheduled){cancelAnimationFrame(scheduled);scheduled=0;}
    if(!disposed&&!contextLost&&loaded&&active&&!document.hidden&&visible){lastFrame=0;render();
      if(timeline||performance.now()-liveAt<180||openness>0)scheduled=requestAnimationFrame(loop);
    }
  }
  function resize(){
    if(disposed)return;
    const w=Math.max(1,host.clientWidth),h=Math.max(1,host.clientHeight),aspect=w/h;
    renderer.setPixelRatio(Math.min(window.devicePixelRatio||1,1.5));renderer.setSize(w,h,false);
    const viewHeight=Math.max(height*1.015,width/aspect*1.015),viewWidth=viewHeight*aspect;
    camera.left=-viewWidth/2;camera.right=viewWidth/2;camera.top=viewHeight/2;camera.bottom=-viewHeight/2;camera.updateProjectionMatrix();
    if(active&&loaded)render();
  }
  function selection(){
    const next=host.classList.contains('deckard');
    if(next!==active){active=next;closeMouth();canvas.hidden=!active;resize();resume();}
  }
  function speech(event){
    const detail=event.detail||{};
    if(detail.type==='stop'){closeMouth();resume();return;}
    if(!active||detail.character!=='deckard')return;
    if(detail.type==='start'&&Array.isArray(detail.envelope)){
      const values=detail.envelope.slice(0,6000).map(v=>Number.isFinite(v)?clamp(v):0);
      const step=Number.isFinite(detail.frame_ms)?clamp(detail.frame_ms,10,10000):40;
      const duration=Number.isFinite(detail.duration_ms)?Math.max(0,detail.duration_ms):values.length*step;
      const offset=Number.isFinite(detail.offset_ms)?Math.max(0,detail.offset_ms):0;
      timeline={values,frameMs:step,duration,started:performance.now()-offset};liveAt=-Infinity;
      if(offset>=duration)closeMouth();resume();
    }else if(detail.type==='level'){
      timeline=null;liveAt=performance.now();liveLevel=Number.isFinite(detail.level)?clamp(detail.level):0;resume();
    }
  }
  function dispose(){
    if(disposed)return;disposed=true;if(scheduled)cancelAnimationFrame(scheduled);
    resizeObserver.disconnect();selectionObserver.disconnect();intersection.disconnect();
    document.removeEventListener('visibilitychange',resume);window.removeEventListener('studio-speech',speech);
    reduced.removeEventListener('change',resume);window.removeEventListener('pageshow',resume);
    geometry.dispose();innerGeometry.dispose();material.dispose();innerMaterial.dispose();texture.dispose();renderer.dispose();
  }
  const resizeObserver=new ResizeObserver(resize);resizeObserver.observe(host);
  const selectionObserver=new MutationObserver(selection);selectionObserver.observe(host,{attributes:true,attributeFilter:['class']});
  const intersection=new IntersectionObserver(entries=>{visible=entries[0].isIntersecting;resume();});intersection.observe(host);
  document.addEventListener('visibilitychange',resume);reduced.addEventListener('change',resume);
  window.addEventListener('studio-speech',speech);window.addEventListener('pageshow',resume);
  window.addEventListener('pagehide',event=>{if(event.persisted){if(scheduled)cancelAnimationFrame(scheduled);scheduled=0;}else dispose();});
  canvas.addEventListener('webglcontextlost',event=>{event.preventDefault();contextLost=true;host.classList.add('deckardUnavailable');if(scheduled)cancelAnimationFrame(scheduled);scheduled=0;});
  canvas.addEventListener('webglcontextrestored',()=>{contextLost=false;host.classList.remove('deckardUnavailable');resume();});
  canvas.hidden=true;resize();selection();
}
