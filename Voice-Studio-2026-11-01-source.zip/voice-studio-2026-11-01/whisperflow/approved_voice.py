"""Private, approved voice presets shared by browser and MCP clients.

Reference audio and its local manifest live in .references, outside public source.
English has no override and continues through the existing Jarvis path.
"""
import io
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import tempfile
import threading
import queue
import wave

ROOT = Path(__file__).resolve().parents[1]
MANIFEST = ROOT / '.references/voice-presets.json'
_resident = None
_resident_lock = threading.Lock()


class VoiceWorker:
    """Keep model and reference conditioning alive between utterances."""
    def __init__(self):
        self.active=threading.Event()
        config=ROOT/'windows-config.json'
        values=json.loads(config.read_text(encoding='utf-8-sig')) if config.is_file() else {}
        python=os.environ.get('APPROVED_VOICE_PYTHON') or values.get('APPROVED_VOICE_PYTHON') or sys.executable
        self.responses=queue.Queue()
        log=ROOT/'.windows-data/approved-voice-worker.log'
        log.parent.mkdir(exist_ok=True,parents=True)
        with log.open('ab') as errors:
            self.process=subprocess.Popen([python,'-u','-m','whisperflow.approved_voice','--serve'],cwd=ROOT,
                stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=errors,
                **({'creationflags':subprocess.CREATE_NO_WINDOW} if os.name=='nt' else {}))
        threading.Thread(target=self.read,daemon=True).start()

    def read(self):
        try:
            for line in self.process.stdout:
                if line.startswith(b'WFVOICE '):
                    self.responses.put(json.loads(line[8:]))
        finally:
            self.responses.put({'error':'Voice generation was stopped.'})

    def run(self,request,output):
        self.active.set()
        try:
            self.process.stdin.write((json.dumps([str(request),str(output)])+'\n').encode('utf-8'))
            self.process.stdin.flush()
            try:
                result=self.responses.get(timeout=1800)
            except queue.Empty:
                self.close()
                raise RuntimeError('Voice generation timed out.')
            if result.get('error'):
                self.close()
                raise RuntimeError(result['error'])
            if not output.is_file():
                raise RuntimeError('Voice generation returned no recording.')
            return output.read_bytes()
        finally:
            self.active.clear()

    def close(self):
        if self.process.poll() is None:
            if os.name=='nt':
                subprocess.run(['taskkill','/PID',str(self.process.pid),'/T','/F'],
                    stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,creationflags=subprocess.CREATE_NO_WINDOW,timeout=10)
            else:
                self.process.kill()
            self.process.wait(timeout=10)


def stop_worker(only_busy=False, only_idle=False):
    global _resident
    with _resident_lock:
        if only_busy and (_resident is None or not _resident.active.is_set()):
            return
        if only_idle and (_resident is None or _resident.active.is_set()):
            return
        resident,_resident=_resident,None
    if resident:
        resident.close()


def resident_worker():
    global _resident
    with _resident_lock:
        if _resident is None or _resident.process.poll() is not None:
            _resident=VoiceWorker()
        return _resident


def prepare(preset):
    if preset.get('engine')!='icl':
        return
    parent=ROOT/'.windows-data/tmp'
    parent.mkdir(exist_ok=True,parents=True)
    with tempfile.TemporaryDirectory(dir=parent) as temporary:
        request,output=Path(temporary)/'request.json',Path(temporary)/'ready'
        request.write_text(json.dumps({'prepare':True,'preset':preset,'seed':preset['seed']}),encoding='utf-8')
        resident_worker().run(request,output)


def settings():
    return json.loads(MANIFEST.read_text(encoding='utf-8')) if MANIFEST.is_file() else {}


def profile(voice, language):
    return settings().get('profiles', {}).get(voice + ':' + language)


def status():
    data = settings()
    return {'preset_revision': data.get('revision'), 'approved_presets': {
        name: {'ready': (ROOT / value['reference']).is_file(),
               'engine': value['engine'], 'robot_effect': value.get('robot_effect','none')}
        for name, value in data.get('profiles', {}).items()}}


def cache_file(text,preset,seed,effect):
    if not preset.get('reference') or len(text)>200:
        return None
    reference=ROOT/preset['reference']
    if not reference.is_file():
        return None
    stat=reference.stat()
    value=json.dumps([text,preset,seed,effect,stat.st_size,stat.st_mtime_ns,'approved-audio-v1'],sort_keys=True,ensure_ascii=False)
    parent=ROOT/'.windows-data/voice-cache'
    parent.mkdir(exist_ok=True,parents=True)
    return parent/(hashlib.sha256(value.encode('utf-8')).hexdigest()+'.wav')


def chunks(text, maximum):
    # Preserve whole sentences where possible, bounding CPU generation and decoding.
    sentences = re.split(r'(?<=[.!?。！？])\s+|\n+', text.strip())
    result = []
    for sentence in sentences:
        while len(sentence) > maximum:
            boundary = sentence.rfind(' ', maximum // 2, maximum + 1)
            boundary = maximum if boundary < 1 else boundary
            result.append(sentence[:boundary].strip())
            sentence = sentence[boundary:].strip()
        if sentence:
            result.append(sentence)
    return result


def join_audio(parts, pause_ms=100):
    if len(parts) == 1:
        return parts[0]
    frames = []
    expected = None
    for part in parts:
        with wave.open(io.BytesIO(part), 'rb') as audio:
            params = audio.getparams()[:3]
            if expected is None:
                expected = params
            if params != expected or params != (1, 2, 24000):
                raise ValueError('Approved voices require mono PCM16 at 24kHz.')
            if frames:
                frames.append(b'\0\0' * (24000 * pause_ms // 1000))
            frames.append(audio.readframes(audio.getnframes()))
    output = io.BytesIO()
    with wave.open(output, 'wb') as audio:
        audio.setnchannels(1)
        audio.setsampwidth(2)
        audio.setframerate(24000)
        audio.writeframes(b''.join(frames))
    return output.getvalue()


def generate(text, preset, seed=None):
    reference = ROOT / preset['reference']
    if not reference.is_file():
        raise RuntimeError('The approved voice reference is not installed.')
    selected_seed = int(preset['seed'] if seed is None else seed)
    if preset['engine'] == 'native':
        from . import native_qwen
        # VoiceDesigner serializes generation and warmup with its lock. Release
        # only our idle Deckard worker before native CUDA needs the same VRAM.
        # Active speech is never stopped by a character switch here.
        if native_qwen.use_gpu():
            stop_worker(only_idle=True)
        parts = [native_qwen.generate(part, reference, 'ko', selected_seed,
                 sampling=preset.get('sampling'), max_frames=128)
                 for part in chunks(text, 70)]
        audio = join_audio(parts, preset.get('pause_ms',100))
    elif preset['engine'] == 'icl':
        parent = ROOT / '.windows-data/tmp'
        parent.mkdir(parents=True, exist_ok=True)
        with tempfile.TemporaryDirectory(dir=parent) as temporary:
            request, output = Path(temporary)/'request.json', Path(temporary)/'speech.wav'
            request.write_text(json.dumps({'text':text,'preset':preset,'seed':selected_seed},
                                         ensure_ascii=False), encoding='utf-8')
            audio = resident_worker().run(request,output)
    else:
        raise ValueError('Unknown approved voice engine.')
    if preset.get('filters'):
        import imageio_ffmpeg
        with tempfile.TemporaryDirectory() as temporary:
            source, target = Path(temporary)/'in.wav', Path(temporary)/'out.wav'
            source.write_bytes(audio)
            subprocess.run([imageio_ffmpeg.get_ffmpeg_exe(),'-v','error','-i',str(source),
                            '-af',preset['filters'],'-ar','24000','-ac','1','-y',str(target)],
                            check=True,capture_output=True,timeout=60,
                            **({'creationflags':subprocess.CREATE_NO_WINDOW} if os.name=='nt' else {}))
            audio = target.read_bytes()
    return audio


def normalize(audio):
    import numpy as np
    with wave.open(io.BytesIO(audio),'rb') as source:
        params = source.getparams()
        if params[:3] != (1,2,24000):
            raise ValueError('Unexpected approved voice audio format.')
        signal = np.frombuffer(source.readframes(source.getnframes()),dtype='<i2').astype(np.float32)/32768
    peak = float(np.max(np.abs(signal)))
    rms = float(np.sqrt(np.mean(signal**2)))
    if peak <= 0 or rms <= 0:
        raise RuntimeError('Voice generation returned silence.')
    signal *= min(.07/rms,.88/peak)
    output = io.BytesIO()
    with wave.open(output,'wb') as target:
        target.setparams(params)
        target.writeframes((signal*32768).round().clip(-32768,32767).astype('<i2').tobytes())
    return output.getvalue()


_model=None
_prompts={}


def worker(request_path, output_path):
    global _model
    import functools
    import random
    import numpy as np
    import soundfile as sf
    import torch
    os.environ.setdefault('HF_HOME',str(ROOT/'.models'))
    from qwen_tts import Qwen3TTSModel
    data = json.loads(Path(request_path).read_text(encoding='utf-8'))
    preset, seed = data['preset'], data['seed']
    if _model is None:
        torch.set_num_threads(4)
        torch.set_num_interop_threads(2)
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    snapshot = Path(os.environ['HF_HOME'])/'hub/models--Qwen--Qwen3-TTS-12Hz-0.6B-Base/snapshots'
    checkpoint = snapshot/preset.get('model_revision','5d83992436eae1d760afd27aff78a71d676296fc')
    model_name = str(checkpoint) if (checkpoint/'config.json').is_file() else 'Qwen/Qwen3-TTS-12Hz-0.6B-Base'
    if _model is None:
        device=os.environ.get('APPROVED_VOICE_DEVICE','auto')
        if device=='auto':
            device='cuda:0' if torch.cuda.is_available() else 'cpu'
        # Keep the audition's float32 precision. In particular, older GTX 16xx
        # half-precision kernels can produce invalid sampling probabilities.
        _model = Qwen3TTSModel.from_pretrained(model_name,
                  device_map=device,dtype=torch.float32,
                  attn_implementation='sdpa',low_cpu_mem_usage=True)
        decoder = _model.model.speech_tokenizer.model.decoder
        decoder.chunked_decode = functools.partial(decoder.chunked_decode,chunk_size=64,left_context_size=25)
    model=_model
    reference=ROOT/preset['reference']
    key=(str(reference),reference.stat().st_mtime_ns,preset['ref_text'])
    if key not in _prompts:
        _prompts[key]=model.create_voice_clone_prompt(ref_audio=str(reference),
                     ref_text=preset['ref_text'],x_vector_only_mode=False)
    prompt=_prompts[key]
    if data.get('prepare'):
        Path(output_path).write_bytes(b'ready')
        return
    parts = []
    # The approved audition uses one continuous paragraph; keep that where it fits.
    paragraphs, current = [], ''
    for sentence in chunks(data['text'],120):
        if current and len(current)+len(sentence)+1 > 120:
            paragraphs.append(current)
            current = ''
        current = (current+' '+sentence).strip()
    if current:
        paragraphs.append(current)
    for text in paragraphs:
        count = [0]
        def progress(module,args,result):
            count[0] += 1
        handle = model.model.talker.register_forward_hook(progress)
        with torch.inference_mode():
            waves,rate = model.generate_voice_clone(text=text,language='Korean',voice_clone_prompt=prompt,
                non_streaming_mode=True,do_sample=True,temperature=.65,top_k=40,top_p=.9,
                subtalker_temperature=.65,subtalker_top_k=40,subtalker_top_p=.9,
                repetition_penalty=1.05,max_new_tokens=512)
        handle.remove()
        if count[0] >= 512:
            raise RuntimeError('Voice generation reached its limit; shorten this speech request.')
        output = io.BytesIO()
        sf.write(output,waves[0],rate,format='WAV',subtype='PCM_16')
        parts.append(output.getvalue())
    Path(output_path).write_bytes(join_audio(parts,150))


if __name__ == '__main__':
    if sys.argv[1:] == ['--serve']:
        import contextlib
        for line in sys.stdin:
            try:
                request,output=json.loads(line)
                with contextlib.redirect_stdout(sys.stderr):
                    worker(request,output)
                result={'ok':True}
            except Exception as error:
                import traceback
                traceback.print_exc(file=sys.stderr)
                result={'error':str(error)}
            print('WFVOICE '+json.dumps(result),flush=True)
    else:
        worker(sys.argv[1],sys.argv[2])
