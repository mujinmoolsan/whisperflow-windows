"""Wake names, personas and language/provider selection for the Windows companion."""
import re

WAKE=re.compile(r'^\s*(자비스|자비서|저비스|jarvis|데커드|데카드|데커트|deckard)(?:야|아)?(?=\s|[,，.!?]|$)[\s,，.!?]*',re.I)
STOP=re.compile(r'^(?:그만|멈춰|멈추어|정지|취소|긴급\s*정지|stop|cancel)(?:해|줘|주세요|시켜)?[.!?\s]*$',re.I)


def parse_command(text, character='jarvis', language='ko', provider='codex', require_wake=False, armed=False):
    text=text.strip()
    wake=WAKE.match(text)
    if wake:
        name=wake.group(1).lower()
        character='deckard' if name.startswith(('데','deck')) else 'jarvis'
        language='ko'
        text=text[wake.end():].strip()
    if require_wake and not wake and not armed and not STOP.fullmatch(text):
        return {'accepted':False,'reason':'wake_required'}
    if STOP.fullmatch(text):
        return {'accepted':True,'action':'stop','character':character,'language':language,'provider':provider,'text':''}
    language_command=re.match(r'^(?:영어(?:로|\s*모드)?|english(?:\s+mode)?)\s*[,，:]?\s*',text,re.I)
    korean_command=re.match(r'^(?:한국어(?:로|\s*모드)?|korean(?:\s+mode)?)\s*[,，:]?\s*',text,re.I)
    if language_command:
        if character=='deckard':
            return {'accepted':False,'reason':'deckard_korean_only'}
        language='en'
        text=text[language_command.end():].strip()
    elif korean_command:
        language='ko'
        text=text[korean_command.end():].strip()
    selection=re.match(r'^(지피티|gpt|코덱스|codex|클로드|claude)(?:(?:한테|에게|로|를|으로)\s*)?\s*[,，:]?\s*',text,re.I)
    if selection:
        provider='claude' if selection.group(1).lower() in ('클로드','claude') else 'codex'
        text=text[selection.end():].strip()
    return {'accepted':True,'action':'command' if text else 'wake','character':character,
            'language':language,'provider':provider,'text':text,'woke':bool(wake)}


def persona(character,language):
    if character=='deckard':
        return ('사용자를 친구라고 부르는 든든하고 따뜻한 로봇 경찰 동료 말투로 응답하세요. '
                '답변 첫머리에 자연스럽게 "친구야,"라고 부르고 친근한 한국어 반말을 쓰세요. '
                '차분하고 명확하게 말하고 과장된 연기나 반복적인 구호는 피하세요.')
    if language=='en':
        return ('Respond in English with calm, refined, concise and polite delivery. '
                'Use restrained wit only when appropriate. Do not translate the task itself.')
    return ('차분하고 정확한 개인 비서 말투로 한국어 존댓말을 쓰세요. '
            '정중하고 간결하게 답하고 사용자에게 반말하지 마세요.')


def short_message(character,kind,language='ko'):
    if character=='deckard':
        return {'wake':'친구야, 듣고 있어.','completed':'친구야, 요청한 작업을 마쳤어.',
                'failed':'친구야, 작업을 끝내지 못했어. 화면을 확인해 줘.',
                'stopped':'친구야, 작업을 멈췄어.'}[kind]
    if language=='en':
        return {'wake':'Yes, I am listening.','completed':'Your task is complete.',
                'failed':'I could not finish the task. Please check the screen.',
                'stopped':'The task has been stopped.'}[kind]
    return {'wake':'네, 듣고 있습니다.','completed':'요청하신 작업을 완료했습니다.',
            'failed':'작업을 완료하지 못했습니다. 화면을 확인해 주십시오.',
            'stopped':'작업을 중지했습니다.'}[kind]
