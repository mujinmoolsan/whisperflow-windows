"""Conservative robotic coloration, preserving the underlying character voice."""
import io
from pathlib import Path
import subprocess
import tempfile
import wave


def robot_effect(audio, strength='soft'):
    if strength == 'none':
        return audio
    if strength not in ('soft', 'strong'):
        raise ValueError('Choose none, soft or strong robot effect.')
    import numpy as np
    import imageio_ffmpeg
    with wave.open(io.BytesIO(audio), 'rb') as source:
        rate = source.getframerate()
        if source.getnchannels() != 1 or source.getsampwidth() != 2:
            raise ValueError('Robot processing expects mono PCM16 WAV.')
        signal = np.frombuffer(source.readframes(source.getnframes()), dtype='<i2').astype(np.float32) / 32768
    amount, carrier, delay, gain = (.20, 62, 4.2, .14) if strength == 'soft' else (.38, 82, 5., .22)
    time = np.arange(len(signal)) / rate
    signal *= ((1 - amount) + amount * np.cos(2 * np.pi * carrier * time))
    with tempfile.TemporaryDirectory() as temporary:
        source, target = Path(temporary) / 'input.wav', Path(temporary) / 'output.wav'
        with wave.open(str(source), 'wb') as file:
            file.setnchannels(1)
            file.setsampwidth(2)
            file.setframerate(rate)
            file.writeframes((np.clip(signal, -1, 1) * 32767).astype('<i2').tobytes())
        filters = (f'highpass=f=110,lowpass=f=7800,equalizer=f=1150:t=q:w=2:g=2.5,'
                   f'aecho=0.8:0.88:{delay}|{delay*2}:{gain}|{gain/2},'
                   'acompressor=threshold=0.16:ratio=2:attack=5:release=70:makeup=1.3,alimiter=limit=0.92')
        subprocess.run([imageio_ffmpeg.get_ffmpeg_exe(), '-v', 'error', '-i', str(source),
                        '-af', filters, '-ac', '1', '-ar', str(rate), '-y', str(target)],
                       check=True, capture_output=True, timeout=30)
        return target.read_bytes()
