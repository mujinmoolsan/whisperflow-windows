"""Desktop actions for the user's standalone Windows voice application."""
import base64
import ctypes
from ctypes import wintypes
import io
import os
from pathlib import Path
import subprocess
import time
import uuid
import webbrowser
from urllib.parse import urlparse


class Desktop:
    def __init__(self):
        self.snapshots={}
        if os.name=='nt':
            with __import__('contextlib').suppress(OSError,AttributeError):
                ctypes.windll.user32.SetProcessDpiAwarenessContext(ctypes.c_void_p(-4))

    @property
    def user32(self):
        if os.name!='nt':
            raise RuntimeError('Desktop control requires Windows.')
        api=ctypes.windll.user32
        api.GetWindowTextW.argtypes=[wintypes.HWND,wintypes.LPWSTR,ctypes.c_int]
        api.GetWindowThreadProcessId.argtypes=[wintypes.HWND,ctypes.POINTER(wintypes.DWORD)]
        api.IsWindowVisible.argtypes=[wintypes.HWND]
        api.SetForegroundWindow.argtypes=[wintypes.HWND]
        api.ShowWindow.argtypes=[wintypes.HWND,ctypes.c_int]
        return api

    def foreground(self):
        api=self.user32
        api.GetForegroundWindow.restype=wintypes.HWND
        handle=api.GetForegroundWindow()
        text=ctypes.create_unicode_buffer(1024)
        api.GetWindowTextW(handle,text,1024)
        pid=wintypes.DWORD()
        api.GetWindowThreadProcessId(handle,ctypes.byref(pid))
        return {'handle':int(handle or 0),'title':text.value,'pid':pid.value}

    def windows(self):
        api=self.user32
        result=[]
        callback_type=ctypes.WINFUNCTYPE(wintypes.BOOL,wintypes.HWND,wintypes.LPARAM)
        def visit(handle,_):
            if api.IsWindowVisible(handle):
                title=ctypes.create_unicode_buffer(512)
                api.GetWindowTextW(handle,title,512)
                if title.value:
                    result.append({'handle':int(handle),'title':title.value})
            return True
        api.EnumWindows(callback_type(visit),0)
        return result[:60]

    def observe(self):
        from PIL import ImageGrab
        image=ImageGrab.grab(all_screens=True)
        width,height=image.size
        image.thumbnail((1600,1200))
        stream=io.BytesIO()
        image.save(stream,format='PNG')
        snapshot=uuid.uuid4().hex
        foreground=self.foreground()
        self.snapshots={snapshot:{'created':time.monotonic(),'foreground':foreground,
            'width':width,'height':height,'rendered_width':image.width,'rendered_height':image.height,
            'origin_x':self.user32.GetSystemMetrics(76),'origin_y':self.user32.GetSystemMetrics(77)}}
        return {'snapshot_id':snapshot,'image':base64.b64encode(stream.getvalue()).decode(),
                'width':image.width,'height':image.height,'foreground':foreground,'windows':self.windows()}

    def require_snapshot(self,snapshot):
        value=self.snapshots.get(snapshot)
        if not value or time.monotonic()-value['created']>120:
            raise ValueError('Observe the desktop again before acting.')
        if self.foreground()['handle']!=value['foreground']['handle']:
            raise ValueError('The foreground window changed. Observe again before acting.')
        return value

    def require_editable_app(self):
        state=self.foreground()
        kernel=ctypes.windll.kernel32
        kernel.OpenProcess.argtypes=[wintypes.DWORD,wintypes.BOOL,wintypes.DWORD]
        kernel.OpenProcess.restype=wintypes.HANDLE
        handle=kernel.OpenProcess(0x1000,False,state['pid'])
        if not handle:
            raise RuntimeError('Cannot verify the focused application.')
        try:
            path=ctypes.create_unicode_buffer(2048)
            length=wintypes.DWORD(len(path))
            kernel.QueryFullProcessImageNameW.argtypes=[wintypes.HANDLE,wintypes.DWORD,wintypes.LPWSTR,ctypes.POINTER(wintypes.DWORD)]
            if not kernel.QueryFullProcessImageNameW(handle,0,path,ctypes.byref(length)):
                raise RuntimeError('Cannot verify the focused application.')
            name=Path(path.value).name.lower()
            if name in {'cmd.exe','powershell.exe','pwsh.exe','windowsterminal.exe','lockapp.exe','consent.exe','credentialuibroker.exe','keepass.exe','1password.exe'}:
                raise ValueError('This window requires direct user control. Use file tools for workspace commands.')
        finally:
            kernel.CloseHandle.argtypes=[wintypes.HANDLE]
            kernel.CloseHandle(handle)

    def open_app(self,name):
        system=Path(os.environ.get('WINDIR','C:/Windows'))/'System32'
        apps={'notepad':system/'notepad.exe','calculator':system/'calc.exe','explorer':system.parent/'explorer.exe',
              'paint':system/'mspaint.exe'}
        if name=='chrome':
            choices=[Path(os.environ.get('PROGRAMFILES','C:/Program Files'))/'Google/Chrome/Application/chrome.exe',
                     Path(os.environ.get('PROGRAMFILES(X86)','C:/Program Files (x86)'))/'Google/Chrome/Application/chrome.exe',
                     Path(os.environ.get('LOCALAPPDATA',''))/'Google/Chrome/Application/chrome.exe']
            apps[name]=next((item for item in choices if item.is_file()),None)
        if name not in apps or apps[name] is None:
            raise ValueError('Choose notepad, calculator, explorer, paint or chrome.')
        subprocess.Popen([str(apps[name])],stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
        self.snapshots.clear()
        return {'opened':name}

    def action(self,data):
        action=data.get('action')
        if action=='open_app':
            return self.open_app(data.get('app'))
        if action=='open_url':
            url=data.get('url','')
            parsed=urlparse(url)
            if parsed.scheme not in ('https','http') or not parsed.netloc:
                raise ValueError('Only HTTP and HTTPS URLs may be opened.')
            webbrowser.open(url)
            self.snapshots.clear()
            return {'opened':url}
        snapshot=self.require_snapshot(data.get('snapshot_id'))
        api=self.user32
        if action=='focus':
            handle=int(data['window_handle'])
            if handle not in {item['handle'] for item in self.windows()}:
                raise ValueError('Choose a window returned by desktop_observe.')
            api.ShowWindow(wintypes.HWND(handle),9)
            if not api.SetForegroundWindow(wintypes.HWND(handle)):
                raise RuntimeError('Windows did not allow focus to change. Select the app manually.')
        elif action=='click':
            self.require_editable_app()
            x,y=float(data['x']),float(data['y'])
            if not 0<=x<snapshot['rendered_width'] or not 0<=y<snapshot['rendered_height']:
                raise ValueError('Click coordinates must come from the latest screenshot.')
            api.SetCursorPos(round(x*snapshot['width']/snapshot['rendered_width'])+snapshot['origin_x'],
                             round(y*snapshot['height']/snapshot['rendered_height'])+snapshot['origin_y'])
            flags=(0x0008,0x0010) if data.get('button')=='right' else (0x0002,0x0004)
            for flag in flags:
                api.mouse_event(flag,0,0,0,0)
        elif action in ('type','press_key'):
            self.require_editable_app()
            self.keyboard(data)
        elif action=='scroll':
            self.require_editable_app()
            amount=max(-10,min(10,int(data.get('steps',-3))))
            api.mouse_event(0x0800,0,0,ctypes.c_uint32(amount*120).value,0)
        else:
            raise ValueError('Unsupported desktop action.')
        self.snapshots.clear()
        return {'done':action,'foreground':self.foreground(),'next':'Observe again before the next input.'}

    def keyboard(self,data):
        pointer=ctypes.c_ulonglong if ctypes.sizeof(ctypes.c_void_p)==8 else ctypes.c_ulong
        class Keyboard(ctypes.Structure):
            _fields_=[('virtual',wintypes.WORD),('scan',wintypes.WORD),('flags',wintypes.DWORD),('time',wintypes.DWORD),('extra',pointer)]
        class Mouse(ctypes.Structure):
            _fields_=[('x',wintypes.LONG),('y',wintypes.LONG),('data',wintypes.DWORD),('flags',wintypes.DWORD),('time',wintypes.DWORD),('extra',pointer)]
        class Union(ctypes.Union):
            _fields_=[('keyboard',Keyboard),('mouse',Mouse)]
        class Input(ctypes.Structure):
            _fields_=[('type',wintypes.DWORD),('value',Union)]
        events=[]
        if data['action']=='type':
            text=str(data.get('text',''))
            if not 1<=len(text)<=4000:
                raise ValueError('Type between 1 and 4000 characters.')
            encoded=text.encode('utf-16-le')
            for index in range(0,len(encoded),2):
                scan=int.from_bytes(encoded[index:index+2],'little')
                for flags in (0x0004,0x0006):
                    events.append(Input(1,Union(keyboard=Keyboard(0,scan,flags,0,0))))
        else:
            names=str(data.get('key','')).lower().split('+')
            keys={'ctrl':0x11,'control':0x11,'shift':0x10,'alt':0x12,'enter':13,'tab':9,'escape':27,'esc':27,
                  'backspace':8,'delete':46,'space':32,'left':37,'up':38,'right':39,'down':40,'home':36,'end':35,
                  'pageup':33,'pagedown':34,**{chr(n):n for n in range(65,91)},**{str(n):48+n for n in range(10)},
                  **{f'f{n}':111+n for n in range(1,13)}}
            keys.update({key.lower():value for key,value in list(keys.items())})
            if not 1<=len(names)<=3 or any(name not in keys for name in names):
                raise ValueError('Unsupported shortcut. Windows-key shortcuts are not enabled.')
            for name in names:
                events.append(Input(1,Union(keyboard=Keyboard(keys[name],0,0,0,0))))
            for name in reversed(names):
                events.append(Input(1,Union(keyboard=Keyboard(keys[name],0,0x0002,0,0))))
        inputs=(Input*len(events))(*events)
        self.user32.SendInput.argtypes=[wintypes.UINT,ctypes.POINTER(Input),ctypes.c_int]
        if self.user32.SendInput(len(events),inputs,ctypes.sizeof(Input))!=len(events):
            raise RuntimeError('Windows did not accept this keyboard input.')
