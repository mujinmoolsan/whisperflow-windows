"""Reusable local recognition process; one recording at a time, bounded lifetime."""
import asyncio
import contextlib
import os
import sys


class SpeechWorker:
    def __init__(self, root):
        self.root = root
        self.process = None
        self.lock = asyncio.Lock()

    async def transcribe(self, source, output):
        import json
        async with self.lock:
            if self.process is None or self.process.returncode is not None:
                self.process = await asyncio.create_subprocess_exec(
                    sys.executable, '-u', '-m', 'whisperflow.speech_input', '--serve',
                    cwd=str(self.root), stdin=asyncio.subprocess.PIPE,
                    stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.DEVNULL,
                    **({'creationflags': 0x08000000} if os.name == 'nt' else {}))
            try:
                self.process.stdin.write((json.dumps([str(source), str(output)])+'\n').encode())
                await self.process.stdin.drain()
                async with asyncio.timeout(120):
                    while True:
                        line = await self.process.stdout.readline()
                        if not line:
                            raise RuntimeError('음성 인식 프로세스가 종료되었습니다.')
                        if line.startswith(b'WFASR '):
                            result = json.loads(line[6:])
                            if result.get('error'):
                                raise RuntimeError(result['error'])
                            return json.loads(output.read_text(encoding='utf-8'))
            except BaseException:
                await self.close()
                raise

    async def close(self):
        process, self.process = self.process, None
        if process and process.returncode is None:
            with contextlib.suppress(ProcessLookupError):
                process.kill()
            await process.wait()
