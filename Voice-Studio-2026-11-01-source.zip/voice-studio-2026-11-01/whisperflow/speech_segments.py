"""Complete speech segments, preserving words, punctuation and approved voices."""
import re


def segments(text, limit=48):
    result = []
    for sentence in re.split(r'(?<=[.!?。！？])\s+|\n+', text.strip()):
        while len(sentence) > limit:
            boundary = sentence.rfind(' ', limit // 2, limit + 1)
            if boundary < 1:
                break
            result.append(sentence[:boundary].strip())
            sentence = sentence[boundary:].strip()
        if sentence:
            result.append(sentence)
    return result
