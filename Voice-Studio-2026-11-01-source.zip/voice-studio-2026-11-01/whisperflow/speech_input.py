"""Local microphone recording recognition. Audio is never uploaded by this module."""
import json
import os
from pathlib import Path
import sys

_processor = None
_model = None


def transcribe(source,output):
    global _processor, _model
    import numpy as np
    import soundfile as sf
    import torch
    from scipy.signal import resample_poly
    from math import gcd
    from transformers import WhisperProcessor,WhisperForConditionalGeneration
    torch.set_num_threads(4)
    audio,rate=sf.read(source,dtype='float32')
    if audio.ndim==2:
        audio=audio.mean(1)
    if not .25<=len(audio)/rate<=30:
        raise ValueError('Record a command between 0.25 and 30 seconds.')
    divisor=gcd(rate,16000)
    audio=resample_poly(audio,16000//divisor,rate//divisor).astype(np.float32)
    name='openai/whisper-small'
    if _model is None:
        _processor=WhisperProcessor.from_pretrained(name)
        _model=WhisperForConditionalGeneration.from_pretrained(name,dtype=torch.float32).eval()
    processor, model = _processor, _model
    inputs=processor(audio,sampling_rate=16000,return_tensors='pt')
    prompt=processor.get_prompt_ids('자비스, 데커드, 지피티, 클로드. 친구야. 계산기. 메모장.',return_tensors='pt')
    with torch.inference_mode():
        generated=model.generate(**inputs,language='korean',task='transcribe',prompt_ids=prompt,
                                 max_new_tokens=180,num_beams=3)
    text=processor.batch_decode(generated,skip_special_tokens=True)[0].strip()
    Path(output).write_text(json.dumps({'text':text},ensure_ascii=False),encoding='utf-8')


if __name__=='__main__':
    root=Path(__file__).resolve().parents[1]
    os.environ.setdefault('HF_HOME',str(root/'.models'))
    if sys.argv[1:] == ['--serve']:
        import contextlib
        for line in sys.stdin:
            try:
                source, output = json.loads(line)
                with contextlib.redirect_stdout(sys.stderr):
                    transcribe(source, output)
                result = {'ok': True}
            except Exception as error:
                result = {'error': str(error)}
            print('WFASR '+json.dumps(result), flush=True)
    else:
        transcribe(sys.argv[1],sys.argv[2])
