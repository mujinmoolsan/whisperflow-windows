"""Small-process Qwen GGUF backend, using an official llama.cpp Windows build."""
import os
from pathlib import Path
import subprocess
import tempfile
import threading

ROOT = Path(__file__).resolve().parents[1]
_process=None
_process_lock=threading.Lock()


def stop_pending():
    with _process_lock:
        if _process is not None and _process.poll() is None:
            _process.kill()


def paths():
    runtime = Path(os.getenv('JARVIS_NATIVE_DIR', ROOT / '.native/llama'))
    models = Path(os.getenv('JARVIS_NATIVE_MODEL_DIR', ROOT / '.models/gguf'))
    return runtime / 'llama-tts.exe', models / 'tts-q4.gguf', models / 'codec-q8.gguf'


def available():
    return all(path.is_file() for path in paths())


def generate(text, reference, language, seed=42, *, sampling=None, max_frames=None):
    global _process
    executable, model, codec = paths()
    if not available():
        raise RuntimeError('Run Setup-Native-Qwen.cmd first.')
    parent = ROOT / '.windows-data/tmp'
    parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(dir=parent) as temporary:
        output = Path(temporary) / 'speech.wav'
        # The native TTS file readers do not reliably handle absolute non-ASCII
        # Windows paths. Relative paths keep Unicode home names out of those readers.
        def relative(path):
            try:
                return os.path.relpath(path, ROOT)
            except ValueError:
                return str(path)
        command = [str(executable), '-m', relative(model), '--mmproj', relative(codec),
                   '-p', text, '--tts-lang', language, '--tts-speaker-file', relative(reference),
                   '--output', relative(output), '-ngl', '0', '-t', '4',
                   '-n', str(max_frames or min(1024, max(96, len(text) * 6))),
                   '-b', '64', '-ub', '64', '-c', '1024',
                   '--seed', str(seed), '--repeat-penalty', '1.05']
        for name, flag in (('temperature','--temp'),('top_k','--top-k'),('top_p','--top-p')):
            if sampling and name in sampling:
                command.extend([flag, str(sampling[name])])
        with _process_lock:
            process = subprocess.Popen(command,cwd=str(ROOT),stdout=subprocess.PIPE,stderr=subprocess.PIPE,
                **({'creationflags': subprocess.CREATE_NO_WINDOW} if os.name == 'nt' else {}))
            _process=process
        try:
            _,errors=process.communicate(timeout=300)
        except subprocess.TimeoutExpired:
            process.kill()
            process.communicate()
            raise
        finally:
            with _process_lock:
                if _process is process:
                    _process=None
        if process.returncode or not output.is_file():
            (parent.parent/'native-error.log').write_bytes(errors)
            raise RuntimeError('Local Qwen synthesis failed. Check the runtime and model files.')
        return output.read_bytes()
