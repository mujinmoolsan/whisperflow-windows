"""Small-process Qwen GGUF backend, using an official llama.cpp Windows build.

GPU: when Setup-GPU.cmd has installed the official CUDA build into .native/llama-cuda,
that build is used with all layers on the NVIDIA GPU. If it fails once, this process
falls back to the CPU build for the rest of its life and records why in native-error.log.
"""
import os
from pathlib import Path
import subprocess
import tempfile
import threading

ROOT = Path(__file__).resolve().parents[1]
_process=None
_process_lock=threading.Lock()
_cuda_failed=False


class SynthesisCancelled(RuntimeError):
    """The pending synthesis was stopped on purpose; not an engine failure."""


def stop_pending():
    with _process_lock:
        if _process is not None and _process.poll() is None:
            _process.jarvis_cancelled = True
            _process.kill()


def _cpu_dir():
    return Path(os.getenv('JARVIS_NATIVE_DIR', ROOT / '.native/llama'))


def _cuda_dir():
    return Path(os.getenv('JARVIS_NATIVE_CUDA_DIR', ROOT / '.native/llama-cuda'))


def use_gpu():
    if _cuda_failed or os.getenv('JARVIS_FORCE_CPU') == '1':
        return False
    return (_cuda_dir() / 'llama-tts.exe').is_file()


def _threads():
    value = os.getenv('JARVIS_THREADS')
    if value and value.isdigit():
        return value
    return str(max(4, (os.cpu_count() or 8) // 2))


def paths():
    runtime = _cuda_dir() if use_gpu() else _cpu_dir()
    models = Path(os.getenv('JARVIS_NATIVE_MODEL_DIR', ROOT / '.models/gguf'))
    return runtime / 'llama-tts.exe', models / 'tts-q4.gguf', models / 'codec-q8.gguf'


def available():
    return all(path.is_file() for path in paths())


def generate(text, reference, language, seed=42, *, sampling=None, max_frames=None):
    global _cuda_failed
    executable, model, codec = paths()
    if not available():
        raise RuntimeError('Run Setup-Native-Qwen.cmd first.')
    gpu = executable.parent.resolve() == _cuda_dir().resolve()
    try:
        return _run(executable, model, codec, text, reference, language, seed, sampling, max_frames, gpu)
    except SynthesisCancelled:
        raise
    except (RuntimeError, subprocess.TimeoutExpired):
        cpu = _cpu_dir() / 'llama-tts.exe'
        if not gpu or not cpu.is_file():
            raise
        audio = _run(cpu, model, codec, text, reference, language, seed, sampling, max_frames, False)
        # Only blame the GPU when the same request works on the CPU build.
        _cuda_failed = True
        return audio


def _run(executable, model, codec, text, reference, language, seed, sampling, max_frames, gpu):
    global _process
    parent = ROOT / '.windows-data/tmp'
    parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(dir=parent) as temporary:
        output = Path(temporary) / 'speech.wav'
        # The native TTS file readers do not reliably handle absolute non-ASCII
        # Windows paths. Relative paths keep Unicode home names out of those readers.
        def relative(path):
            try:
                return os.path.relpath(path, ROOT)
            except ValueError:
                return str(path)
        command = [str(executable), '-m', relative(model), '--mmproj', relative(codec),
                   '-p', text, '--tts-lang', language, '--tts-speaker-file', relative(reference),
                   '--output', relative(output), '-ngl', (os.getenv('JARVIS_GPU_LAYERS', '99') if gpu else '0'), '-t', _threads(),
                   '-n', str(max_frames or min(1024, max(96, len(text) * 6))),
                   '-b', '64', '-ub', '64', '-c', '1024',
                   '--seed', str(seed), '--repeat-penalty', '1.05']
        for name, flag in (('temperature','--temp'),('top_k','--top-k'),('top_p','--top-p')):
            if sampling and name in sampling:
                command.extend([flag, str(sampling[name])])
        with _process_lock:
            process = subprocess.Popen(command,cwd=str(ROOT),stdout=subprocess.PIPE,stderr=subprocess.PIPE,
                **({'creationflags': subprocess.CREATE_NO_WINDOW} if os.name == 'nt' else {}))
            _process=process
        try:
            _,errors=process.communicate(timeout=120 if gpu else 300)
        except subprocess.TimeoutExpired:
            process.kill()
            process.communicate()
            raise
        finally:
            with _process_lock:
                if _process is process:
                    _process=None
        if getattr(process, 'jarvis_cancelled', False):
            raise SynthesisCancelled('Local Qwen synthesis was stopped.')
        if process.returncode or not output.is_file():
            (parent.parent/'native-error.log').write_bytes((b'[GPU]\n' if gpu else b'[CPU]\n') + (errors or b''))
            raise RuntimeError('Local Qwen synthesis failed. Check the runtime and model files.')
        return output.read_bytes()
