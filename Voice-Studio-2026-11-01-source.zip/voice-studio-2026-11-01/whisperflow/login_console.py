"""Visible, interactive login only; no credential capture or storage."""
import subprocess
import sys


def main():
    provider,path=sys.argv[1:]
    if provider not in ('codex','claude'):
        raise SystemExit('Unsupported provider')
    print('음성 작업실 계정 연결',flush=True)
    print('브라우저가 열리면 직접 로그인해 주세요. 완료 후 음성 작업실에서 연결 상태를 갱신합니다.',flush=True)
    args=[path,'login'] if provider=='codex' else [path,'auth','login']
    try:
        result=subprocess.run(args,check=False)
        if result.returncode:
            print('\n로그인을 완료하지 못했습니다. 위 안내를 확인하고 다시 시도해 주세요.',flush=True)
            input('이 창을 닫으려면 Enter를 누르세요. ')
        raise SystemExit(result.returncode)
    except OSError as error:
        print('\n로그인 프로그램을 실행하지 못했습니다: '+str(error),flush=True)
        input('이 창을 닫으려면 Enter를 누르세요. ')
        raise SystemExit(1)


if __name__=='__main__':
    main()
