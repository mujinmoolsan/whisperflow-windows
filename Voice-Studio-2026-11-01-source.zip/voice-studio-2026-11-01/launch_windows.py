"""Double-click bootstrap: install only the small browser-server dependency locally."""
import argparse
import importlib.util
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent


def main():
    if sys.version_info < (3, 11):
        raise SystemExit('Python 3.11 or newer is required. Install Python from python.org.')
    parser = argparse.ArgumentParser()
    parser.add_argument('--no-open', action='store_true')
    parser.add_argument('--port', type=int, default=8767)
    args = parser.parse_args()
    dependencies = ROOT / '.windows-env'
    sys.path.insert(0, str(dependencies))
    if importlib.util.find_spec('websockets') is None:
        print('Preparing the local browser server (first launch only)...', flush=True)
        subprocess.run([sys.executable, '-m', 'pip', 'install', '--target', str(dependencies),
                        '-r', str(ROOT / 'requirements-windows.txt')], check=True)
    # Read only the non-secret configuration entries needed by this application.
    config = ROOT / 'windows-config.json'
    if config.exists():
        import json
        values = json.loads(config.read_text(encoding='utf-8-sig'))
        for key in ('QWEN_TTS_URL', 'JARVIS_CLAUDE_PATH', 'JARVIS_TTS_VOICE', 'JARVIS_TTS_SPEED', 'JARVIS_GPT_MODEL'):
            if values.get(key) is not None:
                os.environ[key] = str(values[key])
    from whisperflow.windows import run
    import asyncio
    try:
        asyncio.run(run(args.port, open_browser=not args.no_open))
    except KeyboardInterrupt:
        pass


if __name__ == '__main__':
    main()
