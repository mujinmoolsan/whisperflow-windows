"""Start the local voice companion; keep background helpers out of the way."""
import argparse
import json
import os
from pathlib import Path
import subprocess
import time
import urllib.request
import webbrowser
from launch_qwen_windows import runtime

ROOT=Path(__file__).resolve().parent


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--no-open',action='store_true')
    parser.add_argument('--foreground',action='store_true')
    parser.add_argument('--port',type=int,default=8770)
    args=parser.parse_args()
    url=f'http://127.0.0.1:{args.port}'
    environment=dict(os.environ)
    config=ROOT/'windows-config.json'
    if config.is_file():
        values=json.loads(config.read_text(encoding='utf-8-sig'))
        for key in ('HF_HOME','JARVIS_CODEX_PATH','JARVIS_CLAUDE_PATH','JARVIS_NATIVE_DIR','JARVIS_NATIVE_MODEL_DIR','QWEN_TTS_URL'):
            if values.get(key):
                environment[key]=str(values[key])
    command=[str(runtime()),'-m','whisperflow.companion','--port',str(args.port),'--no-open']
    if args.foreground:
        raise SystemExit(subprocess.call(command,cwd=ROOT,env=environment))
    try:
        urllib.request.urlopen(url+'/api/status',timeout=2).close()
    except OSError:
        folder=ROOT/'.windows-data'
        folder.mkdir(exist_ok=True)
        with (folder/'companion.log').open('ab') as log:
            subprocess.Popen(command,cwd=ROOT,env=environment,stdin=subprocess.DEVNULL,stdout=log,stderr=log,
                             **({'creationflags':subprocess.CREATE_NO_WINDOW} if os.name=='nt' else {}))
        for _ in range(40):
            time.sleep(.25)
            try:
                urllib.request.urlopen(url+'/api/status',timeout=2).close()
                break
            except OSError:
                continue
        else:
            raise RuntimeError('프로그램을 시작하지 못했습니다. .windows-data/companion.log를 확인해 주세요.')
    if not args.no_open:
        webbrowser.open(url)
    print('음성 작업실: '+url)


if __name__=='__main__':
    main()
