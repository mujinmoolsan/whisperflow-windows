"""Prepare a PRIVATE reference clip. Never adds recordings to Git."""
import argparse
from pathlib import Path
import subprocess


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('source', type=Path)
    parser.add_argument('--character', choices=['jarvis', 'deckard'], required=True)
    parser.add_argument('--start', type=float, default=0)
    parser.add_argument('--duration', type=float, default=12)
    args = parser.parse_args()
    if not args.source.is_file() or args.start < 0 or not 3 <= args.duration <= 30:
        parser.error('Choose an existing audio file and a 3–30 second speech excerpt.')
    import imageio_ffmpeg
    root = Path(__file__).resolve().parent
    destination = root / '.references' / (args.character + '.wav')
    destination.parent.mkdir(exist_ok=True)
    subprocess.run([imageio_ffmpeg.get_ffmpeg_exe(), '-v', 'error', '-ss', str(args.start),
                    '-i', str(args.source), '-t', str(args.duration), '-ac', '1', '-ar', '24000',
                    '-af', 'highpass=f=70,lowpass=f=10000', '-y', str(destination)],
                   check=True, capture_output=True)
    print('Private reference prepared. Listen and verify the chosen excerpt before voice cloning.')


if __name__ == '__main__':
    main()
