# Voice Studio for Windows

A local Korean voice workspace with Jarvis and Deckard characters, animated avatars, GPT/Claude task delegation, and local voice playback.

This source snapshot contains the inspectable application code. The repository's original `main` branch retains the earlier ZIP-and-patch distribution; the new sharing branch provides this snapshot as `Voice-Studio-2026-11-01-source.zip`. Extract that archive before reviewing or changing the code. Start with [CLAUDE-HANDOFF.md](CLAUDE-HANDOFF.md) for implementation status and [CLOUD-REALTIME-PLAN.md](CLOUD-REALTIME-PLAN.md) for the proposed cloud path.

## Current status

- The desktop UI runs locally at `http://127.0.0.1:8770/`.
- Jarvis uses a continuously animated blue electron cloud with visible volume and flowing light. Deckard uses a generated upper-body image mapped to an articulated 2.5D mesh, with mouth movement driven by played audio. It is not a freely rotatable full-volume model.
- Character selection changes the whole workspace: Jarvis has a cyan laboratory with six animated technical screens, an operating robot arm on the left, and three procedural 3D armor displays. Deckard has an empty headquarters interior with architectural ivory, navy, and gold panels throughout the UI. There are no background teammates. The brand, captions, footer, and page title follow the selected character.
- The laboratory screens are decorative drawings, waveforms, circuits, and exploded views labeled **DESIGN VISUAL**. They do not measure the PC, microphone, model, or network. The laboratory and armor animations pause with the motion toggle and are hidden for Deckard.
- Local speech uses approved private voice presets, exact-text caching, phrase segmentation, and next-phrase prefetch. Voice recordings and trained/downloaded model files are **not** included here.
- An adapted official [OpenAI Live Console](https://github.com/openai/openai-live-console) browser transport is integrated, with its original MIT license and pinned source retained. It remains unavailable without API credentials and the selected voice configuration. Copying its source does not supply a hosted model or guarantee realtime latency.
- The separate cloud conversation-plus-streaming-TTS direction is a design proposal. It has not been activated or validated against a paid API.

The earlier HUD launcher on port 8767 is intentionally absent from this shared branch. Use `Start-Companion.cmd` for the current workspace.

The three armor props are code-generated Three.js geometry with a fixed camera, subtle servo motion, and reactor lighting. They are approximations based on visual references, not trained models or official film assets. No downloaded reference photograph is included. This code-based implementation follows the blocked raster image-generation attempt.

## Open the interface

Use Python 3.11 or newer on Windows. A basic interface-only environment can be prepared with:

```powershell
py -3 -m venv .qwen-env
.\.qwen-env\Scripts\python.exe -m pip install -r requirements-companion.txt
.\.qwen-env\Scripts\python.exe -m whisperflow.companion --port 8770
```

This starts the local UI. GPT/Claude task execution requires the corresponding supported CLI and a user-completed login. Microphone transcription and speech playback additionally require their local dependencies and models; an interface-only environment does not provide those automatically.

For an already prepared installation, launch `Start-Companion.cmd`. It uses the local `.qwen-env` runtime and can read machine-specific values from `windows-config.json`. Copy `windows-config.example.json` only when configuring a new machine, and keep the resulting private configuration out of Git.

## Voice setup

The relevant modules are `whisperflow/speech_input.py`, `windows_qwen.py`, `approved_voice.py`, and `native_qwen.py`. See [WINDOWS.md](WINDOWS.md) and [CONNECTIONS.md](CONNECTIONS.md) for local model/runtime prerequisites. The setup scripts may download substantial model files; review their choices before running them.

Private voice references belong under `.references/`, with the approved preset manifest at `.references/voice-presets.json`. That directory is excluded from this source distribution. A fresh checkout therefore cannot reproduce the original local character voices until the user supplies their own authorized recordings and configuration. Do not silently substitute an unrelated voice.

Keep the app bound to loopback. GitHub sharing is source sharing; it does not expose or deploy the local desktop service.

## Validation

Run the selected backend checks from the repository root using an environment that has the existing local application's test dependencies:

```powershell
$env:PYTHONDONTWRITEBYTECODE = '1'
$env:PYTHONPATH = Join-Path $PWD 'tests'
.\.qwen-env\Scripts\python.exe -m unittest tests.test_companion tests.test_speech_pipeline tests.test_login_connection tests.test_latency tests.test_live_companion tests.test_live_session tests.test_official_bridge
```

The frontend checks use Node.js and mocked render/media boundaries:

```powershell
node --test tests/web/test_official_browser.cjs
node tests/web/test_deckard_avatar.mjs
node tests/web/test_jarvis_motion.cjs
node tests/web/test_persona_theme.cjs
node tests/web/test_lab_activity.cjs
node tests/web/test_armor_display.cjs
```

These checks do not upload audio, call paid APIs, or establish end-to-end voice latency. See `VALIDATION.md` for the actual results recorded for this shared snapshot.

## Source map

| File | Role |
| --- | --- |
| `whisperflow/companion.py` | Local web app, task queue, state, and speech scheduling |
| `whisperflow/agent_runner.py` | GPT/Claude CLI integration |
| `whisperflow/live_session.py` | OpenAI Live lifecycle and voice readiness |
| `whisperflow/static/companion.js` | UI and microphone flow |
| `whisperflow/static/live-client.js` | Official transport wrapper |
| `whisperflow/static/jarvis-neural.js` | Jarvis motion |
| `whisperflow/static/deckard-avatar.js` | Deckard articulation |
| `whisperflow/static/persona-theme.css`, `persona-theme.js` | Character-specific workspace skins and labels |
| `whisperflow/static/lab-activity.css`, `lab-activity.js` | Six decorative technical screens and animated robot arm |
| `whisperflow/static/armor-display.css`, `armor-display.js` | Procedural Three.js armor props and motion lifecycle |
| `third_party/openai-live-console/` | Pinned upstream source, license, and rebuild adapter |

## Sharing and attribution

This snapshot excludes API keys, account state, local machine paths, private recordings, conversation/job history, logs, caches, virtual environments, downloaded models, and temporary visual-review pages. The local personal form of address is replaced with a generic form in the public code and matching tests.

The project derives from [kshicdi/whisperflow](https://github.com/kshicdi/whisperflow), whose MIT license is retained in [LICENSE](LICENSE). OpenAI Live Console and Three.js retain their own MIT license notices. The generated avatar and laboratory artwork are included as interface assets, not as reference voice recordings. No affiliation with the fictional-character rights holders is asserted.
