import io
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
import wave

from whisperflow import native_qwen


def wav():
    buffer = io.BytesIO()
    with wave.open(buffer, 'wb') as file:
        file.setnchannels(1)
        file.setsampwidth(2)
        file.setframerate(24000)
        file.writeframes(b'\0\0' * 2400)
    return buffer.getvalue()


class FakeProcess:
    def __init__(self, command, cwd, fail):
        self.command, self.cwd, self.fail, self.returncode = command, cwd, fail, None
    def communicate(self, timeout=None):
        if self.fail:
            self.returncode = 1
            return b'', b'cuda error'
        Path(self.cwd, self.command[self.command.index('--output')+1]).write_bytes(wav())
        self.returncode = 0
        return b'', b''
    def poll(self):
        return self.returncode
    def kill(self):
        pass


class GpuTests(unittest.TestCase):
    def test_cuda_build_uses_gpu_layers_and_falls_back_to_cpu_once(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            cuda, cpu, models = root/'llama-cuda', root/'llama', root/'models'
            for folder in (cuda, cpu, models):
                folder.mkdir()
            for file in (cuda/'llama-tts.exe', cpu/'llama-tts.exe', models/'tts-q4.gguf', models/'codec-q8.gguf'):
                file.touch()
            calls, timeouts = [], []
            def popen(command, cwd=None, **kwargs):
                folder = Path(command[0]).parent.name
                calls.append((folder, command[command.index('-ngl')+1]))
                process = FakeProcess(command, cwd, folder == 'llama-cuda')
                original_communicate = process.communicate
                def communicate(timeout=None):
                    timeouts.append(timeout)
                    return original_communicate(timeout)
                process.communicate = communicate
                return process
            env = {'JARVIS_NATIVE_CUDA_DIR': str(cuda), 'JARVIS_NATIVE_DIR': str(cpu),
                   'JARVIS_NATIVE_MODEL_DIR': str(models)}
            with patch.dict('os.environ', env), patch('subprocess.Popen', side_effect=popen), \
                    patch.object(native_qwen, '_cuda_failed', False), patch.object(native_qwen, 'ROOT', root):
                self.assertTrue(native_qwen.use_gpu())
                self.assertEqual(native_qwen.generate('안녕하세요.', Path('ref.wav'), 'ko')[:4], b'RIFF')
                self.assertEqual(calls, [('llama-cuda', '99'), ('llama', '0')])
                self.assertEqual(timeouts, [300, 300])
                self.assertFalse(native_qwen.use_gpu())
                native_qwen.generate('다시 한 번.', Path('ref.wav'), 'ko')
                self.assertEqual(calls[-1], ('llama', '0'))

    def test_cpu_only_install_keeps_cpu_settings(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            with patch.dict('os.environ', {'JARVIS_NATIVE_CUDA_DIR': str(root/'missing')}), \
                    patch.object(native_qwen, '_cuda_failed', False):
                self.assertFalse(native_qwen.use_gpu())



class CancelTests(unittest.TestCase):
    def test_stopping_gpu_synthesis_does_not_fall_back_or_disable_gpu(self):
        import threading
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            cuda, cpu, models = root/'llama-cuda', root/'llama', root/'models'
            for folder in (cuda, cpu, models):
                folder.mkdir()
            for file in (cuda/'llama-tts.exe', cpu/'llama-tts.exe', models/'tts-q4.gguf', models/'codec-q8.gguf'):
                file.touch()
            started, calls = threading.Event(), []

            class Slow(FakeProcess):
                def __init__(self, *args):
                    super().__init__(*args)
                    self.killed = threading.Event()
                def communicate(self, timeout=None):
                    started.set()
                    self.killed.wait(2)
                    self.returncode = -9
                    return b'', b''
                def kill(self):
                    self.killed.set()

            def popen(command, cwd=None, **kwargs):
                calls.append(Path(command[0]).parent.name)
                return Slow(command, cwd, False)
            env = {'JARVIS_NATIVE_CUDA_DIR': str(cuda), 'JARVIS_NATIVE_DIR': str(cpu),
                   'JARVIS_NATIVE_MODEL_DIR': str(models)}
            with patch.dict('os.environ', env), patch('subprocess.Popen', side_effect=popen), \
                    patch.object(native_qwen, '_cuda_failed', False), patch.object(native_qwen, 'ROOT', root):
                stopper = threading.Thread(target=lambda: (started.wait(2), native_qwen.stop_pending()))
                stopper.start()
                with self.assertRaises(native_qwen.SynthesisCancelled):
                    native_qwen.generate('긴 문장입니다.', Path('ref.wav'), 'ko')
                stopper.join()
                self.assertEqual(calls, ['llama-cuda'])
                self.assertTrue(native_qwen.use_gpu())

    def test_failure_on_both_builds_keeps_gpu_enabled(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            cuda, cpu, models = root/'llama-cuda', root/'llama', root/'models'
            for folder in (cuda, cpu, models):
                folder.mkdir()
            for file in (cuda/'llama-tts.exe', cpu/'llama-tts.exe', models/'tts-q4.gguf', models/'codec-q8.gguf'):
                file.touch()
            env = {'JARVIS_NATIVE_CUDA_DIR': str(cuda), 'JARVIS_NATIVE_DIR': str(cpu),
                   'JARVIS_NATIVE_MODEL_DIR': str(models)}
            with patch.dict('os.environ', env), \
                    patch('subprocess.Popen', side_effect=lambda c, cwd=None, **k: FakeProcess(c, cwd, True)), \
                    patch.object(native_qwen, '_cuda_failed', False), patch.object(native_qwen, 'ROOT', root):
                with self.assertRaises(RuntimeError):
                    native_qwen.generate('잘못된 참조', Path('ref.wav'), 'ko')
                self.assertTrue(native_qwen.use_gpu())


if __name__ == '__main__':
    unittest.main()
