"""Offline bridge contract tests for the pinned OpenAI BrowserSession adapter."""
import asyncio
import json
from pathlib import Path
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import AsyncMock, patch

from whisperflow.companion import Companion
from whisperflow.live_session import LiveSessionManager
from test_live_session import ENV, Transport


class PublicUsageTests(unittest.IsolatedAsyncioTestCase):
    def manager(self, **kwargs):
        return LiveSessionManager(AsyncMock(), AsyncMock(), env=ENV,
                                  transport=Transport(), close_timeout=.03, **kwargs)

    async def test_only_safe_finite_final_seconds_are_public(self):
        manager = self.manager()
        for usage in (None, {}, [], {'seconds': True}, {'seconds': -1},
                      {'seconds': float('nan')}, {'seconds': float('inf')},
                      {'seconds': '12'}, {'seconds': 10**1000}):
            manager.final_usage = usage
            self.assertIsNone(manager.status()['usage'])
        manager.final_usage = {'seconds': 12.75, 'api_key': 'upstream-secret'}
        public = manager.status()
        self.assertEqual(public['usage'], {'seconds': 12.75})
        self.assertNotIn('upstream-secret', json.dumps(public))
        self.assertNotIn(ENV['OPENAI_API_KEY'], json.dumps(public))
        manager.final_usage = {'seconds': 0}
        self.assertEqual(manager.status()['usage'], {'seconds': 0})

    async def test_closed_event_and_close_response_share_final_receipt(self):
        manager = self.manager()
        await manager.create('offer', client_request_id='receipt-request')
        await manager.ingest({'type': 'session.closed', 'event_id': 'final-receipt',
                              'usage': {'seconds': 7.25, 'secret': 'hidden'}})
        event = manager.emit.call_args.args[0]
        self.assertEqual(event, {'type': 'live_closed', 'confirmed': True,
            'usage': {'seconds': 7.25}, 'session_id': 'live_fixture_id',
            'client_request_id': 'receipt-request'})
        response = await manager.close(client_request_id='receipt-request')
        self.assertEqual(response['usage'], {'seconds': 7.25})
        self.assertTrue(response['confirmed'])
        self.assertNotIn('hidden', json.dumps(response))

    async def test_missing_receipt_stays_unknown_even_when_close_confirmed(self):
        manager = self.manager()
        await manager.create('offer', client_request_id='unknown-usage')
        result = await manager.close(client_request_id='unknown-usage')
        self.assertTrue(result['confirmed'])
        self.assertIsNone(result['usage'])

    async def test_new_call_clears_previous_usage_and_stale_close_is_ignored(self):
        manager = self.manager()
        manager.final_usage = {'seconds': 88}
        await manager.create('offer', client_request_id='active-request')
        self.assertIsNone(manager.status()['usage'])
        result = await manager.close(client_request_id='expired-request')
        self.assertEqual(result, {'confirmed': True, 'ignored': True})
        self.assertEqual(manager.status()['client_request_id'], 'active-request')
        self.assertEqual(manager.state, 'connected')
        self.assertFalse(manager.transport.socket.closed)
        await manager.close(client_request_id='active-request')


class EmptyWebSocket:
    def __init__(self):
        self.prepare = AsyncMock()
        self.send_json = AsyncMock()

    def __aiter__(self):
        return self

    async def __anext__(self):
        raise StopAsyncIteration


class SnapshotBridgeTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.temp = tempfile.TemporaryDirectory(dir=Path(__file__).resolve().parents[1])
        root = Path(self.temp.name)
        with patch('whisperflow.companion.ROOT', root), patch('whisperflow.companion.Desktop'):
            self.companion = Companion(data_dir=root/'data')
        self.companion.settings['character'] = 'deckard'
        self.companion.live.env = ENV
        self.companion.status = AsyncMock(return_value={'settings': {'character': 'deckard'}})
        self.companion.live.state = 'connected'
        self.companion.live.session_id = 'live_snapshot_id'
        self.companion.live.client_request_id = 'snapshot-request'
        self.companion.live.final_usage = {'seconds': 2.5, 'private': 'hidden-upstream-field'}

    async def asyncTearDown(self):
        self.temp.cleanup()

    def endpoint(self, path):
        with patch('whisperflow.companion.STATIC', Path(self.temp.name)):
            return next(route.handler for route in self.companion.app().router.routes()
                        if route.method == 'GET' and route.resource.canonical == path)

    def assert_safe_identity(self, live):
        self.assertEqual(live['state'], 'connected')
        self.assertEqual(live['session_id'], 'live_snapshot_id')
        self.assertEqual(live['client_request_id'], 'snapshot-request')
        self.assertEqual(live['usage'], {'seconds': 2.5})
        self.assertEqual(live['implementation'], {
            'source': 'openai/openai-live-console',
            'commit': '5f64ecb3009d8274da9953c825d469ea6b6b67c3'})
        self.assertEqual(live['readiness']['character'], 'deckard')
        serialized = json.dumps(live)
        for secret in (ENV['OPENAI_API_KEY'], ENV['DECKARD_OPENAI_VOICE_ID'], 'hidden-upstream-field'):
            self.assertNotIn(secret, serialized)

    async def test_websocket_snapshot_can_confirm_matching_sideband(self):
        ws = EmptyWebSocket()
        endpoint = self.endpoint('/ws')
        with patch('whisperflow.companion.web.WebSocketResponse', return_value=ws):
            await endpoint(SimpleNamespace())
        snapshot = ws.send_json.call_args.args[0]
        self.assertEqual(snapshot['type'], 'snapshot')
        self.assert_safe_identity(snapshot['live'])
        self.assertNotIn(ws, self.companion.clients)

    async def test_status_endpoint_exposes_same_safe_bridge_contract(self):
        response = await self.endpoint('/api/live/status')(SimpleNamespace())
        self.assert_safe_identity(json.loads(response.text))

    async def test_selected_local_voice_readiness_stays_blocked_without_configuration(self):
        self.companion.live.env = {}
        response = await self.endpoint('/api/live/status')(SimpleNamespace())
        live = json.loads(response.text)
        self.assertFalse(live['readiness']['ready'])
        self.assertEqual({reason['code'] for reason in live['readiness']['reasons']},
            {'api_key_missing', 'custom_voice_missing', 'korean_voice_unverified'})


if __name__ == '__main__':
    unittest.main()
