import asyncio
import tempfile
from pathlib import Path
import unittest
from unittest.mock import AsyncMock,patch

from whisperflow.codex_stream import partial_reply,CodexStream
from whisperflow.approved_voice import cache_file


class StreamingTests(unittest.TestCase):
    def test_only_reply_is_exposed_during_partial_json_stream(self):
        self.assertEqual(partial_reply('{"status":"completed","reply":"친구야, 안녕'), '친구야, 안녕')
        self.assertEqual(partial_reply('{"status":"completed","reply":"line\\nnext\\'), 'line\nnext')
        self.assertEqual(partial_reply('{"reply":"친구야, \\uC54'), '친구야, ')
        self.assertEqual(partial_reply('{"reply":"친구야, \\uC548\\uB155"}'), '친구야, 안녕')
        self.assertEqual(partial_reply('{"status":"completed"}'), '')

    def test_voice_cache_changes_with_reference_and_effect(self):
        with tempfile.TemporaryDirectory() as temporary:
            root=Path(temporary)
            (root/'ref.wav').write_bytes(b'reference')
            preset={'reference':'ref.wav','seed':42}
            with patch('whisperflow.approved_voice.ROOT',root):
                first=cache_file('ready',preset,None,'soft')
                self.assertEqual(first,cache_file('ready',preset,None,'soft'))
                self.assertNotEqual(first,cache_file('ready',preset,None,'none'))
                (root/'ref.wav').write_bytes(b'new-reference')
                self.assertNotEqual(first,cache_file('ready',preset,None,'soft'))


class TransportTests(unittest.IsolatedAsyncioTestCase):
    async def test_failed_turn_does_not_return_draft_as_completed(self):
        server=CodexStream('unused')
        server.start=AsyncMock()
        async def call(method,params):
            if method=='thread/start':
                return {'thread':{'id':'thread'}}
            if method=='turn/start':
                queue=server.events['thread']
                queue.put_nowait({'method':'item/agentMessage/delta','params':{'itemId':'message','delta':'{"reply":"working'}})
                queue.put_nowait({'method':'turn/completed','params':{'turn':{'status':'failed'}}})
                return {'turn':{'id':'turn'}}
            return {}
        server.call=call
        progress=AsyncMock()
        with tempfile.TemporaryDirectory() as temporary:
            with self.assertRaises(RuntimeError):
                await server.run({'desktop_enabled':False},'request',Path(temporary),Path(temporary),{}, {},progress)
        progress.assert_called_once_with({'reply_draft':'working'})
        self.assertEqual(server.events,{})
