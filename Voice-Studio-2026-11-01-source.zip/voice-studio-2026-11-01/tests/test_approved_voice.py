import io
import unittest
from unittest.mock import patch
import wave

from whisperflow import approved_voice
from whisperflow.windows_qwen import VoiceDesigner


def wav():
    import numpy as np
    signal=(np.sin(np.arange(2400)/24000*2*np.pi*180)*8000).astype('<i2')
    output=io.BytesIO()
    with wave.open(output,'wb') as audio:
        audio.setnchannels(1)
        audio.setsampwidth(2)
        audio.setframerate(24000)
        audio.writeframes(signal.tobytes())
    return output.getvalue()


class ApprovedVoiceTests(unittest.TestCase):
    def test_korean_uses_approved_preset_and_preserves_its_default_seed(self):
        preset={'engine':'native','seed':17}
        designer=VoiceDesigner()
        with patch.object(designer,'schedule_unload'), \
             patch.object(approved_voice,'profile',return_value=preset) as lookup, \
             patch.object(approved_voice,'generate',return_value=wav()) as generate, \
             patch('whisperflow.native_qwen.generate') as legacy:
            output=designer.generate({'text':'작업을 완료했습니다.','voice':'clone:jarvis','language':'ko'})
        lookup.assert_called_once_with('clone:jarvis','ko')
        generate.assert_called_once_with('작업을 완료했습니다.',preset,None)
        legacy.assert_not_called()
        self.assertEqual(output[:4],b'RIFF')

    def test_english_keeps_original_reference_seed_and_unprocessed_audio(self):
        original=wav()
        designer=VoiceDesigner()
        with patch.object(designer,'schedule_unload'), \
             patch.object(approved_voice,'profile',return_value=None), \
             patch('whisperflow.windows_qwen.Path.is_file',return_value=True), \
             patch('whisperflow.native_qwen.available',return_value=True), \
             patch('whisperflow.native_qwen.generate',return_value=original) as generate:
            output=designer.generate({'text':'All done.','voice':'clone:jarvis','language':'en'})
        self.assertEqual(output,original)
        self.assertEqual(generate.call_args.args[1].name,'jarvis.wav')
        self.assertEqual(generate.call_args.args[2:],('en',42))

    def test_deckard_approved_route_keeps_soft_effect_by_default(self):
        preset={'engine':'icl','seed':42}
        original=wav()
        designer=VoiceDesigner()
        with patch.object(designer,'schedule_unload'), \
             patch.object(approved_voice,'profile',return_value=preset), \
             patch.object(approved_voice,'generate',return_value=original), \
             patch('whisperflow.voice_effects.robot_effect',return_value=original) as effect:
            designer.generate({'text':'완료했습니다.','voice':'clone:deckard','language':'ko'})
        effect.assert_called_once_with(original,'soft')
