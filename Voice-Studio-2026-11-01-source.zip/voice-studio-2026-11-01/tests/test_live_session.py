import asyncio
import json
import unittest
from unittest.mock import AsyncMock
from whisperflow.live_session import LiveSessionManager,LiveError,readiness


ENV={'OPENAI_API_KEY':'test-not-a-secret','JARVIS_OPENAI_VOICE_ID':'voice_jarvis_test',
     'DECKARD_OPENAI_VOICE_ID':'voice_deckard_test','OPENAI_CUSTOM_KO_VERIFIED':'1'}


class Message:
    type=1
    def __init__(self,value):self.value=value
    def json(self):return self.value


class Socket:
    def __init__(self,ack_close=True):
        self.closed=False
        self.sent=[]
        self.queue=asyncio.Queue()
        self.ack_close=ack_close
    def __aiter__(self):return self
    async def __anext__(self):
        value=await self.queue.get()
        if value is None:raise StopAsyncIteration
        return Message(value)
    async def send_json(self,value):
        self.sent.append(value)
        if value['type']=='session.close' and self.ack_close:
            self.queue.put_nowait({'type':'session.closed','event_id':'closed_1','usage':{}})
    async def close(self):
        self.closed=True
        self.queue.put_nowait(None)


class Transport:
    def __init__(self,ack_close=True):
        self.socket=Socket(ack_close)
        self.requests=[]
        self.closed=False
    async def create(self,body,key):
        self.requests.append(body)
        return {'session':{'id':'live_fixture_id'},'transport':{'type':'webrtc','sdp':'answer'}}
    async def attach(self,identity,key):
        self.attached=identity
        return self.socket
    async def close(self):self.closed=True


class Readiness(unittest.TestCase):
    def test_not_ready_without_key_voice_and_korean_verification(self):
        result=readiness('deckard','ko',{})
        self.assertFalse(result['ready'])
        self.assertEqual({r['code'] for r in result['reasons']},
                         {'api_key_missing','custom_voice_missing','korean_voice_unverified'})

    def test_never_falls_back_to_builtin_voice(self):
        values={**ENV,'DECKARD_OPENAI_VOICE_ID':''}
        result=readiness('deckard','ko',values)
        self.assertFalse(result['ready'])
        self.assertNotIn('test-not-a-secret',json.dumps(result))
        self.assertNotIn('voice_jarvis_test',json.dumps(result))

    def test_korean_guard_independent_of_key_and_voice(self):
        self.assertFalse(readiness('jarvis','ko',{**ENV,'OPENAI_CUSTOM_KO_VERIFIED':'0'})['ready'])
        self.assertTrue(readiness('jarvis','en',{**ENV,'OPENAI_CUSTOM_KO_VERIFIED':'0'})['ready'])
        self.assertFalse(readiness('deckard','en',ENV)['ready'])


class Lifecycle(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.transport=Transport()
        self.dispatch=AsyncMock(return_value={'status':'completed','reply':'확인된 테스트 결과입니다.','verified':True})
        self.emit=AsyncMock()
        self.manager=LiveSessionManager(self.dispatch,self.emit,env=ENV,
            transport=self.transport,transcript_grace=0,close_timeout=.03)

    async def asyncTearDown(self):
        await self.manager.close()

    async def start(self):
        return await self.manager.create('offer',character='deckard',language='ko')

    async def fragment(self,text,start=0,end=500,event_id='transcript_1'):
        await self.manager.ingest({'type':'session.input_transcript.delta','event_id':event_id,
                                   'delta':text,'start_ms':start,'end_ms':end})

    async def delegate(self,identity='delegation_1',offset=500,event_id='delegate_event_1'):
        await self.manager.ingest({'type':'session.delegation.created','event_id':event_id,
            'offset_ms':offset,'delegation':{'id':identity,'type':'delegation','target':'client'}})

    async def settle(self):
        await asyncio.gather(*list(self.manager.tasks))

    async def test_missing_readiness_makes_zero_http_or_socket_requests(self):
        self.manager.env={}
        with self.assertRaises(LiveError) as error:
            await self.start()
        self.assertEqual(error.exception.code,'not_ready')
        self.assertEqual(self.transport.requests,[])

    async def test_contract_uses_exact_custom_voice_and_restricts_frontend(self):
        response=await self.start()
        session=self.transport.requests[0]['session']
        self.assertEqual(session['audio']['output']['voice'],{'id':'voice_deckard_test'})
        self.assertEqual(session['delegation'],{'type':'client'})
        self.assertFalse(session['store'])
        self.assertEqual(session['client']['data_channel']['allowed_client_events'],['session.close'])
        self.assertEqual(response,{'session':{'id':'live_fixture_id'},'transport':{'type':'webrtc','sdp':'answer'}})
        self.assertEqual(self.transport.socket.sent,[])  # Never sends session.start on sideband.
        self.assertNotIn('test-not-a-secret',json.dumps(self.manager.status()))

    async def test_transcript_fragments_do_not_dispatch_until_delegated(self):
        await self.start()
        await self.fragment('메모를')
        await self.fragment(' 만들어 줘',500,900,'transcript_2')
        self.dispatch.assert_not_awaited()
        await self.delegate(offset=900)
        await self.settle()
        self.assertEqual(self.dispatch.call_args.args[0],'메모를 만들어 줘')
        context=self.dispatch.call_args.args[1]
        self.assertEqual(context['character'],'deckard')
        self.assertEqual(len(context['transcripts']),2)
        sent=self.transport.socket.sent[0]
        self.assertEqual(sent['type'],'session.commentary.append')
        self.assertEqual(sent['delegation_id'],'delegation_1')

    async def test_duplicate_events_and_delegations_never_repeat_work(self):
        await self.start()
        await self.fragment('확인해 줘')
        await self.fragment('확인해 줘')
        await self.delegate()
        await self.delegate(event_id='another_event_same_delegation')
        await self.settle()
        self.dispatch.assert_awaited_once()
        self.assertEqual(self.dispatch.call_args.args[0],'확인해 줘')

    async def test_no_transcript_asks_for_input_without_inventing_a_task(self):
        await self.start()
        await self.delegate()
        await self.settle()
        self.dispatch.assert_not_awaited()
        self.assertEqual(self.manager.delegations['delegation_1']['status'],'needs_input')

    async def test_unverified_complete_is_never_announced_as_success(self):
        self.dispatch.return_value={'status':'completed','reply':'삭제 완료했습니다.'}
        await self.start()
        await self.fragment('작업해 줘')
        await self.delegate()
        await self.settle()
        sent=self.transport.socket.sent[0]
        self.assertNotIn('삭제 완료',sent['content'])
        self.assertIn('needs_input',sent['content'])

    async def test_acknowledgment_does_not_claim_audio_was_played(self):
        await self.start()
        await self.fragment('작업해 줘')
        await self.delegate()
        await self.settle()
        sent=self.transport.socket.sent[0]
        await self.manager.ingest({'type':'session.commentary.appended','event_id':'ack1',
                                  'client_event_id':sent['event_id']})
        accepted=[call.args[0] for call in self.emit.call_args_list if call.args[0]['type']=='live_context_accepted']
        self.assertEqual(len(accepted),1)
        self.assertFalse(accepted[0]['played'])

    async def test_provider_error_body_cannot_expose_credentials(self):
        await self.start()
        await self.manager.ingest({'type':'error','event_id':'err1','error':{'message':'test-not-a-secret'}})
        self.assertNotIn('test-not-a-secret',repr(self.emit.call_args_list))

    async def test_close_waits_for_server_confirmation_and_cleans_resources(self):
        await self.start()
        result=await self.manager.close()
        self.assertTrue(result['confirmed'])
        self.assertTrue(self.transport.socket.closed)
        self.assertTrue(self.transport.closed)

    async def test_close_timeout_is_reported_as_unconfirmed(self):
        self.transport.socket.ack_close=False
        await self.start()
        result=await self.manager.close()
        self.assertFalse(result['confirmed'])
        self.assertEqual(self.manager.state,'close_unconfirmed')

    async def test_stop_cancels_actual_dispatch_coroutine(self):
        started=asyncio.Event()
        cancelled=asyncio.Event()
        async def work(*args):
            started.set()
            try:await asyncio.Event().wait()
            finally:cancelled.set()
        self.manager.dispatch=work
        await self.start()
        await self.fragment('작업해 줘')
        await self.delegate()
        await asyncio.wait_for(started.wait(),1)
        await self.manager.close(cancel_jobs=True)
        self.assertTrue(cancelled.is_set())
        self.assertEqual(self.manager.delegations['delegation_1']['status'],'cancelled')

    async def test_attach_failure_is_not_retried_and_blocks_recreate(self):
        self.transport.attach=AsyncMock(side_effect=LiveError('sideband_unavailable','연결 실패',uncertain=True))
        with self.assertRaises(LiveError):await self.start()
        self.assertEqual(self.manager.state,'uncertain')
        with self.assertRaises(LiveError):await self.start()
        self.assertEqual(len(self.transport.requests),1)

    async def test_close_before_create_tombstones_request(self):
        result=await self.manager.close(client_request_id='cancelled_before_create')
        self.assertTrue(result['confirmed'])
        with self.assertRaises(LiveError) as raised:
            await self.manager.create('offer',client_request_id='cancelled_before_create')
        self.assertEqual(raised.exception.code,'request_cancelled')
        self.assertEqual(self.transport.requests,[])

    async def test_stale_close_cannot_close_newer_request(self):
        await self.manager.create('offer',client_request_id='newer_request')
        result=await self.manager.close(client_request_id='older_request')
        self.assertTrue(result['ignored'])
        self.assertEqual(self.manager.state,'connected')
        self.assertFalse(self.transport.socket.closed)
        self.assertEqual(self.transport.socket.sent,[])

    async def test_close_during_create_never_returns_cancelled_sdp(self):
        entered=asyncio.Event()
        release=asyncio.Event()
        original=self.transport.create
        async def delayed(body,key):
            entered.set()
            await release.wait()
            return await original(body,key)
        self.transport.create=delayed
        creation=asyncio.create_task(self.manager.create('offer',client_request_id='inflight_request'))
        await entered.wait()
        closing=asyncio.create_task(self.manager.close(client_request_id='inflight_request'))
        await asyncio.sleep(0)
        release.set()
        with self.assertRaises(LiveError) as raised:await creation
        self.assertEqual(raised.exception.code,'request_cancelled')
        self.assertTrue((await closing)['confirmed'])
        self.assertTrue(self.transport.socket.closed)

    async def test_invalid_request_identity_never_creates_or_closes(self):
        for invalid in ('short',None,{},'bad identity with spaces'):
            if invalid is None:continue  # Internal emergency close still omits identity.
            with self.assertRaises(LiveError):await self.manager.create('offer',client_request_id=invalid)
            with self.assertRaises(LiveError):await self.manager.close(client_request_id=invalid)
        self.assertEqual(self.transport.requests,[])

    async def test_known_create_rejection_closes_cleanly_but_uncertain_does_not(self):
        self.transport.create=AsyncMock(side_effect=LiveError('api_auth_failed','rejected'))
        with self.assertRaises(LiveError):await self.manager.create('offer',client_request_id='rejected_request')
        self.assertTrue((await self.manager.close(client_request_id='rejected_request'))['confirmed'])
        self.transport.create=AsyncMock(side_effect=LiveError('create_outcome_uncertain','unknown',uncertain=True))
        with self.assertRaises(LiveError):await self.manager.create('offer',client_request_id='uncertain_request')
        self.assertFalse((await self.manager.close(client_request_id='uncertain_request'))['confirmed'])


if __name__=='__main__':unittest.main()
