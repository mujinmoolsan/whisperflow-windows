import asyncio
import tempfile
import unittest
from unittest.mock import AsyncMock,Mock,patch
from pathlib import Path
from whisperflow.speech_worker import SpeechWorker
from whisperflow.companion import Companion
from whisperflow.speech_segments import segments


class Segments(unittest.TestCase):
    def test_words_and_punctuation_are_preserved(self):
        text='친구야, 첫 문장을 읽을게. 두 번째 문장도 빠짐없이 읽을게.'
        self.assertEqual(segments(text),['친구야, 첫 문장을 읽을게.','두 번째 문장도 빠짐없이 읽을게.'])
        self.assertEqual(' '.join(segments('긴 문장 '+('내용 확인 '*20))).split(),('긴 문장 '+('내용 확인 '*20)).split())


class Pipeline(unittest.IsolatedAsyncioTestCase):
    async def test_recognition_reuses_worker_and_restarts_after_failure(self):
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory)
            output=root/'result.json'
            output.write_text('{"text":"hello"}')
            proc=Mock(returncode=None)
            proc.stdin.drain=AsyncMock()
            proc.stdout.readline=AsyncMock(side_effect=[b'WFASR {"ok":true}\n',b'WFASR {"ok":true}\n',b''])
            proc.wait=AsyncMock()
            worker=SpeechWorker(root)
            with patch('asyncio.create_subprocess_exec',AsyncMock(return_value=proc)) as spawn:
                self.assertEqual(await worker.transcribe(root/'in.wav',output),{'text':'hello'})
                await worker.transcribe(root/'in.wav',output)
                self.assertEqual(spawn.await_count,1)
                with self.assertRaises(RuntimeError):
                    await worker.transcribe(root/'in.wav',output)
                proc.kill.assert_called_once()
                self.assertIsNone(worker.process)

    async def test_prefetch_runs_during_playback_and_never_reorders_speech(self):
        with tempfile.TemporaryDirectory() as directory:
            app=Companion(data_dir=directory)
            app.broadcast=AsyncMock()
            events=[]
            async def prefetch(text,options):
                events.append('generate:'+text)
            async def speak(text,options,on_playing,last):
                events.append('play:'+text)
                await on_playing()
                await asyncio.sleep(0)
                events.append('end:'+text)
            app.prefetch_voice=prefetch
            app.speak=speak
            await app.speak_segments(['one','two'],{})
            self.assertEqual(events,['play:one','generate:two','end:one','play:two','end:two'])
            self.assertFalse(app.voice_busy)

    async def test_cancellation_cancels_pending_generation(self):
        with tempfile.TemporaryDirectory() as directory:
            app=Companion(data_dir=directory)
            app.broadcast=AsyncMock()
            started=asyncio.Event()
            cancelled=asyncio.Event()
            async def prefetch(*args):
                started.set()
                try:
                    await asyncio.Event().wait()
                finally:
                    cancelled.set()
            async def speak(text,options,on_playing,last):
                await on_playing()
                await asyncio.Event().wait()
            app.prefetch_voice=prefetch
            app.speak=speak
            task=asyncio.create_task(app.speak_segments(['one','two'],{}))
            try:
                await asyncio.wait_for(started.wait(),2)
            except TimeoutError:
                if task.done():
                    await task
                raise
            task.cancel()
            with self.assertRaises(asyncio.CancelledError):
                await task
            self.assertTrue(cancelled.is_set())
            self.assertFalse(app.voice_busy)
