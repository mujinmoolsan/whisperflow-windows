"""Early speech: start reading finished sentences before the final GPT result."""
import asyncio
import tempfile
import time
import unittest
from unittest.mock import AsyncMock

from whisperflow.companion import Companion, DraftSpeech


class DraftSpeechTests(unittest.TestCase):
    def test_only_sentences_followed_by_more_text_are_spoken(self):
        stream = DraftSpeech('jarvis')
        self.assertFalse(stream.feed('작업을 마쳤습니다'))
        self.assertFalse(stream.feed('작업을 마쳤습니다.'))
        self.assertTrue(stream.feed('작업을 마쳤습니다. 결과'))
        self.assertEqual(stream.parts, ['작업을 마쳤습니다.'])
        self.assertTrue(stream.feed('작업을 마쳤습니다. 결과는 화면에 있습니다. 더'))
        self.assertEqual(stream.parts, ['작업을 마쳤습니다.', '결과는 화면에 있습니다.'])

    def test_final_appends_only_the_unspoken_rest(self):
        stream = DraftSpeech('jarvis')
        stream.feed('첫 문장입니다. 두')
        stream.finish('첫 문장입니다. 두 번째 문장입니다.')
        self.assertEqual(stream.parts, ['첫 문장입니다.', '두 번째 문장입니다.'])
        self.assertTrue(stream.finished)

    def test_deckard_prefix_matches_final_reply(self):
        stream = DraftSpeech('deckard')
        stream.feed('작업을 끝냈어. 확인해 주세요')
        self.assertEqual(stream.parts, ['친구야, 작업을 끝냈어.'])
        stream.finish('친구야, 작업을 끝냈어. 확인해 줘')
        self.assertEqual(stream.parts[-1], '확인해 줘')

    def test_rewritten_draft_freezes_and_final_adds_nothing(self):
        stream = DraftSpeech('jarvis')
        stream.feed('가 문장입니다. 나')
        self.assertFalse(stream.feed('다른 문장입니다. 나'))
        stream.finish('다른 문장입니다. 나머지입니다.')
        self.assertEqual(stream.parts, ['가 문장입니다.'])

    def test_long_reply_stops_at_spoken_limit(self):
        stream = DraftSpeech('jarvis')
        sentence = '가' * 60 + '.'
        stream.feed(' '.join([sentence] * 5) + ' 끝')
        self.assertLessEqual(sum(len(p) for p in stream.parts) + len(stream.parts), 181)
        self.assertTrue(stream.frozen)


class CompanionEarlySpeechTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.directory = tempfile.TemporaryDirectory()
        self.companion = Companion(data_dir=self.directory.name)
        self.companion.settings['workspace'] = self.directory.name
        self.companion.settings['voice_enabled'] = True
        self.companion.broadcast = AsyncMock()
        self.companion.prefetch_voice = AsyncMock()
        self.spoken = []

        async def speak(text, options, on_playing=None, last=True):
            self.spoken.append((text, time.monotonic()))
            if on_playing:
                await on_playing()
            await asyncio.sleep(.02)
        self.companion.speak = speak

    async def asyncTearDown(self):
        await asyncio.gather(*self.companion.voice_tasks, return_exceptions=True)
        self.directory.cleanup()

    def job(self, text='안녕', character='jarvis'):
        return {'id': 'j1', 'status': 'queued', 'character': character, 'language': 'ko',
                'created': time.time(), 'directory': __import__('pathlib').Path(self.directory.name),
                'task': {'text': text, 'workspace': self.directory.name, 'desktop_enabled': False,
                         'character': character, 'language': 'ko', 'voice_output': 'local'}}

    async def test_first_sentence_is_spoken_before_the_final_reply(self):
        finished = {}

        async def run(task, history, folder, job_dir, url, token, progress):
            await progress({'reply_draft': '첫 문장입니다. 두'})
            await asyncio.sleep(.2)
            await progress({'reply_draft': '첫 문장입니다. 두 번째 문장입니다.'})
            finished['at'] = time.monotonic()
            return {'status': 'completed', 'reply': '첫 문장입니다. 두 번째 문장입니다.', 'artifacts': []}
        self.companion.runner.run = run
        job = self.job()
        await self.companion.execute(job)
        await asyncio.gather(*list(self.companion.voice_tasks), return_exceptions=True)
        texts = [text for text, _ in self.spoken]
        self.assertEqual(texts, ['첫 문장입니다.', '두 번째 문장입니다.'])
        self.assertLess(self.spoken[0][1], finished['at'])
        self.assertIn('early_speech_seconds', job)

    async def test_without_drafts_the_original_final_path_is_used(self):
        self.companion.runner.run = AsyncMock(return_value={'status': 'completed', 'reply': '완료했습니다.', 'artifacts': []})
        self.companion.schedule_voice = unittest.mock.Mock()
        await self.companion.execute(self.job())
        self.companion.schedule_voice.assert_called_once()
        self.assertEqual(self.companion.schedule_voice.call_args[0][0], '완료했습니다.')

    async def test_cancelled_task_stops_early_speech(self):
        self.companion.stop_voice = AsyncMock()

        async def run(task, history, folder, job_dir, url, token, progress):
            await progress({'reply_draft': '읽기 시작합니다. 계속'})
            await asyncio.sleep(10)
        self.companion.runner.run = run
        execution = asyncio.create_task(self.companion.execute(self.job()))
        await asyncio.sleep(.05)
        execution.cancel()
        with self.assertRaises(asyncio.CancelledError):
            await execution
        await asyncio.sleep(.05)
        self.companion.stop_voice.assert_awaited()

    async def test_disabled_setting_keeps_old_behaviour(self):
        self.companion.settings['early_speech'] = False
        self.companion.schedule_voice = unittest.mock.Mock()

        async def run(task, history, folder, job_dir, url, token, progress):
            await progress({'reply_draft': '첫 문장입니다. 두'})
            return {'status': 'completed', 'reply': '첫 문장입니다. 두 번째.', 'artifacts': []}
        self.companion.runner.run = run
        await self.companion.execute(self.job())
        self.assertEqual(self.spoken, [])
        self.companion.schedule_voice.assert_called_once()


if __name__ == '__main__':
    unittest.main()
