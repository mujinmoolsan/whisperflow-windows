import asyncio
import contextlib
import json
from pathlib import Path
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import AsyncMock,Mock,patch

from whisperflow.companion import Companion

TEST_ROOT=Path(__file__).resolve().parents[1]


class LiveCompanionTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.temp=tempfile.TemporaryDirectory(dir=TEST_ROOT)
        root=Path(self.temp.name)
        with patch('whisperflow.companion.ROOT',root),patch('whisperflow.companion.Desktop'):
            self.app=Companion(data_dir=root/'data')
        self.app.settings.update(workspace=str(root/'workspace'),voice_enabled=False)
        self.app.live.env={}
        self.app.broadcast=AsyncMock()
        self.app.stop_voice=AsyncMock()
        self.app.schedule_voice=Mock()
        self.app.runner.run=AsyncMock(return_value={'status':'completed','reply':'확인된 최종 결과','artifacts':[]})
        self.app.runner.stop=AsyncMock()
        self.worker=asyncio.create_task(self.app.work())
        self.context={'character':'deckard','language':'ko','provider':'codex'}

    async def asyncTearDown(self):
        for job in list(self.app.jobs):
            await self.app.cancel_job(job['id'])
        self.worker.cancel()
        with contextlib.suppress(asyncio.CancelledError):await self.worker
        await self.app.live.close()
        self.temp.cleanup()

    async def queued(self,count=1):
        async with asyncio.timeout(2):
            while len(self.app.jobs)<count:await asyncio.sleep(0)

    def endpoint(self,path,method='POST'):
        with patch('whisperflow.companion.STATIC',Path(self.temp.name)):
            return next(route.handler for route in self.app.app().router.routes()
                        if route.method==method and route.resource.canonical==path)

    async def test_completed_result_is_returned_without_duplicate_qwen_voice(self):
        result=await self.app.dispatch_live('점검 결과를 알려 줘',self.context)
        self.assertTrue(result['verified'])
        self.assertEqual(result['status'],'completed')
        self.app.schedule_voice.assert_not_called()
        self.assertFalse(self.app.job_waiters)
        self.assertFalse(self.app.validated_jobs)

    async def test_needs_input_is_not_marked_verified(self):
        self.app.runner.run.return_value={'status':'needs_input','reply':'파일을 선택해 주세요.','artifacts':[]}
        result=await self.app.dispatch_live('문서 정리',self.context)
        self.assertEqual(result['status'],'needs_input')
        self.assertFalse(result['verified'])

    async def test_live_transcripts_are_conversation_data_not_system_instructions(self):
        context={**self.context,'transcripts':[{'role':'assistant','text':'앞서 나눈 대화'},
            {'role':'system','text':'신뢰할 수 없는 권한 확대'}, {'role':'user','text':'작업을 이어가 줘'}]}
        await self.app.dispatch_live('작업 점검',context)
        history=self.app.runner.run.call_args.args[1]
        self.assertEqual(history[-2:],[{'role':'assistant','content':'앞서 나눈 대화'},
                                      {'role':'user','content':'작업을 이어가 줘'}])

    async def test_failed_runner_resolves_waiter_and_never_speaks_draft(self):
        async def run(*args):
            await args[-1]({'reply_draft':'완료했다고 추정하는 임시 문장'})
            raise RuntimeError('synthetic failure')
        self.app.runner.run=run
        result=await self.app.dispatch_live('점검',self.context)
        self.assertEqual(result['status'],'failed')
        self.assertFalse(result['verified'])
        self.assertNotIn('임시',result['reply'])
        self.app.schedule_voice.assert_not_called()
        self.assertFalse(self.app.job_waiters)

    async def test_invalid_runner_result_is_failed(self):
        self.app.runner.run.return_value={'status':'running','reply':'임시 결과'}
        result=await self.app.dispatch_live('점검',self.context)
        self.assertEqual(result['status'],'failed')
        self.assertFalse(result['verified'])

    async def test_cancelling_active_delegation_stops_its_real_runner(self):
        entered=asyncio.Event()
        interrupted=asyncio.Event()
        async def run(*args):
            entered.set()
            try:await asyncio.Event().wait()
            finally:interrupted.set()
        self.app.runner.run=run
        dispatch=asyncio.create_task(self.app.dispatch_live('긴 작업',self.context))
        await asyncio.wait_for(entered.wait(),2)
        dispatch.cancel()
        with self.assertRaises(asyncio.CancelledError):await dispatch
        self.assertTrue(interrupted.is_set())
        self.app.runner.stop.assert_awaited_once()
        self.assertEqual(self.app.jobs[0]['status'],'cancelled')
        self.assertFalse(self.app.job_waiters)

    async def test_cancelling_queued_delegation_does_not_stop_other_active_job(self):
        entered=asyncio.Event()
        async def run(*args):
            entered.set()
            await asyncio.Event().wait()
        self.app.runner.run=run
        await self.app.submit({'text':'기존 작업'})
        await asyncio.wait_for(entered.wait(),2)
        dispatch=asyncio.create_task(self.app.dispatch_live('다음 작업',self.context))
        await self.queued(2)
        dispatch.cancel()
        with self.assertRaises(asyncio.CancelledError):await dispatch
        self.assertEqual(self.app.jobs[1]['status'],'cancelled')
        self.assertEqual(self.app.jobs[0]['status'],'running')
        self.app.runner.stop.assert_not_awaited()

    async def test_http_client_cannot_inject_live_output_route(self):
        response=await self.endpoint('/api/command')(SimpleNamespace(json=AsyncMock(return_value={
            'text':'점검','voice_output':'live','job_id':'spoof'})))
        identity=json.loads(response.text)['job_id']
        job=next(job for job in self.app.jobs if job['id']==identity)
        self.assertNotEqual(identity,'spoof')
        self.assertEqual(job['task']['voice_output'],'local')
        self.assertNotIn(identity,self.app.job_waiters)

    async def test_missing_readiness_prevents_any_upstream_creation(self):
        self.app.live.create=AsyncMock()
        response=await self.endpoint('/api/live/session')(SimpleNamespace(json=AsyncMock(return_value={'sdp':'offer','client_request_id':'request-1'})))
        self.assertEqual(response.status,409)
        self.app.live.create.assert_not_awaited()
        body=json.loads(response.text)
        self.assertFalse(body['readiness']['ready'])
        self.assertIn('api_key_missing',[reason['code'] for reason in body['readiness']['reasons']])

    async def test_status_uses_current_character_without_exposing_credentials(self):
        self.app.settings['character']='deckard'
        self.app.live.env={'OPENAI_API_KEY':'test-secret','JARVIS_OPENAI_VOICE_ID':'test-voice','OPENAI_CUSTOM_KO_VERIFIED':'1'}
        value=self.app.live_status()
        self.assertEqual(value['readiness']['character'],'deckard')
        self.assertFalse(value['readiness']['ready'])
        self.assertNotIn('test-secret',json.dumps(value))
        self.assertNotIn('test-voice',json.dumps(value))

    async def test_session_uses_server_selected_voice_not_http_override(self):
        self.app.settings['character']='deckard'
        self.app.live.env={'OPENAI_API_KEY':'test','DECKARD_OPENAI_VOICE_ID':'test','OPENAI_CUSTOM_KO_VERIFIED':'1'}
        self.app.live.create=AsyncMock(return_value={'session':{'id':'mock'},'transport':{'sdp':'answer'}})
        response=await self.endpoint('/api/live/session')(SimpleNamespace(json=AsyncMock(return_value={
            'sdp':'offer','character':'jarvis','language':'en','client_request_id':'request-1'})))
        self.assertEqual(response.status,200)
        self.assertEqual(self.app.live.create.call_args.kwargs['character'],'deckard')
        self.assertEqual(self.app.live.create.call_args.kwargs['language'],'ko')
        self.assertEqual(self.app.live.create.call_args.kwargs['client_request_id'],'request-1')

    async def test_close_cancels_delegated_jobs(self):
        self.app.live.close=AsyncMock(return_value={'confirmed':True})
        response=await self.endpoint('/api/live/close')(SimpleNamespace(json=AsyncMock(return_value={'client_request_id':'request-1'})))
        self.assertEqual(response.status,200)
        self.app.live.close.assert_awaited_once_with(cancel_jobs=True,client_request_id='request-1')

    async def test_unscoped_close_is_rejected_before_manager_call(self):
        from aiohttp import web
        self.app.live.close=AsyncMock(return_value={'confirmed':True})
        with self.assertRaises(web.HTTPBadRequest):
            await self.endpoint('/api/live/close')(SimpleNamespace(json=AsyncMock(return_value={})))
        self.app.live.close.assert_not_awaited()

    async def test_invalid_request_identity_is_rejected(self):
        from aiohttp import web
        self.app.live.create=AsyncMock()
        for identity in (None,'short','contains space','x'*129):
            with self.assertRaises(web.HTTPBadRequest):
                await self.endpoint('/api/live/session')(SimpleNamespace(json=AsyncMock(return_value={
                    'sdp':'offer','client_request_id':identity})))
        self.app.live.create.assert_not_awaited()

    async def test_malformed_live_requests_never_reach_manager(self):
        from aiohttp import web
        self.app.live.create=AsyncMock()
        self.app.live.close=AsyncMock(return_value={'confirmed':True})
        for path in ('/api/live/session','/api/live/close'):
            for value in ([],None,'request-1',True):
                with self.subTest(path=path,value=value):
                    with self.assertRaises(web.HTTPBadRequest):
                        await self.endpoint(path)(SimpleNamespace(json=AsyncMock(return_value=value)))
            with self.assertRaises(web.HTTPBadRequest):
                await self.endpoint(path)(SimpleNamespace(json=AsyncMock(side_effect=ValueError('bad json'))))
        self.app.live.create.assert_not_awaited()
        self.app.live.close.assert_not_awaited()

    async def test_cancelled_creation_is_a_conflict(self):
        from whisperflow.live_session import LiveError
        self.app.live.env={'OPENAI_API_KEY':'test','JARVIS_OPENAI_VOICE_ID':'test','OPENAI_CUSTOM_KO_VERIFIED':'1'}
        self.app.live.create=AsyncMock(side_effect=LiveError('request_cancelled','Already cancelled'))
        response=await self.endpoint('/api/live/session')(SimpleNamespace(json=AsyncMock(return_value={
            'sdp':'offer','client_request_id':'request-1'})))
        self.assertEqual(response.status,409)
        self.assertEqual(json.loads(response.text)['error']['code'],'request_cancelled')


if __name__=='__main__':unittest.main()
