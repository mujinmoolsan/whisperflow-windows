import asyncio
from pathlib import Path
import tempfile
import unittest
from unittest.mock import AsyncMock,patch
from aiohttp.test_utils import TestClient,TestServer
from whisperflow.companion import Companion
from whisperflow.voice_commands import parse_command,persona


class WakeTests(unittest.TestCase):
    def test_wake_names_choose_persona_and_jarvis_resets_to_korean(self):
        command=parse_command('자비스, 지피티로 문서를 정리해 줘',language='en',require_wake=True)
        self.assertEqual((command['character'],command['language'],command['provider'],command['text']),
                         ('jarvis','ko','codex','문서를 정리해 줘'))
        command=parse_command('데커드, 클로드한테 메모를 만들어 줘',require_wake=True)
        self.assertEqual((command['character'],command['language'],command['provider']),('deckard','ko','claude'))
        self.assertIn('친구야',persona('deckard','ko'))
        self.assertIn('존댓말',persona('jarvis','ko'))

    def test_background_speech_cannot_start_a_job_without_a_wake_name(self):
        self.assertFalse(parse_command('계산기 열어 줘',require_wake=True)['accepted'])
        self.assertTrue(parse_command('계산기 열어 줘',require_wake=True,armed=True)['accepted'])
        self.assertEqual(parse_command('멈춰',require_wake=True)['action'],'stop')

    def test_deckard_has_no_english_mode(self):
        self.assertEqual(parse_command('데커드 영어로')['reason'],'deckard_korean_only')
        command=parse_command('자비스 영어로')
        self.assertEqual((command['action'],command['language']),('wake','en'))


class CompanionTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.directory=tempfile.TemporaryDirectory()
        self.companion=Companion(data_dir=self.directory.name)
        self.companion.settings['workspace']=self.directory.name
        self.companion.settings['voice_enabled']=False
        self.companion.stop_voice=AsyncMock()
        self.companion.connections={'codex':{'installed':True,'logged_in':True},'claude':{'installed':True,'logged_in':False}}
        self.client=TestClient(TestServer(self.companion.app()))
        await self.client.start_server()

    async def asyncTearDown(self):
        await self.client.close()
        self.directory.cleanup()

    async def wait_job(self,job_id):
        for _ in range(100):
            job=next(item for item in self.companion.jobs if item['id']==job_id)
            if job['status'] not in ('running','queued'):
                return job
            await asyncio.sleep(.01)
        self.fail('Task did not finish')

    async def test_voice_routing_reaches_selected_ai_and_keeps_needs_input_distinct(self):
        self.companion.runner.run=AsyncMock(return_value={'status':'needs_input','reply':'어느 문서를 정리할까요?','artifacts':[]})
        response=await self.client.post('/api/command',json={'text':'데커드, 클로드로 문서를 정리해 줘','require_wake':True})
        job=await self.wait_job((await response.json())['job_id'])
        self.assertEqual(job['status'],'needs_input')
        self.assertTrue(job['reply'].startswith('친구야'))
        sent=self.companion.runner.run.call_args.args[0]
        self.assertEqual((sent['character'],sent['provider'],sent['language']),('deckard','claude','ko'))

    async def test_rejected_wake_never_calls_an_ai_or_opens_an_app(self):
        self.companion.runner.run=AsyncMock()
        with patch.object(self.companion.desktop,'open_app') as launch:
            response=await self.client.post('/api/command',json={'text':'계산기 열어 줘','require_wake':True})
            self.assertFalse((await response.json())['accepted'])
        launch.assert_not_called()
        self.companion.runner.run.assert_not_called()
        self.assertEqual(self.companion.jobs,[])

    async def test_requested_basic_app_launch_is_recorded_in_the_selected_persona(self):
        with patch.object(self.companion.desktop,'open_app',return_value={'opened':'notepad'}) as launch:
            response=await self.client.post('/api/command',json={'text':'데커드, 메모장 열어 줘'})
            job=await self.wait_job((await response.json())['job_id'])
        launch.assert_called_once_with('notepad')
        self.assertEqual(job['status'],'completed')
        self.assertIn('친구야',job['reply'])

    async def test_stop_cancels_running_and_queued_jobs(self):
        started=asyncio.Event()
        async def run(*args):
            started.set()
            await asyncio.Event().wait()
        self.companion.runner.run=run
        first=await self.client.post('/api/command',json={'text':'첫 작업'})
        first_id=(await first.json())['job_id']
        await asyncio.wait_for(started.wait(),2)
        second=await self.client.post('/api/command',json={'text':'다음 작업'})
        second_id=(await second.json())['job_id']
        await self.client.post('/api/stop',json={})
        self.assertEqual((await self.wait_job(first_id))['status'],'cancelled')
        self.assertEqual((await self.wait_job(second_id))['status'],'cancelled')

    async def test_cross_site_commands_and_unauthenticated_desktop_calls_are_rejected(self):
        response=await self.client.post('/api/command',json={'text':'실행해'},headers={'Origin':'https://untrusted.example'})
        self.assertEqual(response.status,403)
        response=await self.client.post('/api/desktop',json={'action':'observe','job_id':'fake'})
        self.assertEqual(response.status,403)
        response=await self.client.post('/api/desktop',json={'action':'observe','job_id':'fake'},headers={'Authorization':'Bearer '+self.companion.desktop_token})
        self.assertEqual(response.status,403)

    async def test_artifact_download_stays_inside_the_command_workspace(self):
        file=Path(self.directory.name)/'memo.txt'
        file.write_text('verified result',encoding='utf-8')
        self.companion.runner.run=AsyncMock(return_value={'status':'completed','reply':'파일을 만들었습니다.','artifacts':['memo.txt']})
        response=await self.client.post('/api/command',json={'text':'메모 파일을 만들어 줘'})
        job=await self.wait_job((await response.json())['job_id'])
        response=await self.client.get('/api/artifact',params={'job':job['id'],'index':'0'})
        self.assertEqual(response.status,200)
        self.assertEqual(await response.text(),'verified result')
        job['artifacts']=['../outside.txt']
        response=await self.client.get('/api/artifact',params={'job':job['id'],'index':'0'})
        self.assertEqual(response.status,403)
