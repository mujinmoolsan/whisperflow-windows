import ast
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import AsyncMock,Mock,patch

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from whisperflow.agent_runner import executable,connection_status


def immediate(coroutine):
    try:
        coroutine.send(None)
    except StopIteration as done:
        return done.value
    finally:
        coroutine.close()
    raise AssertionError('Unexpected non-mocked I/O')


class ConnectionTests(unittest.TestCase):
    def test_persisted_cli_path_survives_missing_path_environment(self):
        with tempfile.TemporaryDirectory(dir=ROOT) as directory:
            root=Path(directory)
            cli=root/'cli-fixture.txt';cli.write_text('test fixture')
            (root/'windows-config.json').write_text(json.dumps({'JARVIS_CODEX_PATH':str(cli)}))
            with patch('whisperflow.agent_runner.ROOT',root),patch.dict(os.environ,{},clear=True),patch('shutil.which',return_value=None):
                self.assertEqual(executable('codex'),str(cli))
                cli.unlink()
                self.assertIsNone(executable('codex'))

    def test_failed_cli_launch_is_a_status_error_instead_of_server_failure(self):
        with patch('whisperflow.agent_runner.executable',return_value='missing.exe'),patch('asyncio.create_subprocess_exec',AsyncMock(side_effect=OSError())):
            result=immediate(connection_status('codex'))
            self.assertFalse(result['logged_in'])
            self.assertIn('error',result)

    def test_login_status_parsers_preserve_provider_separation(self):
        async def wait(awaitable,timeout):return await awaitable
        for provider,stdout,stderr in [('codex',b'',b'Logged in using ChatGPT'),('claude',b'{"loggedIn":true}',b'')]:
            proc=SimpleNamespace(returncode=0,communicate=AsyncMock(return_value=(stdout,stderr)))
            with patch('whisperflow.agent_runner.executable',return_value='fixture.exe'),patch('asyncio.create_subprocess_exec',AsyncMock(return_value=proc)),patch('asyncio.wait_for',wait):
                self.assertTrue(immediate(connection_status(provider))['logged_in'])


class LoginEndpointTests(unittest.TestCase):
    def setUp(self):
        source=ast.parse((ROOT/'whisperflow/companion.py').read_text(encoding='utf-8'))
        function=next(node for node in ast.walk(source) if isinstance(node,ast.AsyncFunctionDef) and node.name=='connect')
        self.state=SimpleNamespace(login_processes={},connections={},runner=SimpleNamespace(auth_cache={'codex':True}))
        self.spawn=Mock(return_value=Mock())
        self.status=AsyncMock(return_value={'installed':True,'logged_in':False})
        class BadRequest(Exception):
            def __init__(self,text=''):super().__init__(text)
        self.bad=BadRequest
        namespace={'self':self.state,'ROOT':ROOT,'sys':sys,'os':os,
            'subprocess':SimpleNamespace(Popen=self.spawn,CREATE_NEW_CONSOLE=subprocess.CREATE_NEW_CONSOLE),
            'web':SimpleNamespace(json_response=lambda data:data,HTTPBadRequest=BadRequest,HTTPNotFound=BadRequest),
            'executable':lambda provider:'fixture.exe','connection_status':self.status}
        exec(compile(ast.Module(body=[function],type_ignores=[]),'companion-connect','exec'),namespace)
        self.connect=namespace['connect']
        self.request=SimpleNamespace(match_info={'provider':'codex'})

    def test_already_connected_does_not_open_reauthentication(self):
        self.status.return_value={'installed':True,'logged_in':True}
        self.assertTrue(immediate(self.connect(self.request))['already_connected'])
        self.spawn.assert_not_called()
        self.assertNotIn('codex',self.state.runner.auth_cache)

    def test_second_click_does_not_spawn_duplicate_windows(self):
        self.state.login_processes['codex']=SimpleNamespace(poll=lambda:None)
        self.assertTrue(immediate(self.connect(self.request))['already_open'])
        self.spawn.assert_not_called()

    def test_uses_interactive_wrapper_without_shell(self):
        self.assertTrue(immediate(self.connect(self.request))['opened'])
        self.assertEqual(self.spawn.call_args.args[0],[sys.executable,'-u','-m','whisperflow.login_console','codex','fixture.exe'])
        self.assertNotIn('shell',self.spawn.call_args.kwargs)

    def test_launch_error_is_displayable(self):
        self.spawn.side_effect=OSError('test')
        with self.assertRaises(self.bad):immediate(self.connect(self.request))


if __name__=='__main__':unittest.main()
