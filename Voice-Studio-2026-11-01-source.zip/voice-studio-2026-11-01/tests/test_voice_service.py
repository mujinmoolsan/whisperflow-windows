import io
import json
import threading
import unittest
from http.server import ThreadingHTTPServer
import urllib.request
import urllib.error
from unittest.mock import patch
import wave

from whisperflow.windows_qwen import make_handler


class FakeDesigner:
    model = None
    playback_generation = 0
    playback_lock = threading.Lock()

    def __init__(self):
        self.requests = []

    def generate(self, data):
        self.requests.append(data)
        buffer = io.BytesIO()
        with wave.open(buffer, 'wb') as file:
            file.setnchannels(1)
            file.setsampwidth(2)
            file.setframerate(24000)
            file.writeframes(b'\0\0' * 100)
        return buffer.getvalue()


class VoiceHTTPTests(unittest.TestCase):
    def setUp(self):
        self.designer = FakeDesigner()
        self.server = ThreadingHTTPServer(('127.0.0.1', 0), make_handler(self.designer))
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)
        self.thread.start()
        self.url = f'http://127.0.0.1:{self.server.server_port}'

    def tearDown(self):
        self.server.shutdown()
        self.thread.join()
        self.server.server_close()

    def post(self, path, data, headers=None):
        request = urllib.request.Request(self.url + path, data=json.dumps(data).encode(),
                    headers={'Content-Type': 'application/json', **(headers or {})})
        return urllib.request.urlopen(request, timeout=5)

    def test_character_and_language_reach_shared_generator_and_playback(self):
        with patch('whisperflow.windows_qwen.play_local', return_value={'playing': True}) as play:
            for character, languages in (('jarvis', ('ko','en')), ('deckard', ('ko',))):
                for language in languages:
                    with self.post('/speak', {'text': 'Ready.', 'character': character,
                            'voice': 'clone:' + character, 'language': language, 'speed': 1.1}) as response:
                        self.assertTrue(json.load(response)['playing'])
                    self.assertEqual(self.designer.requests[-1]['language'], language)
                    self.assertEqual(self.designer.requests[-1]['voice'], 'clone:' + character)
            self.assertEqual(play.call_count, 3)

    def test_cross_site_request_is_rejected_without_generating_audio(self):
        with self.assertRaises(urllib.error.HTTPError) as error:
            self.post('/speak', {'text': 'Do not play'}, {'Origin': 'https://untrusted.example'})
        self.assertEqual(error.exception.code, 403)
        self.assertEqual(self.designer.requests, [])

    def test_generate_returns_wav_for_browser_playback(self):
        with self.post('/generate', {'text': 'Ready.'}) as response:
            self.assertEqual(response.headers['Content-Type'], 'audio/wav')
            self.assertEqual(response.read()[:4], b'RIFF')
