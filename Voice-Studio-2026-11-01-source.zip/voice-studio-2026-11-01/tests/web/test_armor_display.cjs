/* Exercises the real module lifecycle with a deliberately small graphics stub.
 * Visual fidelity and actual WebGL remain browser review responsibilities. */
const assert=require('node:assert/strict');
const fs=require('node:fs'), vm=require('node:vm');
let renders=0,disposeCalls=0,nextId=0,scheduled=new Map(),selection,intersection,resize;
const eventTarget=()=>({events:{},addEventListener(n,f){(this.events[n]??=[]).push(f)},removeEventListener(n,f){this.events[n]=(this.events[n]||[]).filter(x=>x!==f)},fire(n,e={}){(this.events[n]||[]).forEach(f=>f(e))}});
const vector=()=>({x:0,y:0,z:0,set(x,y,z){Object.assign(this,{x,y,z})}});
class Group {constructor(){this.children=[];this.position=vector();this.rotation=vector();this.scale=vector();this.matrix={}}add(...x){this.children.push(...x)}remove(x){this.children=this.children.filter(v=>v!==x)}updateMatrixWorld(){}updateMatrix(){}traverse(f){f(this);this.children.forEach(x=>x.traverse?x.traverse(f):f(x))}}
class Geometry {constructor(){this.attributes={position:{array:new Float32Array(9)},normal:{array:new Float32Array(9)}}}clone(){return new Geometry}applyMatrix4(){return this}dispose(){disposeCalls++}setAttribute(n,v){this.attributes[n]=v}}
class Mesh extends Group {constructor(geometry,material){super();this.isMesh=true;this.geometry=geometry;this.material=material}}
class Light extends Group {}
class Material{constructor(o){Object.assign(this,o)}dispose(){disposeCalls++}}
class Shape{moveTo(){}lineTo(){}closePath(){}}
class Renderer{setClearColor(){}setPixelRatio(n){assert.equal(n,1)}setSize(w,h){assert.equal(w,144);assert.ok(h>300&&h<500)}render(){renders++}dispose(){disposeCalls++}}
const THREE={Group,Scene:Group,Mesh,MeshStandardMaterial:Material,WebGLRenderer:Renderer,OrthographicCamera:Group,HemisphereLight:Light,DirectionalLight:Light,Shape,BufferGeometry:Geometry,BufferAttribute:class{constructor(array){this.array=array}},BoxGeometry:Geometry,SphereGeometry:Geometry,ExtrudeGeometry:Geometry,CylinderGeometry:Geometry};
let deckard=false,setting='on';
const avatar={classList:{contains:()=>deckard}};
const canvas=Object.assign(eventTarget(),{clientWidth:144,setAttribute(){},remove(){}});
const host=Object.assign(eventTarget(),{querySelector(){return null},prepend(){}});
const doc=Object.assign(eventTarget(),{hidden:false,querySelector:()=>host,getElementById:()=>avatar,createElement:()=>canvas});
const win=eventTarget(),media=Object.assign(eventTarget(),{matches:true});
const context={THREE,document:doc,window:win,localStorage:{getItem:()=>setting},matchMedia:()=>media,performance:{now:()=>0},requestAnimationFrame:f=>{scheduled.set(++nextId,f);return nextId},cancelAnimationFrame:i=>scheduled.delete(i),queueMicrotask:f=>f(),MutationObserver:class{constructor(f){selection=f}observe(){}disconnect(){}},ResizeObserver:class{constructor(f){resize=f}observe(){}disconnect(){}},IntersectionObserver:class{constructor(f){intersection=f}observe(){}disconnect(){}},console};
const source=fs.readFileSync(__dirname+'/../../whisperflow/static/armor-display.js','utf8').replace(/^import .*?;\s*$/m,'');
vm.runInNewContext(source,context);
let checks=0;
function check(name,f){f();checks++;console.log('PASS '+name)}
function frame(t){const jobs=[...scheduled.values()];scheduled.clear();jobs.forEach(f=>f(t))}
check('initial visible Jarvis renders, explicit on overrides reduced motion',()=>{assert.ok(renders>0);assert.equal(scheduled.size,1)});
check('20 fps cap',()=>{const before=renders;frame(10);assert.equal(renders,before);frame(60);assert.equal(renders,before+1)});
check('Deckard cancels all frames',()=>{deckard=true;selection();assert.equal(scheduled.size,0);assert.equal(canvas.hidden,true)});
check('Jarvis resumes',()=>{deckard=false;selection();assert.equal(scheduled.size,1);assert.equal(canvas.hidden,false)});
check('hidden tab stops and visible resumes',()=>{doc.hidden=true;doc.fire('visibilitychange');assert.equal(scheduled.size,0);doc.hidden=false;doc.fire('visibilitychange');assert.equal(scheduled.size,1)});
check('offscreen stops and onscreen resumes',()=>{intersection([{isIntersecting:false}]);assert.equal(scheduled.size,0);intersection([{isIntersecting:true}]);assert.equal(scheduled.size,1)});
check('explicit toggle off draws still scene and cancels loop',()=>{setting='off';host.fire('click',{target:{closest:()=>true}});assert.equal(scheduled.size,0)});
check('reduced motion default stays still',()=>{setting=null;win.fire('storage');assert.equal(scheduled.size,0)});
check('explicit on re-enables motion',()=>{setting='on';win.fire('storage');assert.equal(scheduled.size,1)});
check('lost WebGL context cancels loop, restored resumes',()=>{canvas.fire('webglcontextlost',{preventDefault(){}});assert.equal(scheduled.size,0);canvas.fire('webglcontextrestored');assert.equal(scheduled.size,1)});
check('BFCache pagehide pauses and pageshow resumes',()=>{win.fire('pagehide',{persisted:true});assert.equal(scheduled.size,0);win.fire('pageshow');assert.equal(scheduled.size,1)});
check('final pagehide disposes GPU resources and cannot restart',()=>{const before=disposeCalls;win.fire('pagehide',{persisted:false});assert.equal(scheduled.size,0);assert.ok(disposeCalls>before);win.fire('pageshow');assert.equal(scheduled.size,0)});
console.log(checks+' lifecycle checks passed. Browser visual review still required.');
