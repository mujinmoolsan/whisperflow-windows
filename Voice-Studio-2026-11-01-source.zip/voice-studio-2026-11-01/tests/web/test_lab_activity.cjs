/* Dependency-free lifecycle checks for the decorative lab layer. */
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

function harness(options = {}) {
  const observers = [];
  const mutations = [];
  const rafs = new Map();
  const drawTimes = [];
  const effects = [];
  let nextRaf = 1;
  let now = 0;
  class EventTarget {
    constructor() { this.events = new Map(); }
    addEventListener(name, callback) {
      if (!this.events.has(name)) this.events.set(name, new Set());
      this.events.get(name).add(callback);
    }
    removeEventListener(name, callback) { this.events.get(name)?.delete(callback); }
    dispatch(name, event = {}) {
      for (const callback of [...(this.events.get(name) || [])]) callback({type: name, target: this, ...event});
    }
  }
  function changed(target, attributeName) { mutations.push({type: 'attributes', target, attributeName}); }
  function matches(element, selector) {
    if (selector === 'body') return element.tagName === 'BODY';
    if (selector.startsWith('#')) return element.id === selector.slice(1);
    if (selector.startsWith('.')) return selector.slice(1).split('.').every(name => element.classList.contains(name));
    return element.tagName.toLowerCase() === selector.toLowerCase();
  }
  class Element extends EventTarget {
    constructor(tagName) {
      super();
      this.tagName = tagName.toUpperCase();
      this.children = [];
      this.parentNode = null;
      this.attributes = new Map();
      this.style = {setProperty(key, value) {this[key] = value;}, removeProperty(key) {delete this[key];}};
      this.hidden = false;
      this.width = 1000;
      this.height = 400;
      this.clientWidth = 1000;
      this.clientHeight = 400;
      this.offsetWidth = 1000;
      this.offsetHeight = 400;
      this.dataset = new Proxy({}, {set: (target, name, value) => {
        target[name] = value;
        changed(this, 'data-' + name.replace(/[A-Z]/g, letter => '-' + letter.toLowerCase()));
        return true;
      }});
      this.classList = {
        contains: name => this.className.split(/\s+/).includes(name),
        add: (...names) => {this.className = [...new Set([...this.className.split(/\s+/).filter(Boolean), ...names])].join(' ');},
        remove: (...names) => {this.className = this.className.split(/\s+/).filter(name => !names.includes(name)).join(' ');},
        toggle: (name, force) => {const next = force ?? !this.classList.contains(name); next ? this.classList.add(name) : this.classList.remove(name); return next;}
      };
    }
    get className() {return this.attributes.get('class') || '';}
    set className(value) {this.setAttribute('class', value);}
    get isConnected() {return Boolean(this.parentNode || this.tagName === 'BODY');}
    get firstChild() {return this.children[0] || null;}
    setAttribute(name, value) {this.attributes.set(name, String(value)); changed(this, name);}
    getAttribute(name) {return this.attributes.get(name) ?? null;}
    removeAttribute(name) {this.attributes.delete(name); changed(this, name);}
    append(...children) {
      children.forEach(child => {child.parentNode = this; this.children.push(child);});
      mutations.push({type: 'childList', target: this});
    }
    appendChild(child) {this.append(child); return child;}
    prepend(...children) {children.forEach(child => {child.parentNode = this;}); this.children.unshift(...children); mutations.push({type: 'childList', target: this});}
    remove() {if (this.parentNode) this.parentNode.children = this.parentNode.children.filter(child => child !== this); this.parentNode = null;}
    querySelectorAll(selector) {
      const values = [];
      for (const child of this.children) {
        if (matches(child, selector)) values.push(child);
        values.push(...child.querySelectorAll(selector));
      }
      return values;
    }
    querySelector(selector) {return this.querySelectorAll(selector)[0] || null;}
    closest(selector) {for (let element = this; element; element = element.parentNode) if (matches(element, selector)) return element; return null;}
    contains(element) {for (let current = element; current; current = current.parentNode) if (current === this) return true; return false;}
    getBoundingClientRect() {return {x:0,y:80,left:0,top:80,width:this.clientWidth,height:this.clientHeight,right:this.clientWidth,bottom:80+this.clientHeight};}
    getContext() {
      if (options.noContext) return null;
      const gradient = {addColorStop() {}};
      if (!this.context) this.context = new Proxy({
        canvas: this,
        clearRect() {drawTimes.push(now);},
        createLinearGradient() {return gradient;},
        createRadialGradient() {return gradient;},
        createPattern() {return {};},
        measureText(text) {return {width: String(text).length * 5};},
        createImageData(width, height) {return {data: new Uint8ClampedArray(width * height * 4)};}
      }, {get(target, key) {if (key in target) return target[key]; return () => {};}});
      return this.context;
    }
  }
  class Observer {
    constructor(callback) {this.callback = callback; this.targets = new Map(); this.disconnected = false; observers.push(this);}
    observe(target, config = {}) {this.targets.set(target, config);}
    unobserve(target) {this.targets.delete(target);}
    disconnect() {this.targets.clear(); this.disconnected = true;}
  }
  class MutationObserver extends Observer {}
  class ResizeObserver extends Observer {}
  class IntersectionObserver extends Observer {}
  const document = new EventTarget();
  document.hidden = false;
  document.visibilityState = 'visible';
  document.readyState = 'complete';
  document.body = new Element('body');
  document.documentElement = document.body;
  document.body.dataset.studioTheme = options.theme || 'jarvis';
  const commandArea = new Element('section'); commandArea.className = 'commandArea';
  const orb = new Element('div'); orb.id = 'orb'; orb.className = options.theme === 'deckard' ? 'orb deckard' : 'orb';
  const toggle = new Element('button'); toggle.className = 'jarvisMotionToggle';
  const initialMotion = options.motion ?? (options.preference === 'on' || (options.preference !== 'off' && !options.reduced));
  toggle.setAttribute('aria-pressed', String(initialMotion));
  const input = new Element('textarea'); input.id = 'commandInput'; input.value = 'UNCHANGED COMMAND';
  const mic = new Element('button'); mic.id = 'micButton'; mic.setAttribute('aria-label', 'UNCHANGED MICROPHONE');
  if (options.toggle !== false) orb.append(toggle);
  commandArea.append(orb, input, mic); document.body.append(commandArea);
  document.createElement = tagName => new Element(tagName);
  document.createElementNS = (_, tagName) => new Element(tagName);
  document.querySelector = selector => selector === 'body' ? document.body : document.body.querySelector(selector);
  document.querySelectorAll = selector => document.body.querySelectorAll(selector);
  document.getElementById = id => document.querySelector('#' + id);
  const motion = new EventTarget(); motion.matches = Boolean(options.reduced);
  motion.addListener = callback => motion.addEventListener('change', callback);
  motion.removeListener = callback => motion.removeEventListener('change', callback);
  const window = new EventTarget();
  const preferences = new Map();
  if (options.preference) preferences.set('jarvisMotionPreference', options.preference);
  const localStorage = {
    getItem: key => preferences.get(key) ?? null,
    setItem: (...args) => effects.push(['localStorage.setItem', ...args])
  };
  const requestAnimationFrame = callback => {const id = nextRaf++; rafs.set(id, callback); return id;};
  const cancelAnimationFrame = id => rafs.delete(id);
  const forbidden = name => (...args) => {effects.push([name, ...args]); throw new Error('Unexpected side effect: ' + name);};
  Object.assign(window, {document, devicePixelRatio: 1, innerWidth: 1612, innerHeight: 884, localStorage, requestAnimationFrame, cancelAnimationFrame, matchMedia: () => motion});
  const context = {
    window, document, localStorage, MutationObserver, ResizeObserver, IntersectionObserver,
    requestAnimationFrame, cancelAnimationFrame, matchMedia: () => motion,
    performance: {now: () => now}, devicePixelRatio: 1, console,
    setTimeout: forbidden('setTimeout'), setInterval: forbidden('setInterval'), clearTimeout() {}, clearInterval() {},
    fetch: forbidden('fetch'), Audio: forbidden('Audio'), AudioContext: forbidden('AudioContext'),
    navigator: {mediaDevices: {getUserMedia: forbidden('getUserMedia')}},
    getComputedStyle: () => ({position: 'relative', display: 'block', visibility: 'visible'})
  };
  function flush() {
    let remaining = 20;
    while (mutations.length && remaining--) {
      const batch = mutations.splice(0);
      for (const observer of observers.filter(value => value instanceof MutationObserver)) {
        const records = batch.filter(record => [...observer.targets].some(([target, config]) => {
          const descendant = target === record.target || (config.subtree && target.contains(record.target));
          return descendant && (record.type === 'childList' ? config.childList : config.attributes && (!config.attributeFilter || config.attributeFilter.includes(record.attributeName)));
        }));
        if (records.length) observer.callback(records, observer);
      }
    }
    assert.ok(remaining > 0, 'Mutation observers must settle without a feedback loop');
  }
  function pump(milliseconds, step = 1000 / 60) {
    const end = now + milliseconds;
    while (now + step <= end + .00001) {
      now += step;
      const callbacks = [...rafs.values()]; rafs.clear();
      callbacks.forEach(callback => callback(now)); flush();
    }
  }
  function setTheme(theme) {
    document.body.dataset.studioTheme = theme;
    orb.classList.toggle('deckard', theme === 'deckard');
    flush();
  }
  function visibility(hidden) {
    document.hidden = hidden; document.visibilityState = hidden ? 'hidden' : 'visible';
    document.dispatch('visibilitychange'); flush();
  }
  function setMotion(enabled) {
    preferences.set('jarvisMotionPreference', enabled ? 'on' : 'off');
    toggle.setAttribute('aria-pressed', String(enabled)); flush();
  }
  function reduced(enabled) {motion.matches = enabled; motion.dispatch('change', {matches: enabled}); flush();}
  return {context, document, window, commandArea, orb, toggle, input, mic, observers, rafs, drawTimes, effects, motion,
    run(source) {vm.runInNewContext(source, context, {filename:'lab-activity.js'}); flush();},
    pump, flush, setTheme, visibility, setMotion, reduced, now: () => now};
}

function runChecks() {
  const source = fs.readFileSync(path.join(__dirname, '../../whisperflow/static/lab-activity.js'), 'utf8');
  const css = fs.readFileSync(path.join(__dirname, '../../whisperflow/static/lab-activity.css'), 'utf8');
  const app = harness();
  app.run(source);
  const layer = app.commandArea.querySelector('.labActivityLayer');
  assert.ok(layer, 'Jarvis mounts a decorative layer');
  assert.equal(layer.getAttribute('aria-hidden'), 'true');
  assert.equal(layer.hidden, false);
  assert.equal(layer.dataset.motion, 'running');
  assert.equal(layer.querySelectorAll('.labDisplay').length, 6);
  assert.equal(layer.querySelectorAll('.labArmCanvas').length, 1);
  assert.equal(app.drawTimes.length, 7, 'One initial paint for all seven canvases');
  assert.equal(app.rafs.size, 1);
  app.run(source);
  assert.equal(app.commandArea.querySelectorAll('.labActivityLayer').length, 1, 'Repeated inclusion must not duplicate the layer');
  assert.equal(app.rafs.size, 1, 'Repeated inclusion must not create another loop');

  app.pump(2000);
  const frameTimes = [...new Set(app.drawTimes)];
  assert.ok(frameTimes.length > 20, 'Animation progresses while visible and enabled');
  assert.ok(frameTimes.length <= 49, 'Two seconds contain at most 48 animated frames plus the initial paint');
  for (let index = 1; index < frameTimes.length; index++) {
    assert.ok(frameTimes[index] - frameTimes[index - 1] >= 1000 / 24 - .00001, 'Render rate never exceeds 24 fps');
  }
  for (const time of frameTimes) assert.equal(app.drawTimes.filter(value => value === time).length, 7, 'Every rendered frame paints all seven canvases once');

  function paused(change, message) {
    change();
    const draws = app.drawTimes.length;
    assert.equal(app.rafs.size, 0, message + ': RAF is cancelled');
    app.pump(500);
    assert.equal(app.drawTimes.length, draws, message + ': no background painting');
  }
  function resumed(change, message) {
    const draws = app.drawTimes.length;
    change();
    assert.equal(app.rafs.size, 1, message + ': exactly one RAF');
    app.pump(150);
    assert.ok(app.drawTimes.length > draws, message + ': painting resumes');
  }

  paused(() => {app.document.body.dataset.studioTheme = 'deckard'; app.flush();}, 'Body Deckard theme');
  assert.equal(layer.hidden, true);
  resumed(() => {app.document.body.dataset.studioTheme = 'jarvis'; app.flush();}, 'Body Jarvis theme');
  paused(() => {app.orb.classList.add('deckard'); app.flush();}, 'Orb Deckard class');
  resumed(() => {app.orb.classList.remove('deckard'); app.flush();}, 'Orb Jarvis class');
  paused(() => app.visibility(true), 'Hidden document');
  resumed(() => app.visibility(false), 'Visible document');
  paused(() => app.setMotion(false), 'Existing motion toggle disabled');
  assert.equal(layer.dataset.motion, 'paused');
  resumed(() => app.setMotion(true), 'Existing motion toggle enabled');

  const intersection = app.observers.find(observer => observer.constructor.name === 'IntersectionObserver');
  paused(() => intersection.callback([{target: layer, isIntersecting: false}]), 'Offscreen layer');
  resumed(() => intersection.callback([{target: layer, isIntersecting: true}]), 'Onscreen layer');
  paused(() => {app.commandArea.clientWidth = 0; app.commandArea.getBoundingClientRect = () => ({width:0}); app.window.dispatch('resize');}, 'Zero-width stage');
  resumed(() => {app.commandArea.clientWidth = 800; app.window.dispatch('resize');}, 'Stage resized to visible width');
  assert.equal(layer.querySelector('.labActivityStage').style.transform, `scale(${800 / 1983})`);
  paused(() => app.window.dispatch('pagehide', {persisted: true}), 'BFCache pagehide');
  assert.ok(app.observers.some(observer => observer.targets.size), 'BFCache keeps observers available');
  resumed(() => app.window.dispatch('pageshow'), 'BFCache pageshow');

  const inputBefore = app.input.value;
  const micBefore = app.mic.getAttribute('aria-label');
  assert.equal(inputBefore, 'UNCHANGED COMMAND');
  assert.equal(micBefore, 'UNCHANGED MICROPHONE');
  assert.equal(app.input.events.size, 0);
  assert.equal(app.mic.events.size, 0);
  assert.deepEqual(app.effects, [], 'Animation does not call network, media, timers or preference writes');
  paused(() => app.window.dispatch('pagehide', {persisted: false}), 'Final pagehide');
  assert.ok(app.observers.every(observer => observer.disconnected), 'Final teardown disconnects all observers');
  app.window.dispatch('pageshow'); app.visibility(false); app.setMotion(true); app.pump(500);
  assert.equal(app.rafs.size, 0, 'Destroyed layer stays stopped');
  assert.equal(app.input.value, inputBefore);
  assert.equal(app.mic.getAttribute('aria-label'), micBefore);

  const initiallyDeckard = harness({theme:'deckard'}); initiallyDeckard.run(source);
  assert.equal(initiallyDeckard.rafs.size, 0);
  assert.equal(initiallyDeckard.drawTimes.length, 0);
  initiallyDeckard.setTheme('jarvis'); initiallyDeckard.pump(100);
  assert.ok(initiallyDeckard.drawTimes.length > 0, 'Initially hidden layer starts when Jarvis is selected');
  for (const options of [{motion:false}, {reduced:true}, {toggle:false, preference:'off'}, {toggle:false, reduced:true}]) {
    const frozen = harness(options); frozen.run(source); frozen.pump(200);
    assert.equal(frozen.rafs.size, 0, 'Initial disabled motion never schedules RAF');
    assert.equal(frozen.drawTimes.length, 7, 'Disabled motion retains one still frame');
  }
  const media = harness({toggle:false}); media.run(source);
  media.reduced(true); const mediaPaints = media.drawTimes.length; media.pump(200);
  assert.equal(media.rafs.size, 0);
  assert.equal(media.drawTimes.length, mediaPaints, 'OS reduced-motion change pauses the fallback mode');
  media.reduced(false); media.pump(100);
  assert.ok(media.drawTimes.length > mediaPaints);
  const explicitOn = harness({toggle:false, preference:'on', reduced:true}); explicitOn.run(source);
  assert.equal(explicitOn.rafs.size, 1, 'Explicit motion-on follows the existing neural renderer preference precedence');
  const noContext = harness({noContext:true}); noContext.run(source);
  assert.equal(noContext.commandArea.querySelector('.labActivityLayer'), null);
  assert.equal(noContext.rafs.size, 0);
  const noStage = harness(); noStage.commandArea.remove(); noStage.run(source);
  assert.equal(noStage.rafs.size, 0, 'Missing application stage is a safe no-op');

  for (const selector of ['.labActivityLayer', '.labActivityStage', '.labActivityStage canvas']) {
    const escaped = selector.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    const declaration = css.match(new RegExp(escaped + '\\s*\\{([^}]*)\\}'));
    assert.ok(declaration, 'CSS contains ' + selector);
    assert.match(declaration[1], /pointer-events\s*:\s*none\s*!important/, selector + ' cannot intercept controls');
  }
  assert.match(css, /body\[data-studio-theme="deckard"\][^{]*\.labActivityLayer[^}]*display\s*:\s*none\s*!important/);
  console.log('PASS: 6 screens + arm, duplicate inclusion, 24 fps cap, character switching, hidden/offscreen/zero-size pause, motion preference + OS fallback, BFCache, final teardown, canvas fallback, read-only controls, no API/media side effects, pointer transparency.');
}

module.exports = {harness};
if (require.main === module) runChecks();
