// Offline checks use real Three.js geometry and mocked render/media boundaries.
import fs from 'node:fs';
import vm from 'node:vm';
import assert from 'node:assert/strict';
import * as Library from '../../whisperflow/static/vendor/three.module.js';

let now=1000,scene,nextFrame,frames=0,onLoad,selected,onVisibility;
const listeners=new Map(),classes=new Set(['deckard']);
const canvas={setAttribute(){},addEventListener(){},hidden:false};
const host={clientWidth:510,clientHeight:350,querySelector(){return null;},append(){},
  classList:{contains:v=>classes.has(v),add:v=>classes.add(v),remove:v=>classes.delete(v)}};
class Renderer {
  capabilities={getMaxAnisotropy:()=>4};
  setClearColor(){}setPixelRatio(){}setSize(){}dispose(){}
  render(value){scene=value;frames++;}
}
class Loader{load(_url,ready){onLoad=ready;return new Library.Texture();}}
class Observer{constructor(callback){this.callback=callback;}observe(){}disconnect(){}}
class Mutation extends Observer{constructor(callback){super(callback);selected=callback;}}
const doc={hidden:false,getElementById:()=>host,createElement:()=>canvas,
  addEventListener:(name,fn)=>{if(name==='visibilitychange')onVisibility=fn;},removeEventListener(){}};
const window={devicePixelRatio:2,addEventListener:(name,callback)=>listeners.set(name,callback),
  removeEventListener(){},dispatchEvent(){}};
const context={THREE:{...Library,WebGLRenderer:Renderer,TextureLoader:Loader},document:doc,window,URL,
  performance:{now:()=>now},matchMedia:()=>({matches:false,addEventListener(){},removeEventListener(){}}),
  ResizeObserver:Observer,IntersectionObserver:Observer,MutationObserver:Mutation,
  requestAnimationFrame:fn=>{nextFrame=fn;return 1;},cancelAnimationFrame:()=>{nextFrame=null;},
  CustomEvent:class{constructor(type,init){this.type=type;this.detail=init?.detail;}}};
const code=fs.readFileSync(new URL('../../whisperflow/static/deckard-avatar.js',import.meta.url),'utf8')
  .replace("import * as THREE from './vendor/three.module.js';",'')
  .replace('import.meta.url',"'http://127.0.0.1:8770/static/deckard-avatar.js'");
vm.runInNewContext(code,context,{timeout:5000});onLoad();
assert.ok(scene&&classes.has('deckardModelReady'),'Loaded artwork is rendered.');
const portrait=scene.getObjectByName('DeckardArticulatedPortrait');
const cavity=scene.getObjectByName('DeckardMouthInterior');
const before=Array.from(portrait.geometry.attributes.position.array);
const uv=portrait.geometry.attributes.uv.array;
let lowerIndex=-1,upperIndex=-1,best=Infinity;
for(let i=0;i<uv.length/2;i++){
  const x=uv[i*2]*1448,y=(1-uv[i*2+1])*1086;
  const d=Math.abs(x-725)+Math.abs(y-464);
  if(d<best-.001){best=d;upperIndex=i;lowerIndex=i;}
  else if(Math.abs(d-best)<.001)lowerIndex=i;
}
assert.notEqual(lowerIndex,upperIndex,'Lip seam has independent upper and lower vertices.');
assert.ok(portrait.geometry.attributes.position.count<15000,'Relief stays within a modest vertex budget.');
assert.equal(cavity.visible,false,'Neutral portrait has no artificial mouth overlay.');
assert.equal(nextFrame,undefined,'Neutral portrait schedules no continuous animation.');
const speech=detail=>listeners.get('studio-speech')({detail});
const tick=delta=>{now+=delta;const fn=nextFrame;nextFrame=null;fn?.(now);};
speech({type:'start',character:'deckard',envelope:Array(20).fill(1),frame_ms:40,duration_ms:800,offset_ms:0});
tick(100);
const open=portrait.geometry.attributes.position.array;
assert.ok(open[lowerIndex*3+1]<before[lowerIndex*3+1]-.02,'Actual lower lip vertices open with played speech.');
assert.equal(open[upperIndex*3+1],before[upperIndex*3+1],'Upper lip stays anchored to the artwork.');
assert.equal(open[1],before[1],'Helmet and non-face vertices remain fixed.');
assert.equal(cavity.visible,true,'Opening exposes the recessed mouth interior.');
speech({type:'stop'});
assert.deepEqual(Array.from(portrait.geometry.attributes.position.array),before,'Stop restores original portrait exactly.');
assert.equal(nextFrame,null,'Stop cancels continuous rendering.');
speech({type:'start',character:'jarvis',envelope:[1,1],frame_ms:40,duration_ms:80});
tick(100);assert.deepEqual(Array.from(portrait.geometry.attributes.position.array),before,'Other character cannot drive the mouth.');
speech({type:'start',character:'deckard',envelope:[1,1],frame_ms:40,duration_ms:80,offset_ms:90});
tick(100);assert.equal(cavity.visible,false,'Expired playback does not animate.');
speech({type:'level',character:'deckard',level:.9});tick(80);
assert.ok(portrait.geometry.attributes.position.array[lowerIndex*3+1]<before[lowerIndex*3+1],'Live output amplitude drives the same mesh.');
doc.hidden=true;onVisibility();assert.equal(nextFrame,null,'Hidden document stops rendering.');
doc.hidden=false;onVisibility();
classes.delete('deckard');selected();assert.equal(canvas.hidden,true);assert.equal(nextFrame,null,'Unselected avatar stops rendering.');
assert.deepEqual(Array.from(portrait.geometry.attributes.position.array),before,'Switching characters closes mouth.');
assert.ok(Array.from(portrait.geometry.attributes.position.array).every(Number.isFinite),'All vertices stay finite.');
console.log(JSON.stringify({passed:18,vertices:portrait.geometry.attributes.position.count,renderedFrames:frames,texture:'deckard-resynthesized.png',lipVertices:{upperIndex,lowerIndex}}));
