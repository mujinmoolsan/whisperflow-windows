const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

const source = fs.readFileSync(path.join(__dirname, '../../whisperflow/static/persona-theme.js'), 'utf8');
function mount({initial = 'jarvis', extras = true, hasOrb = true} = {}) {
  const nodes = new Map();
  const listeners = new Map();
  const classes = new Set(initial === 'deckard' ? ['deckard', 'deckardModelReady'] : []);
  const orb = {classList: {contains: value => classes.has(value)}};
  const text = {nodeType: 3, nodeValue: 'JARVIS'};
  const subtitleChild = {nodeType: 1};
  function element(selector) {
    const node = {textContent: '', attributes: {}, setAttribute(key, value) {this.attributes[key] = value;}};
    nodes.set(selector, node);
    return node;
  }
  if (extras) {
    element('.brand');
    element('.brand > span:last-child').childNodes = [text, subtitleChild];
    ['.brandSubtitle', '.workspaceHeading .eyebrow', '.workspaceTag', '.footerBrand', 'meta[name="theme-color"]'].forEach(element);
  }
  const document = {
    body: {dataset: {}},
    getElementById: id => id === 'orb' && hasOrb ? orb : null,
    querySelector: selector => nodes.get(selector) || null,
    title: 'original'
  };
  let observer;
  class MutationObserver {
    constructor(callback) {this.callback = callback; observer = this;}
    observe(target, options) {this.target = target; this.options = options;}
    disconnect() {this.disconnected = true;}
  }
  vm.runInNewContext(source, {document, MutationObserver, window: {addEventListener(name, callback) {listeners.set(name, callback);}}});
  return {document, nodes, orb, classes, text, subtitleChild, listeners, get observer() {return observer;}, setTheme(value) {
    value === 'deckard' ? classes.add('deckard') : classes.delete('deckard');
    observer.callback();
  }};
}

const app = mount();
assert.equal(app.document.body.dataset.studioTheme, 'jarvis');
assert.equal(app.document.title, '음성 작업실 · JARVIS');
assert.equal(app.observer.target, app.orb);
assert.deepEqual(Array.from(app.observer.options.attributeFilter), ['class']);
app.classes.add('listening');
app.setTheme('deckard');
assert.equal(app.document.body.dataset.studioTheme, 'deckard');
assert.equal(app.text.nodeValue, 'DECKARD');
assert.equal(app.nodes.get('.brand').attributes['aria-label'], '데커드 음성 작업실 홈');
assert.equal(app.nodes.get('.brandSubtitle').textContent, 'BRAVE POLICE WORKSPACE');
assert.equal(app.nodes.get('.workspaceTag').textContent, '우리들의 작업 기지');
assert.equal(app.nodes.get('meta[name="theme-color"]').attributes.content, '#173e67');
assert.equal(app.nodes.get('.brand > span:last-child').childNodes[1], app.subtitleChild);
assert.ok(app.classes.has('listening'), 'Theme changes preserve live avatar state');
app.nodes.get('.workspaceTag').textContent = 'untouched during unrelated orb mutations';
app.observer.callback();
assert.equal(app.nodes.get('.workspaceTag').textContent, 'untouched during unrelated orb mutations');
app.setTheme('jarvis');
assert.equal(app.document.body.dataset.studioTheme, 'jarvis');
assert.equal(app.text.nodeValue, 'JARVIS');
assert.equal(app.nodes.get('.brand').attributes['aria-label'], '자비스 음성 작업실 홈');

const restored = mount({initial: 'deckard'});
assert.equal(restored.document.body.dataset.studioTheme, 'deckard', 'Persisted avatar state is respected at first execution');
assert.ok(restored.classes.has('deckardModelReady'));
restored.listeners.get('pagehide')({persisted: true});
assert.notEqual(restored.observer.disconnected, true);
restored.listeners.get('pageshow')();
assert.equal(restored.document.body.dataset.studioTheme, 'deckard');
restored.listeners.get('pagehide')({persisted: false});
assert.equal(restored.observer.disconnected, true);
const minimal = mount({extras: false});
minimal.setTheme('deckard');
assert.equal(minimal.document.body.dataset.studioTheme, 'deckard');
assert.equal(mount({hasOrb: false}).document.title, 'original');
console.log('PASS: initial selection, persona switching, labels, Korean text, optional elements, preserved avatar state, unrelated mutations, page lifecycle.');
