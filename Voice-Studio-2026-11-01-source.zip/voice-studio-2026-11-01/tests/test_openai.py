import io
import json
import os
import unittest
from unittest.mock import patch

from whisperflow.windows_openai import request_gpt


class GPTTests(unittest.TestCase):
    def test_responses_request_preserves_history_language_and_extracts_text(self):
        body = {'output': [{'type': 'reasoning'}, {'type': 'message', 'content': [
            {'type': 'output_text', 'text': 'Ready.'}]}]}
        response = io.StringIO(json.dumps(body))
        with patch.dict(os.environ, {'OPENAI_API_KEY': 'dummy-test-value'}), \
                patch('urllib.request.urlopen', return_value=response) as mock:
            answer = request_gpt([{'role': 'user', 'content': 'Hello'}], 'AI 1.4', 'en', 'gpt-5-mini')
        self.assertEqual(answer, 'Ready.')
        request = mock.call_args.args[0]
        payload = json.loads(request.data)
        self.assertFalse(payload['store'])
        self.assertIn('English', payload['instructions'])
        self.assertEqual(payload['input'][-1]['content'], 'AI 1.4')
        self.assertNotIn('dummy-test-value', request.data.decode())

    def test_missing_key_does_not_make_a_network_request(self):
        with patch.dict(os.environ, {'OPENAI_API_KEY': ''}), patch('urllib.request.urlopen') as mock:
            with self.assertRaises(RuntimeError):
                request_gpt([], 'Hello', 'en', 'gpt-5-mini')
            mock.assert_not_called()
