import asyncio
import json
from pathlib import Path
import sys
import unittest

from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client

ROOT = Path(__file__).resolve().parents[1]


class MCPTests(unittest.IsolatedAsyncioTestCase):
    async def test_stdio_initialization_tools_and_local_status(self):
        parameters = StdioServerParameters(command=sys.executable,
                                           args=[str(ROOT / 'run_jarvis_mcp.py')])
        async with stdio_client(parameters) as streams:
            async with ClientSession(*streams) as client:
                await client.initialize()
                names = {tool.name for tool in (await client.list_tools()).tools}
                self.assertEqual(names, {'jarvis_status', 'jarvis_speak', 'jarvis_stop'})
                result = await client.call_tool('jarvis_status')
                self.assertFalse(result.isError)
                # Ready false is also a valid status when the companion service isn't running.
                content = json.loads(result.content[0].text)
                self.assertIsInstance(content['ready'], bool)
                schema = next(tool for tool in (await client.list_tools()).tools
                              if tool.name == 'jarvis_speak').inputSchema
                self.assertEqual(set(schema['properties']['character']['enum']), {'jarvis', 'deckard'})
                self.assertEqual(set(schema['properties']['language']['enum']), {'ko', 'en'})

    async def test_english_deckard_is_rejected_before_contacting_service(self):
        from whisperflow.jarvis_mcp import jarvis_speak
        from unittest.mock import patch
        with patch('whisperflow.jarvis_mcp.request_service') as request:
            with self.assertRaises(ValueError):
                jarvis_speak('Hello', language='en', character='deckard')
            request.assert_not_called()
