"""Regression tests for integrating CUDA into the existing resident voice server.

All native processes and model calls are fake; no GPU or reference voice is loaded.
"""
from contextlib import ExitStack, contextmanager
from pathlib import Path
import tempfile
import threading
import unittest
from unittest.mock import Mock, patch

from whisperflow import approved_voice, native_qwen


@contextmanager
def native_install():
    with tempfile.TemporaryDirectory() as temporary, ExitStack() as stack:
        root = Path(temporary)
        cuda, cpu, models = root/'cuda', root/'cpu', root/'models'
        for folder in (cuda, cpu, models):
            folder.mkdir()
        for path in (cuda/'llama-tts.exe', cpu/'llama-tts.exe', models/'tts-q4.gguf', models/'codec-q8.gguf'):
            path.touch()
        stack.enter_context(patch.dict('os.environ', {
            'JARVIS_NATIVE_CUDA_DIR': str(cuda), 'JARVIS_NATIVE_DIR': str(cpu),
            'JARVIS_NATIVE_MODEL_DIR': str(models), 'JARVIS_FORCE_CPU': '0'}))
        stack.enter_context(patch.object(native_qwen, 'ROOT', root))
        stack.enter_context(patch.object(native_qwen, '_cuda_failed', False))
        yield root


class NativeCancellationTests(unittest.TestCase):
    def test_custom_cpu_directory_discovers_sibling_cuda_runtime(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            cuda = root/'llama-cuda'
            cuda.mkdir()
            executable = cuda/'llama-tts.exe'
            executable.touch()
            with patch.dict('os.environ', {'JARVIS_NATIVE_DIR': str(root/'custom-cpu'),
                    'JARVIS_NATIVE_CUDA_DIR': '', 'JARVIS_FORCE_CPU': '0'}), \
                    patch.object(native_qwen, '_cuda_failed', False):
                self.assertTrue(native_qwen.use_gpu())
                self.assertEqual(native_qwen.paths()[0], executable)

    def test_stop_between_failed_gpu_and_cpu_fallback_launches_no_cpu(self):
        with native_install() as root:
            def failed_gpu(*args):
                native_qwen.stop_pending()
                raise RuntimeError('simulated CUDA error')
            with patch.object(native_qwen, '_run', side_effect=failed_gpu) as run:
                with self.assertRaises(native_qwen.SynthesisCancelled):
                    native_qwen.generate('test', root/'reference.wav', 'ko')
                self.assertEqual(run.call_count, 1)
                self.assertTrue(native_qwen.use_gpu())

    def test_stop_before_cpu_returns_does_not_disable_gpu_or_return_audio(self):
        with native_install() as root:
            def run(*args):
                if args[-2]:
                    raise RuntimeError('simulated CUDA error')
                native_qwen.stop_pending()
                return b'cancelled audio'
            with patch.object(native_qwen, '_run', side_effect=run):
                with self.assertRaises(native_qwen.SynthesisCancelled):
                    native_qwen.generate('test', root/'reference.wav', 'ko')
                self.assertTrue(native_qwen.use_gpu())

    def test_gpu_startup_oserror_falls_back_to_cpu(self):
        with native_install() as root:
            with patch.object(native_qwen, '_run', side_effect=[OSError('startup failed'), b'audio']) as run:
                self.assertEqual(native_qwen.generate('test', root/'reference.wav', 'ko'), b'audio')
                self.assertEqual([call.args[-2] for call in run.call_args_list], [True, False])
                self.assertFalse(native_qwen.use_gpu())

    def test_cancelled_generation_cannot_launch_a_new_process(self):
        with native_install() as root, patch('subprocess.Popen') as popen:
            generation = native_qwen._cancel_generation
            native_qwen.stop_pending()
            with self.assertRaises(native_qwen.SynthesisCancelled):
                native_qwen._run(root/'cuda/llama-tts.exe', root/'models/tts-q4.gguf',
                    root/'models/codec-q8.gguf', 'test', root/'reference.wav', 'ko',
                    42, None, None, True, generation)
            popen.assert_not_called()

    def test_gpu_start_failure_is_logged_before_successful_cpu_fallback(self):
        with native_install() as root:
            def popen(command, cwd=None, **kwargs):
                if Path(command[0]).parent.name == 'cuda':
                    raise OSError('simulated invalid GPU executable')
                process = Mock(returncode=0)
                def communicate(timeout=None):
                    Path(cwd, command[command.index('--output')+1]).write_bytes(b'audio')
                    return b'', b''
                process.communicate.side_effect = communicate
                process.jarvis_cancelled = False
                return process
            with patch('subprocess.Popen', side_effect=popen):
                self.assertEqual(native_qwen.generate('test', root/'reference.wav', 'ko'), b'audio')
            log = (root/'.windows-data/native-error.log').read_text(encoding='utf-8')
            self.assertIn('[GPU]', log)
            self.assertIn('simulated invalid GPU executable', log)


class ResidentMemoryTests(unittest.TestCase):
    def test_idle_release_does_not_kill_active_speech(self):
        resident = Mock()
        resident.active = threading.Event()
        resident.active.set()
        with patch.object(approved_voice, '_resident', resident):
            approved_voice.stop_worker(only_idle=True)
            resident.close.assert_not_called()
            self.assertIs(approved_voice._resident, resident)

    def test_idle_release_releases_owned_resident(self):
        resident = Mock()
        resident.active = threading.Event()
        with patch.object(approved_voice, '_resident', resident):
            approved_voice.stop_worker(only_idle=True)
            resident.close.assert_called_once_with()
            self.assertIsNone(approved_voice._resident)

    def test_native_gpu_releases_idle_deckard_before_synthesis(self):
        with tempfile.TemporaryDirectory() as temporary:
            reference = Path(temporary)/'reference.wav'
            reference.touch()
            preset = {'reference': str(reference), 'seed': 42, 'engine': 'native'}
            events = []
            with patch.object(native_qwen, 'use_gpu', return_value=True), \
                    patch.object(approved_voice, 'stop_worker', side_effect=lambda **kw: events.append(('release', kw))), \
                    patch.object(native_qwen, 'generate', side_effect=lambda *a, **kw: events.append(('generate', {})) or b'audio'):
                self.assertEqual(approved_voice.generate('test', preset), b'audio')
                self.assertEqual(events, [('release', {'only_idle': True}), ('generate', {})])

    def test_cpu_voice_preserves_the_warm_deckard_worker(self):
        with tempfile.TemporaryDirectory() as temporary:
            reference = Path(temporary)/'reference.wav'
            reference.touch()
            preset = {'reference': str(reference), 'seed': 42, 'engine': 'native'}
            with patch.object(native_qwen, 'use_gpu', return_value=False), \
                    patch.object(approved_voice, 'stop_worker') as stop, \
                    patch.object(native_qwen, 'generate', return_value=b'audio'):
                approved_voice.generate('test', preset)
                stop.assert_not_called()


if __name__ == '__main__':
    unittest.main()
