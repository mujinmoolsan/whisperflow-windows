"""Use an installed local voice runtime without putting its path in public source."""
import json
from pathlib import Path
import subprocess
import sys
import os

ROOT = Path(__file__).resolve().parent


def runtime():
    default = ROOT / '.qwen-env/Scripts/python.exe'
    config = ROOT / 'windows-config.json'
    if default.is_file():
        return default
    if config.is_file():
        value = json.loads(config.read_text(encoding='utf-8-sig')).get('QWEN_PYTHON', '')
        if value and Path(value).is_file():
            return Path(value)
    raise RuntimeError('Run Setup-Qwen-CPU.cmd first.')


if __name__ == '__main__':
    try:
        config = ROOT / 'windows-config.json'
        if config.is_file():
            values = json.loads(config.read_text(encoding='utf-8-sig'))
            for key in ('JARVIS_NATIVE_DIR','JARVIS_NATIVE_MODEL_DIR','HF_HOME'):
                if values.get(key):
                    os.environ[key] = str(values[key])
        os.environ['PYTHONPATH'] = str(ROOT/'.windows-env') + os.pathsep + os.environ.get('PYTHONPATH','')
        raise SystemExit(subprocess.call([str(runtime()), '-m', 'whisperflow.windows_qwen',
                                         '--device', 'cpu'], cwd=str(ROOT)))
    except RuntimeError as exc:
        print(exc)
        raise SystemExit(1)
