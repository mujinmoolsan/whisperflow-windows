"""Find similar-speaker candidates, not confirmed identities or fine-tuning data.

Uses ONLY Qwen's small ECAPA speaker encoder from an already-downloaded
checkpoint. It does not load the speech generator, upload audio, or replace
the approved voice reference automatically.
"""
import argparse
import json
from pathlib import Path
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parent


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('source', type=Path)
    parser.add_argument('--character', choices=['jarvis','deckard'], default='deckard')
    parser.add_argument('--output', type=Path, default=ROOT/'.references/candidates')
    parser.add_argument('--window', type=float, default=4)
    parser.add_argument('--step', type=float, default=6)
    parser.add_argument('--top', type=int, default=8)
    args = parser.parse_args()
    if not args.source.is_file() or args.window < 2 or args.step < 1:
        parser.error('Choose an existing audio file and a valid scan interval.')

    import numpy as np
    import soundfile as sf
    import torch
    import imageio_ffmpeg
    from safetensors import safe_open
    from qwen_tts.core.models.modeling_qwen3_tts import Qwen3TTSSpeakerEncoder, mel_spectrogram
    from qwen_tts.core.models.configuration_qwen3_tts import Qwen3TTSSpeakerEncoderConfig
    torch.set_num_threads(2)
    snapshots = ROOT/'.models/hub/models--Qwen--Qwen3-TTS-12Hz-0.6B-Base/snapshots'
    configs = list(snapshots.glob('*/config.json'))
    if not configs:
        raise SystemExit('The optional Python Qwen checkpoint must be downloaded first.')
    checkpoint = configs[0].parent
    config = json.loads(configs[0].read_text(encoding='utf-8'))
    encoder = Qwen3TTSSpeakerEncoder(Qwen3TTSSpeakerEncoderConfig(**config['speaker_encoder_config']))
    state = {}
    for file in checkpoint.glob('*.safetensors'):
        with safe_open(file, framework='pt', device='cpu') as weights:
            for key in weights.keys():
                if key.startswith('speaker_encoder.'):
                    state[key.removeprefix('speaker_encoder.')] = weights.get_tensor(key).float()
    encoder.load_state_dict(state)
    encoder.eval()

    @torch.inference_mode()
    def embed(audio):
        mels = mel_spectrogram(torch.from_numpy(audio).unsqueeze(0), n_fft=1024, num_mels=128,
                               sampling_rate=24000, hop_size=256, win_size=1024, fmin=0, fmax=12000)
        vector = encoder(mels.transpose(1,2))[0].float().numpy().flatten()
        return vector / max(float(np.linalg.norm(vector)), 1e-9)

    parts = list((ROOT/'.references'/f'{args.character}-parts').glob('*.wav'))
    if not parts:
        parts = [ROOT/'.references'/f'{args.character}.wav']
    anchors = []
    for part in parts:
        audio, rate = sf.read(part, dtype='float32')
        if rate != 24000:
            raise ValueError('Reference WAV files must be 24kHz.')
        anchors.append(embed(audio))
    centroid = np.mean(anchors, axis=0)
    centroid /= np.linalg.norm(centroid)
    print('Reference encoder ready. Scanning local audio; candidates need listening review.', flush=True)
    args.output.mkdir(parents=True, exist_ok=True)
    candidates = []
    with tempfile.TemporaryDirectory(dir=ROOT/'.references') as temporary:
        decoded = Path(temporary)/'episode.wav'
        subprocess.run([imageio_ffmpeg.get_ffmpeg_exe(), '-v','error','-i',str(args.source),
                        '-ac','1','-ar','24000','-y',str(decoded)], check=True, capture_output=True)
        with sf.SoundFile(decoded) as episode:
            duration = len(episode)/episode.samplerate
            for index, start in enumerate(np.arange(0, max(0,duration-args.window), args.step)):
                episode.seek(int(start*24000))
                audio = episode.read(int(args.window*24000), dtype='float32')
                if float(np.sqrt(np.mean(audio**2))) < .008:
                    continue
                similarity = float(np.dot(embed(audio), centroid))
                candidates.append({'start':round(float(start),2), 'end':round(float(start+args.window),2),
                                   'similarity':round(similarity,4), 'confirmed':False})
                if index % 25 == 0:
                    print(f'Scanned {int(start)} / {int(duration)} seconds', flush=True)
            selected = []
            for candidate in sorted(candidates, key=lambda item:item['similarity'], reverse=True):
                if any(abs(candidate['start']-item['start']) < args.window for item in selected):
                    continue
                selected.append(candidate)
                if len(selected) == args.top:
                    break
            for index, candidate in enumerate(selected,1):
                episode.seek(int(candidate['start']*24000))
                audio = episode.read(int(args.window*24000), dtype='float32')
                name = f'{args.character}-candidate-{index:02}.wav'
                sf.write(args.output/name, audio, 24000, subtype='PCM_16')
                candidate['file'] = name
    report = {'method':'Qwen ECAPA cosine similarity; not speaker identity confirmation',
              'source':args.source.name, 'reference_parts':len(anchors), 'candidates':selected}
    (args.output/'candidates.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    print('Saved candidate clips and report. The approved reference was not changed.', flush=True)


if __name__ == '__main__':
    main()
