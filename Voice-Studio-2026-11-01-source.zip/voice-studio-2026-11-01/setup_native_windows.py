"""Install the verified official llama.cpp CPU build (and, on NVIDIA PCs, the CUDA build)
and Qwen GGUF locally. `--gpu-only` adds just the CUDA build to an existing install."""
from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import urllib.request
import zipfile

ROOT = Path(__file__).resolve().parent
TAG = 'b11960'
CUDA_ASSETS = ('llama-%s-bin-win-cuda-12.4-x64.zip' % TAG, 'cudart-llama-bin-win-cuda-12.4-x64.zip')


def has_nvidia():
    system = Path(os.environ.get('SystemRoot', r'C:\Windows')) / 'System32' / 'nvidia-smi.exe'
    return system.is_file() or shutil.which('nvidia-smi') is not None


def fetch(url, path):
    if path.is_file():
        return
    temporary = path.with_suffix(path.suffix+'.partial')
    with urllib.request.urlopen(url, timeout=120) as response, temporary.open('wb') as file:
        while data := response.read(1024*1024):
            file.write(data)
    temporary.replace(path)
    print('Downloaded '+path.name, flush=True)


def verified_extract(asset, archive_path, target):
    digest = hashlib.sha256(archive_path.read_bytes()).hexdigest()
    if asset.get('digest') != 'sha256:'+digest:
        archive_path.unlink()
        raise RuntimeError('Official release checksum mismatch: '+asset['name'])
    with zipfile.ZipFile(archive_path) as archive:
        for info in archive.infolist():
            if not (target/info.filename).resolve().is_relative_to(target.resolve()):
                raise RuntimeError('Unsafe archive path.')
        archive.extractall(target)


def install_cuda(release):
    target = ROOT/'.native/llama-cuda'
    target.mkdir(parents=True, exist_ok=True)
    assets = [next(item for item in release['assets'] if item['name'] == name) for name in CUDA_ASSETS]
    with ThreadPoolExecutor(max_workers=2) as pool:
        list(pool.map(lambda a: fetch(a['browser_download_url'], target/a['name']), assets))
    for asset in assets:
        verified_extract(asset, target/asset['name'], target)
    if not (target/'llama-tts.exe').is_file():
        raise RuntimeError('CUDA build did not contain llama-tts.exe.')
    print('GPU (CUDA 12.4) voice runtime is ready.', flush=True)


def get_release():
    with urllib.request.urlopen(urllib.request.Request(
            'https://api.github.com/repos/ggml-org/llama.cpp/releases/tags/'+TAG,
            headers={'User-Agent':'JarvisVoiceSetup'}), timeout=30) as response:
        return json.load(response)


def main():
    if sys.version_info < (3, 11):
        raise SystemExit('Python 3.11 or newer is required.')
    if '--gpu-only' in sys.argv:
        if not has_nvidia():
            raise SystemExit('No NVIDIA driver found. Update the NVIDIA driver first.')
        install_cuda(get_release())
        return
    subprocess.run([sys.executable, '-m', 'pip', 'install', '--target', str(ROOT/'.windows-env'),
                    '-r', str(ROOT/'requirements-windows.txt')], check=True)
    native, models = ROOT/'.native/llama', ROOT/'.models/gguf'
    native.mkdir(parents=True, exist_ok=True)
    models.mkdir(parents=True, exist_ok=True)
    release = get_release()
    asset = next(item for item in release['assets']
                 if item['name'] == 'llama-b11960-bin-win-cpu-x64.zip')
    base = 'https://huggingface.co/ggml-org/Qwen3-TTS-12Hz-1.7B-Base-GGUF/resolve/main/'
    jobs = [(asset['browser_download_url'], native/'release.zip'),
            (base+'Qwen3-TTS-12Hz-1.7B-Base-Q4_K_M.gguf', models/'tts-q4.gguf'),
            (base+'mmproj-Qwen3-TTS-12Hz-1.7B-Base-Q8_0.gguf', models/'codec-q8.gguf')]

    def download(job):
        url, path = job
        if path.is_file():
            return
        temporary = path.with_suffix(path.suffix+'.partial')
        with urllib.request.urlopen(url, timeout=120) as response, temporary.open('wb') as file:
            while data := response.read(1024*1024):
                file.write(data)
        temporary.replace(path)
        print('Downloaded '+path.name, flush=True)

    with ThreadPoolExecutor(max_workers=3) as pool:
        list(pool.map(download, jobs))
    digest = hashlib.sha256((native/'release.zip').read_bytes()).hexdigest()
    if asset.get('digest') != 'sha256:'+digest:
        raise RuntimeError('Official release checksum mismatch.')
    with zipfile.ZipFile(native/'release.zip') as archive:
        for info in archive.infolist():
            if not (native/info.filename).resolve().is_relative_to(native.resolve()):
                raise RuntimeError('Unsafe archive path.')
        archive.extractall(native)
    if has_nvidia():
        try:
            install_cuda(release)
        except Exception as exc:
            print('GPU runtime was not installed; CPU will be used. Reason: '+str(exc), flush=True)
    print('Native Qwen is ready. Prepare local voice references, then run Start-Qwen-CPU.cmd.')


if __name__ == '__main__':
    main()
