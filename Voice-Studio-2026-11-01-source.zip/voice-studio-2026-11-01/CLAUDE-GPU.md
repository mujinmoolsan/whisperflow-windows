# 자비스 한국어 음성 GPU 전환 (Claude, 2026-11-01)

## 작업실 통합 검토 (Codex)

- 중지 요청은 GPU 시도와 CPU 대체 실행 사이에서도 유지됩니다. 중지된 요청 때문에 새 합성이 시작되거나 GPU가 비활성화되지 않습니다.
- GPU 실행 파일을 시작하지 못하는 OS 오류도 CPU 대체 실행 대상으로 처리합니다.
- 자비스의 native GPU 합성 직전에는 같은 음성 서버가 소유한 **유휴 상태의** 데커드 작업자를 종료해 GPU 메모리를 비웁니다. 이미 합성 중인 작업자는 이 경로에서 종료하지 않습니다. 데커드로 돌아오면 모델을 다시 불러올 수 있습니다.
- native 명령·GPU 대체·중지·오류 기록·사용자 지정 런타임 경로·기존 승인 음성 경로에 대한 모의 검사 19개를 통과했습니다. 실제 GPU 음질과 체감 속도는 이 검사에 포함되지 않습니다.
- 이 변경은 자비스 음성 **합성(TTS)** 경로입니다. Whisper 음성인식(STT), GPT 응답 생성, 클라우드 실시간 연결은 바꾸지 않습니다.

Integration base: Claude commit `83311556cc3705bc7f4f71b61c5499f0d6d30ecd`. The 300-second first-CUDA-run timeout is preserved for both GPU and CPU attempts. Measurements below are reported by the upstream author; the integration regression tests do not perform GPU benchmarks.

GPT의 Voice Studio(2026-11-01) 위에 **한 가지만** 바꿨습니다: 자비스 한국어가 쓰는 네이티브 GGUF 엔진(`whisperflow/native_qwen.py`)을 그래픽카드로 돌리는 것.
문장 분할·다음 문장 미리 생성·캐시·상주 작업자는 GPT 버전에 이미 있으므로 건드리지 않았습니다.

## 바뀐 점

- `Setup-GPU.cmd` (신규): 공식 llama.cpp `b11960` **CUDA 12.4** 빌드와 런타임을 `.native/llama-cuda`에 설치합니다. GitHub 공식 체크섬을 확인합니다.
  `Setup-Native-Qwen.cmd`도 NVIDIA 드라이버가 보이면 같이 설치를 시도합니다(실패해도 CPU 설치는 그대로).
- `native_qwen.py`: `.native/llama-cuda`가 있으면 `-ngl 99`(모델 전체 GPU), 없으면 기존처럼 `-ngl 0`.
  GPU 실행이 한 번 실패하면 그 프로세스 동안은 자동으로 CPU 빌드로 돌아갑니다(`.windows-data/native-error.log`에 `[GPU]` 기록).
  CPU 스레드 4 고정 → 코어 수 기준 자동(`JARVIS_THREADS`), GPU 레이어 수는 `JARVIS_GPU_LAYERS`, 강제 CPU는 `JARVIS_FORCE_CPU=1`.
- `tests/test_native_gpu.py`: GPU 선택, 실패 시 CPU 전환, CPU 전용 설치 유지.

## 적용 (Windows)

1. NVIDIA 드라이버 최신 확인 (이 PC: Studio 617.42 / GTX 1660 SUPER 확인됨).
2. `Setup-GPU.cmd` 실행 → `GPU (CUDA 12.4) voice runtime is ready.`
3. Voice Studio를 다시 시작하고 자비스 한국어로 같은 문장을 말하게 해서 첫 소리까지 시간을 비교합니다.

## Claude 원저자가 보고한 비교 측정 (2026-11-01, GTX 1660 SUPER / Studio 617.42)

아래는 원저자가 같은 문장과 자비스 한국어 승인 프리셋으로 측정했다고 보고한 값입니다. 이 통합 작업에서 같은 비교를 재현한 결과는 아닙니다.

| 실행 | 생성 시간 | 음성 길이 |
|---|---|---|
| CPU | 11.69초 | 4.88초 |
| GPU 첫 실행 (CUDA 캐시 생성, 1회만) | 106.98초 | 5.76초 |
| GPU 두 번째부터 | **5.32초** | 5.76초 |

GPU는 음성 길이보다 빨리 만듭니다(실시간 배율 약 0.92). 첫 실행은 드라이버가 CUDA 코드를 한 번 컴파일하는 시간이며, 드라이버를 다시 업데이트하면 한 번 더 생길 수 있습니다.

## 아직 검증 안 됨

- 이 통합 환경에서 같은 문장에 대한 CPU/GPU 비교와 실제 대화의 응답속도. 자동 검사는 모의 실행을 사용합니다.
- `llama-tts`의 Qwen3-TTS가 CUDA에서 CPU와 같은 음질을 내는지 청취 확인 필요.
- GPT 인계 문서의 핵심 병목(최종 답변을 다 받은 뒤에야 합성 시작, SDK가 전체 파형을 한 번에 반환)은 이 변경으로 해결되지 않습니다. 이 변경은 "목소리 만드는 시간" 자체를 줄이는 쪽입니다.

## 별도의 로컬 통합 확인 (Codex)

공식 체크섬으로 설치 런타임을 확인했고 CLI에서 NVIDIA GPU를 열거했습니다. 짧은 문장 한 번을 소리 없이 합성할 때 CUDA 실행 파일과 `-ngl 99`가 선택됐으며 5.867초에 1.332초 분량의 24 kHz 음성을 만들었습니다. CPU 대체 실행은 없었습니다. 음성은 재생·업로드하지 않았고 공개 소스에 포함하지 않습니다. 이는 원저자의 비교 측정과 별개이며, 음질·최초 청취 지연·양방향 실시간 대화를 검증한 결과는 아닙니다. 이후 300초 timeout 변경은 모의 검사로 확인했으며 모델 합성을 반복하지 않았습니다.
